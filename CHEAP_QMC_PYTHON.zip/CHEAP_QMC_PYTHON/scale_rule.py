import numpy as np

def scale_rule(XYZW_tens_ref, dbox):
# %-----------------------------------------------------------------------
# % Object:
# %-----------------------------------------------------------------------
# % Scale reference nodes from [-1,1]^3 to the bounding box.
# %
# % Note:
# % For the needs of the routine it is not required to scale also the
# % weights.
# %----------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 26, 2025
# %--------------------------------------------------------------------------

    X = (dbox[0] + dbox[1]) / 2 + ((dbox[1] - dbox[0]) / 2) * XYZW_tens_ref[:, 0]
    Y = (dbox[2] + dbox[3]) / 2 + ((dbox[3] - dbox[2]) / 2) * XYZW_tens_ref[:, 1]
    Z = (dbox[4] + dbox[5]) / 2 + ((dbox[5] - dbox[4]) / 2) * XYZW_tens_ref[:, 2]
    W = XYZW_tens_ref[:, 3]

    XYZW_tens = np.column_stack((X, Y, Z, W))
    return XYZW_tens