#!/usr/bin/env python
# coding: utf-8


import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
import math
from scipy.special import comb

from cheap_startup import *



def dCHEBVAND(deg,X,dbox,duples, *args, **kwargs):
    
    # ........................... Function body ...............................


    # Box containing the cloud
    if dbox is None:
        a = np.min(X, axis=0)
        b = np.max(X, axis=0)
        dbox = np.vstack([a, b])
    else:
        a = dbox[0, :]
        b = dbox[1, :]
    #d-uples of indices with sum less or equal to "deg" graded lexicographical order
    d = X.shape[1]  # Dimension of space

    if duples is None:
        N = int(comb(deg + d, d)) 
        duples = np.zeros((N, d), dtype=int)
        
        for i in range(1, N):
            duples[i, :] = mono_next_grlex(d, duples[i-1, :])  

    # Mapping the mesh into the hypercube [-1,1]^d
    map_ = np.zeros_like(X)
    for i in range(d):
        map_[:, i] = (2 * X[:, i] - b[i] - a[i]) / (b[i] - a[i])

    # Compute the Chebyshev-Vandermonde matrix on the mesh
    T = chebpolys(deg, map_[:, 0])
    duples_c= np.array(duples)
    
    
    V = T[:, duples_c[:, 0] ]

    for i in range(1, d):
        T = chebpolys(deg, map_[:, i])
        
        V *= T[:, duples_c[:, i] ]



    return V,dbox






def chebpolys(deg,x):

    T = np.zeros((len(x), deg + 2))
    
    T[:, 0] = np.ones(len(x))  
    T[:, 1] = x  
    
    t0 = T[:, 0]
    t1 = T[:, 1]

    for j in range(2, deg + 1):
        t2 = 2 * x * t1 - t0
        T[:, j] = t2
        t0, t1 = t1, t2
    

    return T









