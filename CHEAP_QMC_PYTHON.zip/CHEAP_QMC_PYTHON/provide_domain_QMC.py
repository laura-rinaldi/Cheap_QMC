
import numpy as np
from scipy.spatial import ConvexHull
import scipy.stats.qmc as qmc
from scipy.stats.qmc import Halton
from scipy.spatial import Delaunay
from collections import defaultdict
import alphashape
import pyvista as pv

from shapely.geometry import MultiPoint
from shapely.geometry import Point, Polygon
import trimesh

from inpolyhedron import *
from polyhedron import *
from inball import *
from provide_vertices import *

def provide_domain_QMC(example, card):
# %--------------------------------------------------------------------------
# % Object:
# %--------------------------------------------------------------------------
# % This routine, depending on the example, defines the domain "D" as 
# % specified by the variable "example". 
# % 
# % Random nodes of cardinality "card" are defined on a bounding box of the 
# % domain, so determining, by in-domain functions, a QMC rule on the domain 
# % D.
# % 
# % The rule has nodes the N x 3 matrix "pts_QMC", as weights the N x 1
# % matrix w_QMC, and in the 2 x 3 matrix "dbox" it represents the bounding 
# % box of the domain (first row are the left x,y,z extrema, the second row 
# % consist of the right x,y,z extrema).
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# % Modified object (Oct. 21, 2025).
# % Cut attached routines (inball, provide_vertices).
# % Modified object attached routine.
# % Cut string about printing fprintf('\n \t Example 2').
# %--------------------------------------------------------------------------
# % License:
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 22, 2025
# %--------------------------------------------------------------------------

    if example == 1:  # intersection polyhedron/ball
        # -------------------- Sfera --------------------
        center = np.array([0, 0, 0])
        radius = 1

        dbox_ball_X = [center[0] - radius, center[0] + radius]
        dbox_ball_Y = [center[1] - radius, center[1] + radius]
        dbox_ball_Z = [center[2] - radius, center[2] + radius]

        # ------------------ Poliedro --------------------
        example_polyhedron = 1
        vertices, polyhedron_type, alphashape_radius = provide_vertices(example_polyhedron)
        # print('v',np.shape(vertices))
        X, Y, Z = vertices[:, 0], vertices[:, 1], vertices[:, 2]
       
        # Metodo di triangolazione
        tri_method = 1
        if tri_method == 1:
            mesh = alphashape.alphashape(vertices, alphashape_radius)
            facets = mesh.faces  
            

            
        elif tri_method == 2:
            hull = ConvexHull(np.column_stack((X, Y, Z)), qhull_options='QJ')
            facets_sorted = np.sort(hull.simplices, axis=1)
            facets = facets_sorted[np.argsort(facets_sorted[:, 0])]

        facets= np.array([
                        [13, 19,  6],
                        [11, 13,  6],
                        [14, 15,  8],
                        [20,  2, 17],
                        [11, 10,  2],
                        [13, 11,  2],
                        [ 7, 19, 13],
                        [ 8, 19,  7],
                        [14,  8,  7],
                        [17,  2, 10],
                        [16,  6,  3],
                        [16, 11,  6],
                        [ 9, 16,  3],
                        [ 7,  2, 20],
                        [ 7, 13,  2],
                        [15,  6, 19],
                        [15,  3,  6],
                        [ 4,  3, 12],
                        [17,  4, 12],
                        [15, 19,  8],
                        [11, 16,  9],
                        [10, 11,  9],
                        [17,  9,  4],
                        [17, 10,  9],
                        [ 9,  3,  4],
                        [ 7, 12, 14],
                        [ 7, 20, 12],
                        [12, 15, 14],
                        [15, 12,  3],
                        [20, 17, 12]        ]) -1
       
        fv = {
                    'vertices': vertices,  # numpy array (N, 3)
                    'faces': facets        # numpy array (M, 3)
                }
        
        #print('s', np.shape(facets), np.shape(vertices))
        dbox_polyhedron_X = [np.min(X), np.max(X)]
        dbox_polyhedron_Y = [np.min(Y), np.max(Y)]
        dbox_polyhedron_Z = [np.min(Z), np.max(Z)]

        # ------------- bounding box intersection-------------
        dbox_X = [max(dbox_ball_X[0], dbox_polyhedron_X[0]),
                  min(dbox_ball_X[1], dbox_polyhedron_X[1])]
        dbox_Y = [max(dbox_ball_Y[0], dbox_polyhedron_Y[0]),
                  min(dbox_ball_Y[1], dbox_polyhedron_Y[1])]
        dbox_Z = [max(dbox_ball_Z[0], dbox_polyhedron_Z[0]),
                  min(dbox_ball_Z[1], dbox_polyhedron_Z[1])]

        dbox = np.array([dbox_X, dbox_Y, dbox_Z])
       # print(dbox)

        # ......................... 4. QMC rule ...........................


        p = qmc.Halton(d=3, scramble=False)
        pts_ud_ref = p.random(n=card)
        

        
        # PP=[0.51    0.26    0.63]; ip = inpolyhedron(fv, PP)
        pts_ud_bb = np.zeros((card, 3))
        
        pts_ud_bb[:, 0] = dbox_X[0] + np.diff(dbox_X) * pts_ud_ref[:, 0]
        pts_ud_bb[:, 1] = dbox_Y[0] + np.diff(dbox_Y) * pts_ud_ref[:, 1]
        pts_ud_bb[:, 2] = dbox_Z[0] + np.diff(dbox_Z) * pts_ud_ref[:, 2]

        
        #inside polyhedron
        ip = inpolyhedron(fv, pts_ud_bb)
        #ip = polyhedron(fv, pts_ud_bb)
        #print('ip',ip)
        ind2=(np.array(ip)==1);
        pts_ud_2=pts_ud_bb[ind2[:,0],:];
        #print(pts_ud_2)
        
        #inside cylinder
        pts_QMC = inball(pts_ud_2, center, radius)
        card_int=np.shape(pts_QMC)[0];
        

        #QMC weights
        vol_bb=(np.diff(dbox_X))*(np.diff(dbox_Y))*(np.diff(dbox_Z));
        w_QMC=(vol_bb/card)*np.ones((card_int,1));

    if example == 2: # union of balls


        card_centers = 5
        
        # Generazione dei centri con Halton 3D
        sampler_centers = qmc.Halton(d=3, scramble=False)
        centers = sampler_centers.random(n=card_centers)
        
        # Raggi dei centri
        radii = 0.5 * np.ones((card_centers, 1))
        
        #  bounding box
        xmin = centers[:, 0] - radii[:, 0]
        xmax = centers[:, 0] + radii[:, 0]
        ymin = centers[:, 1] - radii[:, 0]
        ymax = centers[:, 1] + radii[:, 0]
        zmin = centers[:, 2] - radii[:, 0]
        zmax = centers[:, 2] + radii[:, 0]
        

        dbox_X = [np.min(xmin), np.max(xmax)]
        dbox_Y = [np.min(ymin), np.max(ymax)]
        dbox_Z = [np.min(zmin), np.max(zmax)]
        dbox = np.array([dbox_X, dbox_Y, dbox_Z])
       
        
        sampler_pts = qmc.Halton(d=3, scramble=False)
        pts_ud_ref = sampler_pts.random(n=card)
        

        pts_ud_bb = np.zeros_like(pts_ud_ref)
        pts_ud_bb[:, 0] = dbox_X[0] + (np.diff(dbox_X)) * pts_ud_ref[:, 0]
        pts_ud_bb[:, 1] = dbox_Y[0] + (np.diff(dbox_Y)) * pts_ud_ref[:, 1]
        pts_ud_bb[:, 2] = dbox_Z[0] + (np.diff(dbox_Z)) * pts_ud_ref[:, 2]
        
        # finding Halton points in unions of balls.
        ip = np.zeros(card, dtype=bool)
        for k in range(card):
            pt = pts_ud_bb[k, :]
            dist_centers = np.sqrt(np.sum((centers - pt)**2, axis=1))
            ip[k] = np.any(dist_centers <= radii[:, 0])
        
        # 
        ind2=(np.array(ip)==1);
        pts_QMC =pts_ud_bb[ind2[:],:];
        card_int = pts_QMC.shape[0]
        
        # QMC weights
        vol_bb = (np.diff(dbox_X))*(np.diff(dbox_Y))*(np.diff(dbox_Z))
        w_QMC = (vol_bb / card) * np.ones((card_int, 1))
       
        

    return pts_QMC, w_QMC, dbox






