import numpy as np

def incylinder(pts, r, h):
# %--------------------------------------------------------------------------
# % Object:
# % This functions selects what points "pts_in" in the set "pts" are inside 
# % a cilinder.
# %
# % In particular, the cylinder has
# % a) height "h", 
# % b) symmetry axis that is the z-axis,
# % c) as basis the disk centered in (0,0) and radius "r".
# % 
# % We determine the points "pts_in" between those in "pts" (N x 3 matrix) 
# % that are inside the cylinder.
# % The variable "indices" describes the indices of the rows in "pts" such
# % that "pts_in=pts(indices,:)".
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# %--------------------------------------------------------------------------
# % License:
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 26, 2025
# %--------------------------------------------------------------------------
    x, y, z = pts[:, 0], pts[:, 1], pts[:, 2]

    i1 = (x**2 + y**2 <= r**2)
    i2 = (z <= h) & (z >= 0)

    #indices = np.where(i1 & i2)[0]
    indices = np.where((i1 + i2) == 2)[0]
    pts_in = pts[indices]

    return pts_in, indices



