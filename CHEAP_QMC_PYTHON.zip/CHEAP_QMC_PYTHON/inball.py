
import numpy as np
from scipy.spatial import ConvexHull
import scipy.stats.qmc as qmc
from scipy.stats.qmc import Halton
from scipy.spatial import Delaunay
from collections import defaultdict

from inpolyhedron import *






def inball(pts, center, radius):
# %--------------------------------------------------------------------------
# % Object:
# % This functions selects what points "pts_in" in the set "pts" are inside 
# % the ball with center "center" and radius "r".
# %
# % In the output we also provide the index of these points in the set "pts".
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# % Modified object (Oct. 21, 2025)
# % Modified line of adeV.
# % Modified below the test functions and their call in the routine.
# %--------------------------------------------------------------------------
# % License:
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 22, 2025
# %--------------------------------------------------------------------------

    dist_squared = np.sum((pts - center)**2, axis=1)
    in_mask = dist_squared <= radius**2
    ind=np.where(np.array(in_mask)==1)[0];
    pts_in = pts[ind, :]
    return pts_in