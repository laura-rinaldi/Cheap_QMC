import numpy as np
from dCHEBVAND import *


def cubature_tens_chebyshev_QMC(nodes, weights, chebyshev_indices, dbox):
 

# %--------------------------------------------------------------------------
# % Object.
# %--------------------------------------------------------------------------
# % This routine, having cubature nodes/weights of a cubature rule with nodes
# % "nodes" and weights "weights" computes all the moments of the Chebyshev
# % basis, scaled in the bounding box of the domain.
# %
# % The vector "chebyshev_indices" specifies the polynomial degrees, that is
# % the indices i, j, k of the tensorial polynomial T_i*T_j*T_k.
# %
# % As output we provide these moments in the column vector "chebyshev_moms",
# % ordered as in "chebyshev_indices", with total degree as
# % "chebyshev_total_degrees".
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete 
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# % Modified object (Oct. 21, 2025)
# %--------------------------------------------------------------------------
# % Authors: Laura Rinaldi, Alvise Sommariva*, Marco Vianello.
# %--------------------------------------------------------------------------
    X=nodes[:, 0]
    Y=nodes[:, 1]
    Z=nodes[:, 2]

    # Map to reference cube [-1, 1] x [-1, 1] x [-1, 1]
    A1, B1 = (dbox[0] + dbox[1]) / 2, (dbox[1] - dbox[0]) / 2
    A2, B2 = (dbox[2] + dbox[3]) / 2, (dbox[3] - dbox[2]) / 2
    A3, B3 = (dbox[4] + dbox[5]) / 2, (dbox[5] - dbox[4]) / 2

    XN = (X - A1) / B1
    YN = (Y - A2) / B2
    ZN = (Z - A3) / B3
    
    ade = np.max(chebyshev_indices[:, 0])
    
    
    V_QMC, qbox = dCHEBVAND(ade,np.column_stack((XN, YN, ZN)),np.array([[-1 ,-1, -1],[ 1, 1, 1]]),chebyshev_indices);
   

    chebyshev_moms = np.dot(weights.T, V_QMC).T

    return chebyshev_moms