#!/usr/bin/env python
# coding: utf-8



import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
import math
from scipy.special import comb
from itertools import combinations_with_replacement

from dCHEBVAND import *
from mono_next_grlex import *
from tenscheb_norm2sq import *
from cub_gausscheb_tens3D import *

# %--------------------------------------------------------------------------
# % Object.
# %--------------------------------------------------------------------------
# % The cheap algorithm requires a startup that can be used for rules over
# % 3D domains. 
# %
# % The variables computed here are independent from the polyhedra and can be
# % computed and even stored for computing rules with degree of exactness
# % "ade" on any polyhedra.
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % Effective numerical integration on complex shaped elements by discrete signed measures
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# % Modified object (Oct. 27, 2025)
# %--------------------------------------------------------------------------
# % Authors: Laura Rinaldi, Alvise Sommariva*, Marco Vianello.
# %--------------------------------------------------------------------------

def cheap_startup(ade):


    # A. compute moments
    XYW_tens_ref=(cub_gausscheb_tens3D(2*ade));

    # B. compute basis indices (tens. cheb. basis ordering)
    d=3; 
    
    N = int(comb(ade + d, d) )

    chebyshev_indices = np.zeros((N, d), dtype=int)

    for i in range(1, N):
        chebyshev_indices[i, :] = mono_next_grlex(d, chebyshev_indices[i-1, :])

    # C. reference Vandermonde matrix
    X=XYW_tens_ref[:,:3]
    V_ref, dbox = dCHEBVAND(ade,X,np.array([[-1 ,-1, -1],[ 1, 1, 1]]),chebyshev_indices);

    # D. scalar products of basis elements.
    [coeffs,chebyshev_indices]=tenscheb_norm2sq(ade,chebyshev_indices);

    return XYW_tens_ref,chebyshev_indices,V_ref,coeffs








