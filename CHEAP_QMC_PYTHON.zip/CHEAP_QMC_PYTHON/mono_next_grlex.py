#!/usr/bin/env python
# coding: utf-8




import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
import math
from scipy.special import comb

from cheap_startup import *
from dCHEBVAND import *



def mono_next_grlex(m, x):

    x = x.copy()  # Ensure modifications don't affect the original array

    # Find the index of the rightmost nonzero entry
    i = np.max(np.where(x > 0)[0], initial=-1)

    if i == -1:  # If all values are zero, start with [0, 0, ..., 1]
        x[-1] = 1
        return x

    t = x[i]
    x[i] = 0

    if i > 0:
        x[i - 1] += 1
        x[-1] += t - 1
    else:
        x[-1] = t + 1

    return x







