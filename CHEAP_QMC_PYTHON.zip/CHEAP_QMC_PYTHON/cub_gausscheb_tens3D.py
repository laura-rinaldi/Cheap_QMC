
import numpy as np




def gauss_cheb(deg):

# %--------------------------------------------------------------------------
# % OBJECT:
# %--------------------------------------------------------------------------
# % Gauss-Chebyshev rule on (-1,1).
# %--------------------------------------------------------------------------
# % Modified object (Oct. 21, 2025)
# %--------------------------------------------------------------------------
# % License:
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 22, 2025
# %--------------------------------------------------------------------------

    i = np.arange(1, deg + 1)
    x = np.cos((2 * i - 1) * np.pi / (2 * deg))
    w = (np.pi / deg) * np.ones_like(x)
    return x, w

def cub_gausscheb_tens3D(deg):

# %--------------------------------------------------------------------------
# % OBJECT:
# %--------------------------------------------------------------------------
# % Tensorial Gauss-Chebyshev rule on the cube [-1,1]^3.
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete 
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# % Modified object (Oct. 21, 2025)
# %-----------------------------------------------------------------------
# %--------------------------------------------------------------------------
# % License:
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 22, 2025
# %--------------------------------------------------------------------------

    card_gs = int(np.ceil((deg + 1) / 2))
    x, w = gauss_cheb(card_gs)

    Z, Y, X = np.meshgrid(x, x, x, indexing='ij')
    WX, WY, WZ = np.meshgrid(w, w, w, indexing='ij')

    XYZW = np.column_stack((X.ravel(), Y.ravel(), Z.ravel(), (WX * WY * WZ).ravel()))
    return XYZW


