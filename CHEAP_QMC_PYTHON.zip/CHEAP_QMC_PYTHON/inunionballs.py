import numpy as np

def inunionballs(pts, centers, radii):
# %-----------------------------------------------------------------------
# % Object.
# %-----------------------------------------------------------------------
# % Determine what points in the matrix "N x 3" named "pts" are in the union
# % of balls whose 
# % 
# % 1. centers are stored in the matrix "M x 3" named "centers" 
# % 2. corresponding radii are stored in the vector "M x 1" named "radii".
# %
# % If "in(k)=1" then the point "pts(k,:)" is in the union of those balls
# % otherwise it is not.
# %--------------------------------------------------------------------------
# %----------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 22, 2025
# %--------------------------------------------------------------------------
    cx, cy, cz = centers[:, 0], centers[:, 1], centers[:, 2]
    card = pts.shape[0]
    in_union = np.zeros(card, dtype=bool)

    for k in range(card):
        x, y, z = pts[k]
        dist_centers = np.sqrt((cx - x)**2 + (cy - y)**2 + (cz - z)**2)
        if np.any(dist_centers <= radii):
            in_union[k] = True

    return in_union