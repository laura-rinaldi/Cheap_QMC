import numpy as np
from scipy.spatial import Delaunay
import trimesh
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# % Modified object (Oct. 21, 2025)
# % Modified line of adeV.
# % Modified below the test functions and their call in the routine.
# %--------------------------------------------------------------------------
# % License:
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %

# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 22, 2025
# %--------------------------------------------------------------------------


def inpolyhedron(*args, **kwargs):
    facets, qPts, options = parseInputs(*args, **kwargs)
  
    numFaces = facets.shape[2]

    if not options.get("griddedInput", False):
        numQPoints = qPts.shape[0]
    else:
        numQPoints = np.prod([len(v) for v in qPts[:2]])

        
    allEdgeVecs = facets[[1, 2, 0], :, :] - facets[:, :, :] 

    if options.get("facenormals") is None:
        a = allEdgeVecs[0, :, :]
        b = allEdgeVecs[0].T  
        c = allEdgeVecs[1].T
        allFacetNormals = np.cross(b, c) 
        allFacetNormals /= np.linalg.norm(allFacetNormals, axis=1, keepdims=True)


        allFacetNormals = np.transpose(allFacetNormals, (1, 0))[:, np.newaxis, :]

    else:
        allFacetNormals = np.transpose(options["facenormals"], (2, 1, 0))

    if options.get("flipnormals", False):
        allFacetNormals = -allFacetNormals
    isFacetUseful = allFacetNormals[2, 0, :] != 0



    if options.get("gridsize") is not None:
        gridSize = options["gridsize"]
    else:
        def GSfit(x, y):
            return (-47 + 12.83*x + 20.89*y + 0.7578*x**2 - 6.511*x*y - 2.586*y**2 +
                    -0.1802*x**3 + 0.2085*x**2*y + 0.7521*x*y**2 + 0.09984*y**3 +
                    0.005815*x**4 + 0.007775*x**3*y - 0.02129*x**2*y**2 - 0.02309*x*y**3)
        gridSize = int(min(150, max(1, np.ceil(GSfit(np.log(numQPoints), np.log(numFaces))))))
        if np.isnan(gridSize):
            gridSize = 1


    minFacetCoords = np.min(facets[:, :2, :], axis=0).T
    maxFacetCoords = np.max(facets[:, :2, :], axis=0).T
    scalingOffsetsXY = np.min(minFacetCoords, axis=0) - np.finfo(float).eps
    scalingRangeXY = np.max(maxFacetCoords, axis=0) - scalingOffsetsXY + 2*np.finfo(float).eps


    adjusted_min = minFacetCoords - options["tol"]
    adjusted_max = maxFacetCoords + options["tol"]

    
    facet_bounds = np.hstack((adjusted_min, adjusted_max))  

    offsets = np.tile(scalingOffsetsXY, 2)  
    ranges = np.tile(scalingRangeXY, 2)     

    scaled_idxs = ((facet_bounds - offsets) / ranges) * gridSize
    lowToHighGridIdxs = np.floor(scaled_idxs).astype(int) 

    

    cells = [[[] for _ in range(gridSize)] for _ in range(gridSize)]

    unqLHgrids, inverse_inds = np.unique(lowToHighGridIdxs, axis=0, return_inverse=True)

    useful_inds = np.where(isFacetUseful)[0]
    useful_inverse = inverse_inds[useful_inds]


    tmpInds = {}
    for idx, facet in zip(useful_inverse, useful_inds):
        tmpInds.setdefault(idx, []).append(facet)

    for xi in range(gridSize ): 
        xyMinMask = (xi >= unqLHgrids[:, 0]) & (xi <= unqLHgrids[:, 2]) 
        for yi in range(gridSize ):
            full_mask = xyMinMask & (yi >= unqLHgrids[:, 1]) & (yi <= unqLHgrids[:, 3])  
            selected = [tmpInds[i] for i, m in enumerate(full_mask) if m]
            cells[yi ][xi ] = np.concatenate(selected, axis=0) if selected else np.array([])

    del lowToHighGridIdxs, unqLHgrids, inverse_inds, tmpInds,  minFacetCoords, maxFacetCoords
    

    edgeVecs = allEdgeVecs[:, :2, :]
    edgeUVecs = edgeVecs / np.linalg.norm(edgeVecs, axis=1, keepdims=True)
    

    
    alledgeEdgeDotPs  =      np.sum(edgeUVecs * -edgeUVecs[[2, 0, 1], :, :], axis=1, keepdims=True) - 1e-9
    



    if not options.get("griddedInput", False):
        qPtsXY = qPts[:, :2]
        def qPtsXYZViaUnqIndice(ind): return qPts[ind]
        def outPxIndsViaUnqIndiceMask(ind, mask): return ind[mask]
        outputSize = (qPts.shape[0], 1)
        reshapeINfcn = lambda x: x
        minDistFcn = minFacetToQptDistance
    else:
        ymat, xmat = np.meshgrid(qPts[0], qPts[1])
        qPtsXY = np.column_stack((xmat.ravel(), ymat.ravel()))
        zcoords = qPts[2].ravel()
        def qPtsXYZViaUnqIndice(ind): return np.column_stack((qPtsXY[ind], zcoords[ind]))
        numZpts = len(zcoords)
        def outPxIndsViaUnqIndiceMask(ind, mask): return (ind-1)*numZpts + np.arange(numZpts)[mask]
        outputSize = (numZpts, qPtsXY.shape[0])
        reshapeINfcn = lambda x: x.reshape(qPts[2].shape[0], qPts[1].shape[0], qPts[0].shape[0])
        minDistFcn = minFacetToQptsDistance

    IN = np.zeros(outputSize, dtype=bool)


    qPtGridXY = np.floor((qPtsXY - scalingOffsetsXY) / scalingRangeXY * gridSize).astype(int) 

    ptsToConsidMask = np.all((qPtGridXY >= 0) & (qPtGridXY <= gridSize-1), axis=1)
    if not np.any(ptsToConsidMask):
        return reshapeINfcn(IN)


    uniqueGrids, qPtGridInds = np.unique(qPtGridXY, axis=0, return_inverse=True)

    
    qPtsXY_expanded = np.reshape(qPtsXY, (qPtsXY.shape[0], 2, 1, 1)) 
    qPtsXY = np.transpose(qPtsXY_expanded, (3, 1, 2, 0))    

    
    from collections import defaultdict


    valid_indices = np.where(ptsToConsidMask)[0]
    
    cellQptContentsDict = defaultdict(list)
    for i, grid_idx in enumerate(qPtGridInds[ptsToConsidMask] ):  
        cellQptContentsDict[grid_idx].append(valid_indices[i])
    
    max_idx = max(cellQptContentsDict.keys()) +1
    cellQptContents = [cellQptContentsDict.get(i, []) for i in range(max_idx)]

    

    gridsToCheck = uniqueGrids[np.all((uniqueGrids >= 0) & (uniqueGrids <= gridSize-1), axis=1), :]

    cellQptContents = [entry for entry in cellQptContents if entry]

    gridIndsToCheck =  np.sort(gridsToCheck[:, 1]  * len(cells[0]) + gridsToCheck[:, 0]) 


   
    num_cols = len(cells[0])

    row_col_pairs = [divmod(idx, num_cols) for idx in gridIndsToCheck]
    
    empty_mask =  [cells[row][col] is None or len(cells[row][col]) == 0 for row, col in row_col_pairs]
    
    for i, is_empty in enumerate(empty_mask):

       
        allFacetInds = cells[gridIndsToCheck[i%len(cells[0])]][int(i/len(cells[0]))]
        if not allFacetInds.any():  continue

        candVerts = facets[:, :2, allFacetInds]
       
        allqPtInds =  np.array(cellQptContents[i], dtype=int)

        
        queryPtsXY = qPtsXY[:,:,:,allqPtInds]


        vert2ptVecs = queryPtsXY - candVerts[:, :, :, np.newaxis]
    


        norms = np.sqrt(np.sum(vert2ptVecs**2, axis=1, keepdims=True))  
        vert2ptUVecs = vert2ptVecs / norms



        edgeUV = edgeUVecs[:, :, allFacetInds]
        
        edgeDot = alledgeEdgeDotPs[:, :, allFacetInds]
        

            
        edgeQPntDotPs = np.sum(edgeUV[:, :, :, np.newaxis] * vert2ptUVecs, axis=1, keepdims=True)  
        qPntEdgeDotPs = np.sum(
            vert2ptUVecs * -edgeUV[:, :, :, np.newaxis][[2, 0, 1], :, :, :], axis=1, keepdims=True
        )
        


        condition1 = edgeQPntDotPs > edgeDot[:, :, :, np.newaxis] 
        condition2 = qPntEdgeDotPs > edgeDot[:, :, :, np.newaxis] 

        resultIN = np.all(condition1 & condition2, axis=0) 

        resultONVERTEX = np.any(np.any(np.isnan(vert2ptUVecs), axis=1), axis=0) # shape: (num_facets, num_points)

        result = resultIN | resultONVERTEX
        result =  result[np.newaxis, :, :, :]

        qPtHits = np.any(result, axis=2)
        

    

        for ptNo in np.where(qPtHits)[2]:

            piercedFacetInds =  np.array(allFacetInds).T[result[0, 0, :, ptNo]]  
          
      
            piercedTriNorms = allFacetNormals[:, :, piercedFacetInds]
            piercedTriNorms = np.transpose(piercedTriNorms, (1, 0, 2)) 
       
           
            
            qPtXYZ = qPtsXYZViaUnqIndice(allqPtInds[ptNo]).reshape(3, 1, 1)

        
            facetOrigins = facets[0, :, piercedFacetInds].T  

            facetToQptVectors = qPtXYZ - facetOrigins[:, np.newaxis, :]
            facetToQptVectors = np.transpose(facetToQptVectors, (1, 0, 2))

           
            facetToQptDists =np.sum((piercedTriNorms* facetToQptVectors) , axis=1, keepdims=True)/np.abs(piercedTriNorms[ 0, -1, :])
            
            

            IN[outPxIndsViaUnqIndiceMask(np.atleast_1d(allqPtInds[ptNo]), minDistFcn(facetToQptDists).flatten()[0]  < options["tol"])] = True


            
            
            

    return reshapeINfcn(IN)
                                

                                        
                                        
                                        
                                        

def minFacetToQptDistance(facet_to_qpt_dists):

    min_inds = np.argmin(np.abs(facet_to_qpt_dists), axis=2)

    while np.any(np.abs(facet_to_qpt_dists + facet_to_qpt_dists[np.arange(facet_to_qpt_dists.shape[0]), :, min_inds]) < 1e-15):
        # Mask the values that need to be updated to infinity
        mask = np.abs(np.abs(facet_to_qpt_dists) - np.abs(facet_to_qpt_dists[np.arange(facet_to_qpt_dists.shape[0]), :, min_inds])) < 1e-15
        facet_to_qpt_dists[mask] = np.inf

        # Break early if no finite values remain
        if not np.any(np.isfinite(facet_to_qpt_dists)):
            break

        # Recompute minimum indices
        min_inds = np.argmin(np.abs(facet_to_qpt_dists), axis=2)

    # Extract the closest triangle distance
    closest_tri_distance = facet_to_qpt_dists[np.arange(facet_to_qpt_dists.shape[0]), :, min_inds]

    return closest_tri_distance

                                        
                                        
                                        
                                        
                                        
                                        
def minFacetToQptsDistance(facet_to_qpt_dists):
    # Compute the initial minimum values and their indices along axis 2
    min_vals = np.min(np.abs(facet_to_qpt_dists), axis=2)
    min_inds = np.argmin(np.abs(facet_to_qpt_dists), axis=2)

    # Handling edge cases where multiple values are nearly equal
    while np.any(
        np.any(np.abs(min_vals[:, np.newaxis, :] + facet_to_qpt_dists) < 1e-15, axis=2) &
        np.any(np.abs(min_vals[:, np.newaxis, :] - facet_to_qpt_dists) < 1e-15, axis=2)
    ):
        mask_p = np.abs(min_vals[:, np.newaxis, :] + facet_to_qpt_dists) < 1e-15
        mask_n = np.abs(min_vals[:, np.newaxis, :] - facet_to_qpt_dists) < 1e-15
        must_alter_mask = np.any(mask_p, axis=2) & np.any(mask_n, axis=2)

        # Set affected distances to infinity for recalculating the minimum
        facet_to_qpt_dists[must_alter_mask, :, mask_p | mask_n] = np.inf
        
        # Recompute minimum values and indices for affected rows
        new_mv = np.min(np.abs(facet_to_qpt_dists[must_alter_mask, :, :]), axis=2)
        new_min_inds = np.argmin(np.abs(facet_to_qpt_dists[must_alter_mask, :, :]), axis=2)
        min_inds[must_alter_mask] = new_min_inds.flatten()
        min_vals[must_alter_mask] = new_mv.flatten()

    # Compute closest triangle distance using advanced indexing
    closest_tri_distance = facet_to_qpt_dists[np.arange(facet_to_qpt_dists.shape[0]), :, min_inds]

    return closest_tri_distance

                                         
                                   
                                         
                                         

def parseInputs(*args, **kwargs):
    if isinstance(args[0], dict):  # Handling FV struct equivalent
        if not all(key in args[0] for key in ['vertices', 'faces']):
            raise ValueError('Structure FV must have "faces" and "vertices" fields')

        faces = np.array(args[0]['faces'])
        

        vertices = np.array(args[0]['vertices'])
        args = args[1:]

    else:  # Handling separate faces and vertices
        
        faces = np.array(args[0])
        vertices = np.array(args[1])
        args =  np.array(args[2:])

    # Unpacking faces and vertices into facets
    facets = np.transpose(vertices)
    facets = np.transpose(facets[:, faces.T], (1, 0, 2))
    
    # Extract query points
    if len(args) < 2 or isinstance(args[1], str):
        qPts = np.array(args[0])
        args = args[1:]
    else:
        qPts = np.array(args[:3])
        args = args[3:]
        kwargs["griddedInput"] = True

    # Extract configurable options
    options = parseOptions(**kwargs)

    # Check if face normals are unified
    if options.get("testNormals", False):
        options["normalsAreUnified"] = check_normal_unification(faces)
    return facets, qPts, options


                                    
                                    
import argparse

                               
                                    
def parseOptions(**kwargs):
    # Initialize parser
    parser = argparse.ArgumentParser(description="Parse input arguments.")

    # Define arguments with default values
    parser.add_argument("--gridsize", type=float, default=None, help="Grid size")
    parser.add_argument("--tol", type=float, default=0, help="Tolerance")
    parser.add_argument("--tol_ang", type=float, default=1e-5, help="Angular tolerance")
    parser.add_argument("--facenormals", type=str, default=None, help="Face normals")
    parser.add_argument("--flipnormals", type=bool, default=False, help="Flip normals")
    parser.add_argument("--griddedInput", type=bool, default=False, help="Gridded input flag")
    parser.add_argument("--testNormals", type=bool, default=False, help="Test normals flag")

    # Parse arguments
    args, _ = parser.parse_known_args()

    options = vars(args)
    options.update(kwargs)      
    return options