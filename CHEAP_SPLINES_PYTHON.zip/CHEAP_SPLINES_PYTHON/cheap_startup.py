#!/usr/bin/env python
# coding: utf-8


import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
import math
from scipy.special import comb

from spline_chebmom  import *
from cub_gausscheb_tens2D import *
from dCHEBVAND import *
from mono_next_grlex import *
from tenscheb_norm2sq import *



def cheap_startup(ade):

# %--------------------------------------------------------------------------
# % Object.
# %--------------------------------------------------------------------------
# % The cheap algorithm requires a startup that can be used for rules over
# % bivariate domains.
# %
# % The variables computed here are independent from the domain and can be
# % computed and even stored for computing rules with degree of exactness
# % "ade" on any polyhedra.
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# %--------------------------------------------------------------------------
# % License:
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 22, 2025
# %--------------------------------------------------------------------------

    # A. compute moments
    XYW_tens_ref=np.transpose(cub_gausscheb_tens2D(2*ade));

    # B. compute basis indices (tens. cheb. basis ordering)
    d=2; 
    chebyshev_indices = [];
    for i in range(ade + 1):
        for j in range(ade - i + 1):
            chebyshev_indices.append([i, j])
        #end
    #end

    # C. reference Vandermonde matrix
    X=XYW_tens_ref[:,0:2]
    V_ref, dbox = dCHEBVAND(ade,X,np.array([[-1 ,-1],[ 1, 1]]),chebyshev_indices);

    # D. scalar products of basis elements.
    [coeffs,chebyshev_indices]=tenscheb_norm2sq(ade,chebyshev_indices);

    return XYW_tens_ref,chebyshev_indices,V_ref,coeffs










