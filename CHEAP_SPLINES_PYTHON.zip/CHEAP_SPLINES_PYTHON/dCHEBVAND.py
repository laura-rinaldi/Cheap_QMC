#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
import math
from scipy.special import comb

from spline_chebmom  import *
from cheap_startup import *
from cub_gausscheb_tens2D import *



def dCHEBVAND(deg,X,dbox,duples, *args, **kwargs):
    #--------------------------------------------------------------------------
    # Object:
    # This routine computes the Chebyshev-Vandermonde matrix for degree "deg"
    # on a d-dimensional point cloud "X".
    #
    # The Chebyshev basis is the tensorial Chebyshev basis of total degree
    # "deg", shifted on the hyperrectangle defined by "dbox".
    #
    # If "dbox" is not provided, the routine sets that variable to define the
    # smaller "hyperrectangle" (box) with sides parallel to the cartesian
    # axes and containing the pointset "X".
    #--------------------------------------------------------------------------
    # Input:
    # deg: polynomial degree;
    # X: d-column array of "m" points cloud (matrix "m x d");
    # * dbox: variable that defines the smallest hyperectangle with sides
    #     parallel to the axis, containing the domain.
    #     If "dbox" is not provided, it defines the smaller "hyperrectangle",
    #     with sides parallel to the cartesian axes, containing the pointset
    #     "X".
    #     It is a matrix with dimension "2 x d", where "d" is the dimension
    #     of the space in which it is embedded the domain.
    #     For instance, for a 2-sphere, it is "d=3", while for a 2 dimensional
    #     polygon it is "d=2".
    #     As example, the set "[-1,1] x [0,1]" is described as "[-1 0; 1 1]".
    #
    # Note: the variables with an asterisk "*" are not mandatory and can be
    # also set as empty matrix.
    #--------------------------------------------------------------------------
    # Output:
    # V: shifted Chebyshev-Vandermonde matrix for degree "deg" on the pointset
    #    "X", relatively to "dbox".
    # dbox: variable that defines the hyperrectangle with sides parallel to the
    #     axis, containing the domain.



    # ........................... Function body ...............................


    # Box containing the cloud
    if dbox is None:
        a = np.min(X, axis=0)
        b = np.max(X, axis=0)
        dbox = np.vstack([a, b])
    else:
        a = dbox[0, :]
        b = dbox[1, :]

    d = X.shape[1]  # Dimension of space

    # d-uples of indices with sum less or equal to 'deg' in graded lexicographical order
    if duples is None:
        N = int(comb(deg + d, d)) 
        duples = np.zeros((N, d), dtype=int)
        
        for i in range(1, N):
            duples[i, :] = mono_next_grlex(d, duples[i-1, :])  

    # Mapping the mesh into the hypercube [-1,1]^d
    map_ = np.zeros_like(X)
    for i in range(d):
        map_[:, i] = (2 * X[:, i] - b[i] - a[i]) / (b[i] - a[i])

    # Compute the Chebyshev-Vandermonde matrix on the mesh
    T = chebpolys(deg, map_[:, 0])
    duples_c= np.array(duples)
    
    
    V = T[:, duples_c[:, 0] ]

    for i in range(1, d):
        T = chebpolys(deg, map_[:, i])
        
        V *= T[:, duples_c[:, i] ]



    return V,dbox






def chebpolys(deg,x):

    #--------------------------------------------------------------------------
    # Object:
    # This routine computes the Chebyshev-Vandermonde matrix on the real line
    # by recurrence.
    #--------------------------------------------------------------------------
    # Input:
    # deg: maximum polynomial degree
    # x: 1-column array of abscissas
    #--------------------------------------------------------------------------
    # Output:
    # T: Chebyshev-Vandermonde matrix at x, T(i,j+1)=T_j(x_i), j=0,...,deg.
    #--------------------------------------------------------------------------

    T = np.zeros((len(x), deg + 1))
    T[:, 0] = np.ones(len(x))
    T[:, 1] = x

    for j in range(2, deg + 1):
        T[:, j] = 2 * x * T[:, j-1] - T[:, j-2]
    

    return T






