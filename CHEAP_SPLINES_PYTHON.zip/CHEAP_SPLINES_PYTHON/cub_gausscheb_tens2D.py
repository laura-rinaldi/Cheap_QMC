#!/usr/bin/env python
# coding: utf-8


import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
import math
from scipy.special import comb

from spline_chebmom  import *



def cub_gausscheb_tens2D(deg):
# %--------------------------------------------------------------------------
# % OBJECT:
# %--------------------------------------------------------------------------
# % Tensorial Gauss-Chebyshev rule on the square [-1,1]^2.
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# % Modified object (Oct. 21, 2025)
# %--------------------------------------------------------------------------
# %--------------------------------------------------------------------------
# % License:
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 22, 2025
# %--------------------------------------------------------------------------


    card_gs=math.ceil((deg+1)/2);

    [x,w]=gauss_cheb(card_gs);

    [Y, X]=np.meshgrid(x, x) 
    [WY,WX]=np.meshgrid(w,w)

    XYZW=[X.ravel(), Y.ravel(), (WX.ravel())*(WY.ravel())];
    return XYZW






def gauss_cheb(deg):

    i=np.arange(1, deg+1)
    x=np.cos((2*np.transpose(i)-1)*np.pi/(2*deg));
    w=(np.pi/deg)*np.ones(len(x));
    return x,w






