#!/usr/bin/env python
# coding: utf-8


import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
from scipy.special import roots_legendre
from scipy.special import gamma, gammaln

np.set_printoptions(precision=4, suppress=True)



def splinegauss_2020(ade,Sx,Sy):

# %--------------------------------------------------------------------------
# % Object:
# % Determining cubature rule having algebraic degree of exactness "ade" on a
# % spline curvilinear domain determined parametrically by splines in each
# % variable.
# %--------------------------------------------------------------------------
# % Input:
# % ade: polynomial degree of exactness
# %
# % Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
# % the arcs must be counterclockwise concatenated forming a Jordan curve
# % Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
# % i=1,...,end, with end+1:=1.
# %
# %--------------------------------------------------------------------------
# % Output:
# % XYW: cubature rule stored as a M x 3 matrix. The rule has nodes (X,Y) 
# %      with X=XYW(:,1), Y=XYW(:,2) and weights W=XYW(:,3).
# %--------------------------------------------------------------------------
# % Reference paper:
# %--------------------------------------------------------------------------
# % For more details consider
# % [1] A. Sommariva and M. Vianello
# % "Gauss-Green cubature and moment computation over arbitrary geometries"
# % Journal of Computational and Applied Mathematics 231 (2009) 886-896
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# % Authors:
# % Alvise Sommariva and Marco Vianello
# % University of Padova, September 20, 2020.
# %--------------------------------------------------------------------------

   
    [Sx_out,Sy_out,rot_matrix,xi]=domain_rotation(Sx,Sy);
    
    # Compute cubature formula over "D", having degree of precision "ade".

    XYW_D = splinegauss_2020_basic(ade,Sx_out,Sy_out,xi);
    #XYW_D = np.array(XYW_D)
   
    
    XY_D=XYW_D[0:2]; 
    XY=np.array(XY_D).T@rot_matrix; 
    
    XYW=[XY[:,0], XY[:,1], XYW_D[2].T];


    return XYW





def splinegauss_2020_basic(ade,Sx,Sy,xi, *args, **kwargs):

    #--------------------------------------------------------------------------
    # Object:
    # Determining cubature rule having algebraic degree of exactness "ade" on a
    # spline curvilinear domain determined parametrically by splines in each
    # variable.
    #--------------------------------------------------------------------------
    # Input:
    # ade: polynomial degree of exactness
    #
    # Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
    # the arcs must be counterclockwise concatenated forming a Jordan curve
    # Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
    # i=1,...,end, with end+1:=1
    #
    # xi: parameter defining a "reference" ver# tical axis (default: xi=0)
    #
    #--------------------------------------------------------------------------
    # Output:
    # XYW: cubature rule store as a M x 3 matrix. The rule has nodes (X,Y) with
    #      X=XYW(:,1), Y=XYW(:,2) and weights W=XYW(:,3).
    #--------------------------------------------------------------------------
    # Reference paper:
    #
    # For more details consider
    # [1] A. Sommariva and M. Vianello
    # "Gauss-Green cubature and moment computation over arbitrary geometries"
    # Journal of Computational and Applied Mathematics 231 (2009) 886-896
    #--------------------------------------------------------------------------

    # .............. troubleshooting ..............

#     if len(args) + len(kwargs) < 3:
#         xi=0;
#         print('yes')
    #end
    if (np.shape(xi) == 0):
        xi=0; 
    #end
    # .............. formula computation ..............

    XYW=[];

    # Number of spline curvilinear sides
    L=len(Sx);
    # By checking the construction of the tensorial rule, one observe that
    # independently of the spline order, the code has always to compute a one
    # dimensional Gauss-Legendre rule of degree "ade".
    # We compute this rule only once, the first time we use the tensorial rule.
    # In order to make the work work, we set it equal to the null matrix.

    XYW_X=[];


    for i in range(L):
        # Determine curvilinear sides
        SXL = Sx[i]  
        SYL = Sy[i]

        # The degree of precision in x and y directions
        ade_x = ade

        # p_i = spline degree (order - 1)
        p_i = get_spline_degree(Sx[i]) - 1
        
        ade_y = (ade + 2) * p_i - 1

        # Generate tensorial quadrature rule on the reference square
        XYW_square, XYW_X = tensorial_cubature_square(ade_x, ade_y, XYW_X)
        
        # Map the quadrature rule to the curvilinear patch
        XYW_L = rule_map(XYW_square, SXL, SYL, xi)
#         print(SXL.c, SYL.c)
      
        # Append results

        if i ==0:
            XYW = XYW_L
        else:
            XYW = np.hstack([XYW, XYW_L])  


    return XYW


def get_spline_degree(spline):
    if isinstance(spline, CubicSpline):
        deg=4  # CubicSpline always means degree 3
    elif isinstance(spline, BSpline):
        deg=spline.k  # spline.k is the degree
    else:
        deg = spline.c.shape[0]#raise TypeError("Unsupported spline type")
    return deg


def tensorial_cubature_square(ade_x,ade_y,XW_X, *args, **kwargs):

    #--------------------------------------------------------------------------
    # Object:
    # In this routine we compute a cubature rule over the square, having degree
    # of precision "ade_x" in the "x" variable and "ade_y" in the "y".
    #--------------------------------------------------------------------------
    # Input:
    # ade_x: degree of precision of the cubature rule over the square in the
    #       variable x.
    # ade_y: degree of precision of the cubature rule over the square in the
    #       variable y.
    # XW_X:  cubature rule store as a M x 2 matrix. This Gauss-Legendre rule
    #     has nodes X with X=XYW(:,1) and weights W=XYW(:,2).
    #--------------------------------------------------------------------------
    # Output:
    # XYW: cubature rule store as a M x 3 matrix. The rule has nodes (X,Y) with
    #      X=XYW(:,1), Y=XYW(:,2) and weights W=XYW(:,3)
    #--------------------------------------------------------------------------
    # Observation (valif for spline curvilinear cubature):
    # By checking the construction of the tensorial rule in [1], one observe that
    # independently of the spline order, the code has always to compute a one
    # dimensional Gauss-Legendre rule of degree "ade_x".
    # We compute this rule only once, and in case it is available we use again,
    # without recomputing it again.
    #--------------------------------------------------------------------------
    # Reference paper:
    #
    # For more details consider
    # [1] A. Sommariva and M. Vianello
    # "Gauss?Green cubature and moment computation over arbitrary geometries"
    # Journal of Computational and Applied Mathematics 231 (2009) 886?896
    #--------------------------------------------------------------------------

    if XW_X is None:
        XW_X = np.array([]).reshape(0, 2)

    Nx = int(np.ceil((ade_x + 1) / 2))
 

    # Compute rule in x direction if not provided
    if np.shape(XW_X)[0] == 0:
        ab = r_jacobi(Nx, 0, 0)
        XW_X = gauss(Nx, ab)
        Xx = XW_X[ 0]
        Wx = XW_X[ 1]
    else:
        Xx = XW_X[ 0]
        Wx = XW_X[ 1]

    # Rule in y direction
    Ny = int(np.ceil((ade_y + 1) / 2))
    if Nx == Ny:
        XW_Y = XW_X
    else:
        ab = r_jacobi(Ny, 0, 0)
        XW_Y = gauss(Ny, ab)

    Xy = XW_Y[ 0]
    Wy = XW_Y[ 1]

    # Tensorial rule assembly
    X, Y = np.meshgrid(Xx, Xy)
    X = X.T.flatten()
    Y = Y.T.flatten()


    WWx, WWy = np.meshgrid(Wx, Wy)
    W = (WWx * WWy).T.flatten()

    XYW = np.column_stack((X, Y, W))
    return XYW, XW_X


# In[10]:


# ...................... GAUSSIAN RULE  ......................... 

   # GAUSS Gauss quadrature rule.
   #
   #    Given a weight function w encoded by the nx2 array ab of the
   #    first n recurrence coefficients for the associated orthogonal
   #    polynomials, the first column of ab containing the n alpha-
   #    coefficients and the second column the n beta-coefficients,
   #    the call xw=GAUSS(n,ab) generates the nodes and weights xw of
   #    the n-point Gauss quadrature rule for the weight function w.
   #    The nodes, in increasing order, are stored in the first
   #    column, the n corresponding weights in the second column, of
   #    the nx2 array xw.
   #


def gauss(N,ab):
    
    N0=np.shape(ab)[0]; 
    if N0<N:
           raise ValueError('input array ab too short')
       #end
    N=int(N)
    J=np.zeros((N,N));
    for n in range(N):
           J[n,n]=ab[n,0]; 
       #end
    for n in range(1, N):
           J[n,n-1]=np.sqrt(ab[n,1]);
           J[n-1,n]=J[n,n-1];
       #end
    D, V = np.linalg.eig(J)  # Compute eigenvalues (D) and eigenvectors (V)

    # Sort eigenvalues and rearrange eigenvectors accordingly
    I = np.argsort(D)        # Get the sorted indices of eigenvalues
    D = D[I]                 # Reorder eigenvalues
    V = V[:, I]              # Reorder eigenvectors
    xw=[D , ab[0,1]*np.transpose(V[0,:])**2];

    return xw


# In[9]:


# ...................... ORTH. POLY. RECURSION  ......................... 

def r_jacobi(N,a,b):
    nu = (b - a) / (a + b + 2)

    # Compute mu based on the given conditions
    if a + b + 2 > 128:
        mu = np.exp((a + b + 1) * np.log(2) + (gammaln(a + 1) + gammaln(b + 1) - gammaln(a + b + 2)))
    else:
        mu = 2**(a + b + 1) * (gamma(a + 1) * gamma(b + 1) / gamma(a + b + 2))

    # Handle N=1 case
    if N == 1:
        return np.array([[nu, mu]])

    # Compute coefficients
    N -= 1
    N=int(N)
    n = np.arange(1, N + 1)
    nab = 2 * n + a + b
  
    A = np.hstack([[nu], (b**2 - a**2) * np.ones(N) / (nab * (nab + 2))])

    # Compute B coefficients
    nab = nab[1:] 
    B1 = 4 * (a + 1) * (b + 1) / ((a + b + 2)**2 * (a + b + 3))
    B = 4 * (n[1:] + a) * (n[1:] + b) * n[1:] * (n[1:] + a + b) / (nab**2 * (nab + 1) * (nab - 1))

    # Construct final coefficient matrix
    ab = np.column_stack([A, np.hstack([[mu], B1, B])])
    return ab


# In[7]:







def rule_map(XYW,S1,S2,xi):

    #--------------------------------------------------------------------------
    # Object:
    # These routine, from a certain tensorial rule on the square XYW determines
    # some nodes and weights, useful to compute a rule on spline-curvilinear
    # domain.
    #
    # For more details consider formula (18) at page 888 of:
    # [1] A. Sommariva and M. Vianello
    # "Gauss?Green cubature and moment computation over arbitrary geometries"
    # Journal of Computational and Applied Mathema# fprintfs 231 (2009) 886?896
    #--------------------------------------------------------------------------
    # Input:
    # XYW: cubature rule store as a M x 3 matrix. The rule has nodes (X,Y) with
    #      X=XYW(:,1), Y=XYW(:,2) and weights W=XYW(:,3).
    # S1, S2: splines defining the boundary of the domain (they must have the
    #      same order and parametrization subintervals [t(i),t(i+1)].
    # xi:  reference point
    #--------------------------------------------------------------------------
    # Output:
    # XYW_domain: cubature rule store as a M x 3 matrix. The rule has nodes
    #      (X,Y) with X=XYW(:,1), Y=XYW(:,2) and weights W=XYW(:,3) and it is
    #      the main block for computing the wanted rule on the
    #      spline-curvilinear domain.
    #--------------------------------------------------------------------------


    tau=XYW[:,0]; 
    u=XYW[:,1]; 
    w=XYW[:,2];
    

   
    [breaks,coefs,l,k] = [S2.x.T, S2.c.T, np.shape(S2.x)[0] - 1, np.shape(S2.c)[0] ];

    d= 1  
  
    replicated = np.tile(np.arange(k-1, 0, -1), (d * l, 1))

    # Now multiply with the corresponding portion of coefs
    result = replicated * coefs[:, :k-1]
    # Now, create the PPoly object S2_prime from breaks and coefs

    S2_prime = PPoly(result.T,breaks);


    t=S1.x.T; # row vector of spline breaks
    M=len(u);
    L=len(t)-1;

    delta_t=np.diff(t); # row vector
    delta_t_rep=np.tile(delta_t,(M,1))
    #print(delta_t_rep)
    delta_t_rep=delta_t_rep.T.flatten();
   
    aver_t = (t[:-1] + t[1:]) / 2 
    

    
    aver_t_rep = np.tile(aver_t, (M, 1)).T.flatten()

    tau_rep = np.tile(tau, (L, 1)).flatten()
   
    u_rep=np.tile(u,(L,1)).flatten();
    w_rep=np.tile(w,(L,1)).flatten();



    # ........ Computing cubature nodes and weights ........

    qij_u=(delta_t_rep/2)*u_rep.T+aver_t_rep;
    #print(delta_t_rep)
    S1_qij_u=S1(qij_u);
    term1=delta_t_rep/4;

    term2=S1_qij_u-xi;
    term3=S2_prime(qij_u);

    
    W=term1*term2*term3*w_rep;

    X=(term2/2)*tau_rep+(S1_qij_u+xi)/2;
    Y=S2(qij_u);

    XYW_domain=np.array([X, Y, W]);
        
    return XYW_domain


# In[5]:


def domain_rotation(Sx_in,Sy_in):

    #--------------------------------------------------------------------------
    # Object:
    # Determining a rotation of the spline curvilinear domain "Omega" so that
    # "many" nodes will be in "Omega".
    #
    # The key idea is that we rotate the spline curvilinear domain "Omega" in
    # "D" so that the cubature rule in "D" will have "many" nodes inside.
    #
    # By another routine we rotate back the nodes from "D" to "Omega",
    # obtaining a rule with the same amount of internal points.
    #--------------------------------------------------------------------------
    # Input:
    # ade: polynomial degree of exactness
    #
    # Sx_in,Sy_in: arrays of spline structures; (Sx_in(i),yx_in(i)) is the i-th
    # arc.
    #
    # The arcs must be counterclockwise concatenated forming a Jordan curve
    # Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
    # i=1,...,end, with end+1:=1.
    #
    # Here we suppose that the curvilinear domain is tracked parametrically in
    # each variable by a certain number of splines so that the k-th spline is
    # defined either in x and y in the interval [alpha_k,beta_k].
    #
    # For more details see [1], Theorem 3.2, p.887.
    #--------------------------------------------------------------------------
    # Output:
    # ade: polynomial degree of exactness
    #
    # Sx_out,Sy_out: arrays of spline structures; (Sx_out(i),Sy_out(i)) is the
    #    i-th arc, determining the boundary of the rotated domain (i.e. the
    #    boundary of "D").
    #
    # rot_matrix: rotation matrix; the spline curvilinear domain "D" is obtain
    #     from "Omega", so that if P=[P(1); P(2)] belongs to "Omega" than
    #    "rot_matrix*P" belongs to "D" (and viceversa using "rot_matrix'").
    #
    # xi: it allows to choose a good "xi" in formula (18) for rotated domain
    #    "D".
    #
    #--------------------------------------------------------------------------
    # Reference paper:
    #
    # For more details consider
    # [1] A. Sommariva and M. Vianello
    # "Gauss?Green cubature and moment computation over arbitrary geometries"
    # Journal of Computational and Applied Mathematics 231 (2009) 886?896
    #--------------------------------------------------------------------------

    # Here we suppose that the curvilinear domain is tracked parametrically in
    # each variable by a certain number of splines so that the k-th spline is
    # defined either in x and y in the interval [alpha_k,beta_k].
    # For more details see [1], Theorem 3.2, p.887.

    control_pts=[];
    for k in range(len(Sx_in)):
        # Sample points points on the k-th curvilinear side, ie. "t" belonging to
        # "[alpha_k,beta_k]" (that is the spline parametrization interval).
        SxL=Sx_in[k]; 
        SyL=Sy_in[k];
        t= SxL.x;
        Xt=SxL(t);
        Yt=SyL(t);
        control_pts.append(np.column_stack((Xt, Yt)))
    control_pts = np.vstack(control_pts)    
    #end

    # Computing the rotation matrix to allow a high number of nodes of the rule
    # to be in the spline curvilinear domain D (rotation of the original domain
    # "Omega").
    distances = points2distances(control_pts);
    #print('d',distances)
    max_distance = np.max(np.max(distances));
    
    
    [i1,i2]=np.where(distances == max_distance);

    #print(distances, np.max(distances))
    i1=i1[0]; 
    i2=i2[0]; 
    #

    vertex_1=control_pts[i1,:];
    vertex_2=control_pts[i2,:];
    direction_axis=(vertex_2-vertex_1)/max_distance;

    rot_angle_x=np.arccos(direction_axis[0]);
    rot_angle_y=np.arccos(direction_axis[1]);

    if rot_angle_y <= np.pi/2:
        if rot_angle_x <= np.pi/2:
            rot_angle=-rot_angle_y;
        else:
            rot_angle=rot_angle_y;
        #end
    else:
        if rot_angle_x <= np.pi/2:
            rot_angle=np.pi-rot_angle_y;
        else:
            rot_angle=rot_angle_y;
        #end
    #end


    # CLOCKWISE ROTATION.
    rot_matrix=np.array([[np.cos(rot_angle) ,np.sin(rot_angle)],[ -np.sin(rot_angle), np.cos(rot_angle)]]);
    

    number_sides=np.shape(control_pts)[0]-1;

    axis_abscissa=rot_matrix@np.transpose(vertex_1); 
    xi=axis_abscissa[0];

    # Determining the boundary of the domain "D" (rotation of "Omega" via
    # "rot_matrix"). In this map the spline boundary of "Omega" is mapped (as
    # spline object!) into the spline boundary of "D".

    M=len(Sx_in);
    Sx_out=[]
    Sy_out=[]

    for k in range(M):

        SxL_in=Sx_in[k];
        SyL_in=Sy_in[k];
        
        t_vals = SxL_in.x  

        
        
        x_vals = SxL_in(t_vals)
        y_vals = SyL_in(t_vals)
        
        SxL_out_A = rot_matrix[0][0] * SxL_in.c
        
        SxL_out_B= rot_matrix[0][1] * SyL_in.c
        
        SxL_out= SxL_out_B + SxL_out_A
        

        SyL_out_A= rot_matrix[1][0] * SxL_in.c
        SyL_out_B= rot_matrix[1][1] * SyL_in.c
        
        SyL_out= SyL_out_B + SyL_out_A

#         print(SxL_out, SyL_out, t_vals)
        Sx_o=PPoly(SxL_out, t_vals)
        Sy_o=PPoly(SyL_out, t_vals)
        
        Sx_out.append(Sx_o)
        Sy_out.append(Sy_o)
        

    #end
    return [Sx_out,Sy_out,rot_matrix,xi] 



#--------------------------------------------------------------------------
# points2distances.
#--------------------------------------------------------------------------

def points2distances(points):
    #--------------------------------------------------------------------------
    # Object:
    # Create euclidean distance matrix from point matrix.
    #--------------------------------------------------------------------------
    # Input:
    # points: set of N bivariate points of which we need to compute the mutual
    #    distances, defined as N x 2 matrix of X and Y coordinates.
    #--------------------------------------------------------------------------
    # Output:
    # distances; N x N matrix of mutual distance between points, i.e.
    #   "distances(i,j)" is "norm(points(i,:),points(j,:),2)".
    #--------------------------------------------------------------------------

    # Get dimensions.
    numpoints, dim = points.shape
    
    # Matrice dei prodotti scalari
    inner = points @ points.T
    
    # Norme al quadrato
    lsq = np.diag(inner)
    
    # Formula delle distanze, con correzione
    distances = lsq[:, None] + lsq[None, :] - 2 * inner
    
    # Evita valori negativi dovuti ad arrotondamenti
    distances = np.maximum(distances, 0)
    
    # Radice quadrata
    distances = np.sqrt(distances)
    return distances










