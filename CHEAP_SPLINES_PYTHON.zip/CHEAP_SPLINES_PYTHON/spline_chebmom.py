#!/usr/bin/env python
# coding: utf-8

# In[ ]:
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev 
from scipy.interpolate import splder
from scipy.interpolate import BSpline, PPoly
import scipy.special
import math
from scipy.special import comb
import time
import warnings
from scipy.special import gamma, gammaln



def spline_chebmom(n,Sx,Sy):

# %--------------------------------------------------------------------------
# % OBJECT:
# %--------------------------------------------------------------------------
# % The routine computes the moments up to degree m of a total-degree product 
# % Chebyshev basis with respect to the Lebesgue measure in a Jordan spline 
# % polygon, whose boundary is given by the counterclockwise concatened 
# % spline arcs (Sx,Sy).
# %--------------------------------------------------------------------------
# % INPUT:
# %--------------------------------------------------------------------------
# % n: polynomial degree
# % Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
# % the arcs must be counterclockwise concatenated forming a Jordan curve
# % Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
# % i=1,...,end, with end+1:=1
# %--------------------------------------------------------------------------
# % OUTPUT:
# %--------------------------------------------------------------------------
# % cmom: array of bivariate Chebyshev moments
# % bbox: bounding box for the spline polygon
# %--------------------------------------------------------------------------
# % DATA:
# %--------------------------------------------------------------------------
# % built: March 2019
# % check: May 2, 2019
# % modified: October 21, 2025
# %--------------------------------------------------------------------------
# % Note. From this routine, we compute the approximation of a rectangle bbox
# % that is a bounding box for the spline polygon. For low "n" such rectangle
# % may not be good enough. Thus, in this case, we increase a little the 
# % degree so to be acceptable. 
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# %--------------------------------------------------------------------------
# % License:
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 22, 2025
# %--------------------------------------------------------------------------


    # Compute the line integral (or equivalent function)
    xyw = lineint(n, Sx, Sy)

    

    # Compute the bounding box (bbox)
    bbox = [np.min(xyw[:, 0]), np.max(xyw[:, 0]), np.min(xyw[:, 1]), np.max(xyw[:, 1])]
    #print('bbox', bbox)

    # Perform the integration or transformation
    intV = intcvand(n, xyw[:, :2], bbox)

    # Compute the weighted sum (cmom)
    cmom = intV.T @ xyw[:, 2]

    return cmom,bbox


def get_spline_degree(spline):
    if isinstance(spline, CubicSpline):
        deg=4  # CubicSpline always means degree 3
    elif isinstance(spline, BSpline):
        deg=spline.k  # spline.k is the degree
    else:
        deg = spline.c.shape[0]#raise TypeError("Unsupported spline type")
    return deg

#==========================================================================
# lineint
#==========================================================================

def lineint(m,Sx,Sy):

    # OBJECT:
    # computes weights and nodes for the line integral on concatenated 
    # spline arcs; the formula is exact on bivariate polynomials up to deg m
    #
    # INPUT:
    # m = polynomial degree to be integrated, via its x-primitive, on the
    #     spline-curvilinear domain.
    # Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
    # the arcs must be concatenated
    # Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
    #
    # OUTPUT:
    # xyw: 3-column array of nodes coords (cols 1-2) and weights (col 3)


    xyw = []
    
    # Supponiamo che Sx e Sy siano liste di spline (SciPy CubicSpline o PPoly)
    for i in range(len(Sx)):
        ord_spline = Sx[i].c.shape[0]  # numero di coefficienti = ordine
        degree = ord_spline - 1
    
        # Gauss-Legendre nodes and weights
        k = int(np.ceil(((degree) * (m+2)) / 2) + 2)
        t, w = np.polynomial.legendre.leggauss(k)
    
        # intervalli di rottura
        a = Sx[i].x[:-1]
        b = Sx[i].x[1:]
        alpha = (b - a) / 2
        beta = (b + a) / 2
    
        dSy = Sy[i].derivative()
    
        for j in range(len(a)):
            nodes = alpha[j] * t + beta[j]
            wloc = w * alpha[j]
    
            xvals = Sx[i](nodes)
            yvals = Sy[i](nodes)
            dyvals = dSy(nodes)
    
            block = np.column_stack([xvals, yvals, wloc * dyvals])
            xyw.append(block)
    
    # Concatenazione finale
    xyw = np.vstack(xyw)
    return xyw


#==========================================================================
# intcvand
#==========================================================================

def intcvand(n,pts,bbox):

    # computes by recurrence an x-primitive Chebyshev-Vandermonde matrix on a
    # 2d arbitrarily located mesh, in a total-degree product Chebyshev basis
    # of a given rectangle


    # INPUT:
    # n: polynomial degree
    # pts: 2-column array of mesh point coordinates
    # bbox: [bbox(1),bbox(2)] x [bbox(3),bbox(4)] bounding box for the mesh

    # OUTPUT:
    # intV: x-primitive of the Chebyshev-Vandermonde matrix


    # default rectangle containing the mesh if not passed

    if not bbox:
        bbox=[np.min(pts[:,0]), np.max(pts[:,0]), np.min(pts[:,1]), np.max(pts[:,1])];
    #end

    a=bbox[0];
    b=bbox[1];
    c=bbox[2];
    d=bbox[3];

    Vx=chebpolys(n+1,(2*pts[:,0]-b-a)/(b-a));
    Vy=chebpolys(n,(2*pts[:,1]-d-c)/(d-c));
    
    
    intV = np.zeros((pts.shape[0], (n+1)*(n+2)//2))
    k=0;
    for i in range(n+1):
        for j in range(n-i+1):
            k=k+1;

            if i==0:
                intV[:,k-1]=pts[:,0]*Vy[:,j];
            #end

            if i==1:
                intV[:,k-1]=0.25*(b-a)*(((2*pts[:,0]-b-a)/(b-a))**2)*Vy[:,j];
            #end

            if i>1:
                intV[:,k-1]=0.25*(b-a)*(Vx[:,i+1]*Vy[:,j]/(i+1)-Vx[:,i-1]*Vy[:,j]/(i-1));
            #end

        #end
    #end
    return intV


#==========================================================================
#gauss & r_jacobi
#==========================================================================
def gauss(N,ab):
    
    N0=np.shape(ab)[0]; 
    if N0<N:
           raise ValueError('input array ab too short')
       #end
    N=int(N)
    J=np.zeros((N,N));
    for n in range(N):
           J[n,n]=ab[n,0]; 
       #end
    for n in range(1, N):
           J[n,n-1]=np.sqrt(ab[n,1]);
           J[n-1,n]=J[n,n-1];
       #end
    D, V = np.linalg.eig(J)  # Compute eigenvalues (D) and eigenvectors (V)

    # Sort eigenvalues and rearrange eigenvectors accordingly
    I = np.argsort(D)        # Get the sorted indices of eigenvalues
    D = D[I]                 # Reorder eigenvalues
    V = V[:, I]              # Reorder eigenvectors
    xw=[D , ab[0,1]*np.transpose(V[0,:])**2];

    return xw


# In[9]:


# ...................... ORTH. POLY. RECURSION  ......................... 

def r_jacobi(N,a,b):
    nu = (b - a) / (a + b + 2)

    # Compute mu based on the given conditions
    if a + b + 2 > 128:
        mu = np.exp((a + b + 1) * np.log(2) + (gammaln(a + 1) + gammaln(b + 1) - gammaln(a + b + 2)))
    else:
        mu = 2**(a + b + 1) * (gamma(a + 1) * gamma(b + 1) / gamma(a + b + 2))

    # Handle N=1 case
    if N == 1:
        return np.array([[nu, mu]])

    # Compute coefficients
    N -= 1
    N=int(N)
    n = np.arange(1, N + 1)
    nab = 2 * n + a + b
  
    A = np.hstack([[nu], (b**2 - a**2) * np.ones(N) / (nab * (nab + 2))])

    # Compute B coefficients
    nab = nab[1:] 
    B1 = 4 * (a + 1) * (b + 1) / ((a + b + 2)**2 * (a + b + 3))
    B = 4 * (n[1:] + a) * (n[1:] + b) * n[1:] * (n[1:] + a + b) / (nab**2 * (nab + 1) * (nab - 1))

    # Construct final coefficient matrix
    ab = np.column_stack([A, np.hstack([[mu], B1, B])])
    return ab








#==========================================================================
# cvand
#==========================================================================

def cvand(n,pts,bbox):

    # OBJECT:
    # computes by recurrence the Chebyshev-Vandermonde matrix on a 2d
    # arbitrarily located mesh, in a total-degree product Chebyshev basis
    # of a given rectangle
    #
    # INPUT:
    # n: polynomial degree
    # pts: 2-column array of mesh point coordinates
    # bbox: [bbox(1),bbox(2)] x [bbox(3),bbox(4)] bounding box for the mesh
    #
    # OUTPUT:
    # V: Chebyshev-Vandermonde matrix
    #



    # default rectangle containing the mesh if not passed
    if not bbox:
        bbox=[np.min(pts[:,0]), np.max(pts[:,0]), np.min(pts[:,1]), np.max(pts[:,1])];
    #end

    a=bbox[0];
    b=bbox[1];
    c=bbox[2];
    d=bbox[3];

    Vx=chebpolys(n,(2*pts[:,0]-b-a)/(b-a));
    Vy=chebpolys(n,(2*pts[:,1]-d-c)/(d-c));

    k=0;
    for i in range(n):
        for j in range(n-1):
            k=k+1;
            V[:,k]=Vx[:,i+1]*Vy[:,j+1];
        #end
    #end

    return V




#==========================================================================
# chebpolys
#==========================================================================

def chebpolys(deg,x):

    # OBJECT:
    # computes the Chebyshev-Vandermonde matrix on the real line by recurrence
    #
    # INPUT:
    # deg = maximum polynomial degree
    # x = 1-column array of abscissas
    #
    # OUTPUT
    # T: Chebyshev-Vandermonde matrix at x, T(i,j+1)=T_j(x_i), j=0,...,deg


    T = np.zeros((len(x), deg + 1))
    T[:, 0] = np.ones(len(x))
    T[:, 1] = x

    for j in range(2, deg + 1):
        T[:, j] = 2 * x * T[:, j-1] - T[:, j-2]
    #end

    return T

