import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
from scipy.special import roots_legendre
from scipy.special import gamma, gammaln
from scipy.linalg import qr
from scipy.optimize import lsq_linear
from scipy.optimize import nnls




from matplotlib.path import Path
from scipy.spatial.distance import cdist


from incurvpolygon import *
from LHDM import *
from spline_chebmom import *



def splcub(n,Sx,Sy,extraction_type=1):

    
    

# %--------------------------------------------------------------------------
# % OBJECT:
# %--------------------------------------------------------------------------
# % it computes an algebraic formula with positive weights and interior nodes
# % for degree of exactness n with respect to the Lebesgue measure in a
# % Jordan spline polygon, whose boundary is given by the counterclockwise
# % concatened spline arcs (Sx,Sy)
# %--------------------------------------------------------------------------
# % INPUT:
# %--------------------------------------------------------------------------
# % n: polynomial degree
# % Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
# % the arcs must be counterclockwise concatenated forming a Jordan curve
# % Sx(i).breaks(end)=Sx(i+1).breaks(1),Sy(i).breaks(end)=Sy(i+1).breaks(1)
# % i=1,...,end, with end+1:=1
# % extraction_type: 1: lsqnonneg, 2: fast lawson-hanson 3: backslash
# %--------------------------------------------------------------------------
# % OUTPUT:
# %--------------------------------------------------------------------------
# % xyw: 3-column array of nodes coords (cols 1-2) and weights (col 3)
# % res: norm 2 of compressed moments vs moments
# % Zin: internal points
# % Z  : all analysed points
# % cmom: Chebyshev-Vandermonde moments
# % bbox: 
# %--------------------------------------------------------------------------
# % DATA:
# %--------------------------------------------------------------------------
# % built: April 2019
# % modified: October 21, 2025
# %--------------------------------------------------------------------------
# % CODE VERSION:
# %--------------------------------------------------------------------------
# % v: 11.0.1 (conditioning issues)
# % v: 11.0.2 (some minor bugs for low degrees)
# %--------------------------------------------------------------------------
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# % License:
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 25, 2025
# %--------------------------------------------------------------------------



# ....................... troubleshooting .................................
    # Initialize parameters
    alpha = 1.5
    beta = 1.5

    k = int(np.floor(max(n, 5)**alpha))
    restol = 1e-14

    Z = []      # all points
    Zin = []    # points inside the domain
    V = []      # Vandermonde matrix

    Lmax = 6   # max number of sublevels

    # ........................ exact moments .........................
    cmom, bbox = spline_chebmom(n, Sx, Sy) 

    
    for i in range(Lmax):
        # .............. define local point set .....................
        x = np.linspace(bbox[0], bbox[1], k)
        y = np.linspace(bbox[2], bbox[3], k)
        
        u, v = np.meshgrid(x, y)
        ZL = np.column_stack((u.ravel(), v.ravel()))


        #ZL = np.column_stack([u.flatten(), v.flatten()])
        ZL=ZL[np.lexsort((ZL[:, 1], ZL[:, 0]))]
       



        # .................... check inside domain ..................
        inside, onL= incurvpolygon(ZL, Sx, Sy)  

       
        
        ind =  ((inside == 1) & np.isnan(onL)).flatten()

        X = ZL[ind, :]

            
        if len(X) == 0:
            k = int(np.floor(beta * (k + 1)))
        else:
        

            if i ==0:
                Zin=X
                VL = cvand(n, X, bbox)  # function must return Vandermonde matrix
                V=VL
                Z=ZL 
            else:
                Zin = np.vstack([Zin, X]) 
                VL = cvand(n, X, bbox)
                V = np.vstack([V, VL]) 
                Z = np.vstack([Z, ZL]) 
          

            Q,R=qr(V, mode='economic')
  
            cmom1 =  np.linalg.solve(R.T, cmom) #np.linalg.pinv(R.T) @ cmom  #np.linalg.solve(R.T, cmom)


            # .................... weight extraction .....................
            if extraction_type == 1:
                w, rnorm = nnls(Q.T, cmom1)# Nonnegative least squares

            elif extraction_type == 2:
                w = LHDM(Q.T, cmom1)  # Assuming lawsonhanson is implemented  LHDM

            else:
                w = np.linalg.solve(Q.T, cmom1,  bounds=(0, np.inf))

            
            ind1 = np.where(np.abs(w) > 0)[0]
            w = w[ind1]
            
            #res = np.linalg.norm(np.vstack(V)[ind1].T @ w - cmom)
            res = np.linalg.norm(V[ind1,:].T @ w - cmom)

            
            if  (np.any(res > restol)) and (len(w) == 0):
                k = int(np.floor(beta * k))
            else:
                xyw = np.column_stack([np.vstack(Zin)[ind1], w])

                

    #print(f"\n\t Compression not completed. Moment error: {res:.3e}") 

    xyw = np.column_stack([np.vstack(Zin)[ind1], w])
    return xyw, res, Z, np.vstack(Zin), cmom, bbox


















#==========================================================================
# ADDITIONAL ROUTINES
#==========================================================================


#==========================================================================
# cvand
#==========================================================================

def  cvand(n,pts,bbox): #ok

# OBJECT:
# computes by recurrence the Chebyshev-Vandermonde matrix on a 2d
# arbitrarily located mesh, in a total-degree product Chebyshev basis
# of a given rectangle
#
# INPUT:
# n: polynomial degree
# pts: 2-column array of mesh point coordinates
# bbox: [bbox(1),bbox(2)] x [bbox(3),bbox(4)] bounding box for the mesh
#
# OUTPUT:
# V: Chebyshev-Vandermonde matrix
#


# default rectangle containing the mesh if not passed
    if not bbox:
        bbox=[np.min(pts[:,0]), np.max(pts[:,0]), np.min(pts[:,1]), np.max(pts[:,1])];
    #end

    a=bbox[0];
    b=bbox[1];
    c=bbox[2];
    d=bbox[3];

    Vx=chebpolys(n,(2*pts[:,0]-b-a)/(b-a));
   
    Vy=chebpolys(n,(2*pts[:,1]-d-c)/(d-c));

    V = np.zeros((len(pts), (n+1)*(n+2)//2)) 
    k=0;
    for i in range(n+1):
        for j in range(n-i +1):
           
            V[:, k] = Vx[:, i] * Vy[:, j]
            k=k+1
        #end
    #end
    

    return V
#==========================================================================
# chebpolys
#==========================================================================

def chebpolys(deg,x):

# OBJECT:
# computes the Chebyshev-Vandermonde matrix on the real line by recurrence
#
# INPUT:
# deg = maximum polynomial degree
# x = 1-column array of abscissas
#
# OUTPUT
# T: Chebyshev-Vandermonde matrix at x, T(i,j+1)=T_j(x_i), j=0,...,deg
#


# inizialization
    T = np.zeros((len(x), deg + 1))
    t0 = np.ones(len(x))
    T[:, 0] = t0
    t1 = x
    T[:, 1] = t1

    # 3-term recurrence
    for j in range(2, deg + 1):  # Adjust indexing for Python
        t2 = 2 * x * t1 - t0
        T[:, j] = t2
        t0, t1 = t1, t2 
        #end

    return T



#==========================================================================
# chebmom
#==========================================================================

def chebmom(n,Sx,Sy):  

# OBJECT:
# computes the moments up to degree m of a total-degree product Chebyshev
# basis with respect to the Lebesgue measure in a Jordan spline polygon,
# whose boundary is given by the counterclockwise concatened spline
# arcs (Sx,Sy)
#
# INPUT:
# n: polynomial degree
# Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
# the arcs must be counterclockwise concatenated forming a Jordan curve
# Sx(i).breaks(#end)=Sx(i+1).breaks(1),Sy(i).breaks(#end)=Sy(i+1).breaks(1)
# i=1,...,#end, with #end+1:=1

# OUTPUT:
# cmom: array of bivariate Chebyshev moments
# bbox: bounding box for the spline polygon
#


# Note. From this routine, we compute the approximation of a rectangle bbox
# that is a bounding box for the spline polygon. For low "n" such rectangle
# may not be good enough. Thus, in this case, we increase a little the 
# degree so to be acceptable. 

                     
    xyw = lineint(n, Sx, Sy)

    

    # Compute the bounding box (bbox)
    bbox = [np.min(xyw[:, 0]), np.max(xyw[:, 0]), np.min(xyw[:, 1]), np.max(xyw[:, 1])]
    

    # Perform the integration or transformation
    intV = intcvand(n, xyw[:, :2], bbox)

    # Compute the weighted sum (cmom)
    cmom = intV.T@ xyw[:, 2]
   

    return cmom, bbox


#==========================================================================
# lineint
#==========================================================================

def lineint(m,Sx,Sy): 

# OBJECT:
# computes weights and nodes for the line integral on concatenated 
# spline arcs; the formula is exact on bivariate polynomials up to deg m
#
# INPUT:
# m = polynomial degree to be integrated, via its x-primitive, on the
#     spline-curvilinear domain.
# Sx,Sy: arrays of spline structures; (SX(i),Sy(i)) is the i-th arc
# the arcs must be concatenated
# Sx(i).breaks(#end)=Sx(i+1).breaks(1),Sy(i).breaks(#end)=Sy(i+1).breaks(1)
#
# OUTPUT:
# xyw: 3-column array of nodes coords (cols 1-2) and weights (col 3)
#


    xyw=[];
    
    for i in range(len(Sx)):
        ord_spline = get_spline_degree(Sx[i])
        

        # Gauss-Legendre nodes in [-1,1] and corresponding weights on the side
        k = int(np.ceil(((ord_spline - 1) * (m + 2)) / 2)) + 2
        ab = r_jacobi(k, 0, 0)

        xw = gauss(k, ab)
        
       
        t = xw[:,0]  # Gauss nodes
        w = xw[:,1]  # Gauss weights


        a = Sx[i].x.T[:-1]  # Breaks for the current spline (excluding the last)
        b = Sx[i].x.T[1:]  # Breaks for the current spline (excluding the first)

        alpha = (b - a) / 2
        beta = (b + a) / 2
         # Placeholder for derivatives of Sy
        dSy_i= Sy[i].derivative()  # Derivative of Sy at index i
    
        for j in range(len(a)):
            # Nodes for the current interval based on Gauss-Legendre nodes
            nodes = alpha[j] * t + beta[j]

            # Adjust the weights for the current interval
            wloc = w * alpha[j]

            # Evaluate the splines and accumulate the values into xyw
            sx_values = Sx[i](nodes)  # Assuming Sx[i] is callable
            sy_values = Sy[i](nodes)
            dsy_values = dSy_i(nodes)

            # Concatenate new values
            new_row = np.column_stack((sx_values, sy_values, wloc * dsy_values))
            xyw.append((new_row))

    return np.vstack(xyw)

def get_spline_degree(spline):
    if isinstance(spline, CubicSpline):
        deg=4  # CubicSpline always means degree 3

    elif isinstance(spline, BSpline):
        deg=spline.k  # spline.k is the degree
    else:
        deg = spline.c.shape[0] #raise TypeError("Unsupported spline type")
       # print(deg, np.shape(spline.c))
    return deg
   
#==========================================================================
# intcvand
#==========================================================================

def  intcvand(n,pts,bbox):

# computes by recurrence an x-primitive Chebyshev-Vandermonde matrix on a
# 2d arbitrarily located mesh, in a total-degree product Chebyshev basis
# of a given rectangle

# March 2019

# INPUT:
# n: polynomial degree
# pts: 2-column array of mesh point coordinates
# bbox: [bbox(1),bbox(2)] x [bbox(3),bbox(4)] bounding box for the mesh

# OUTPUT:
# intV: x-primitive of the Chebyshev-Vandermonde matrix


# default rectangle containing the mesh if not passed

    if not bbox:
        bbox=[np.min(pts[:,0]), np.max(pts[:,0]), np.min(pts[:,1]), np.max(pts[:,1])];
    #end

    a=bbox[0];
    b=bbox[1];
    c=bbox[2];
    d=bbox[3];

    Vx=chebpolys(n+1,(2*pts[:,0]-b-a)/(b-a));
    Vy=chebpolys(n,(2*pts[:,1]-d-c)/(d-c));
    
    
    intV = np.zeros((pts.shape[0], (n+1)*(n+2)//2))
    k=0;
    for i in range(n+1):
        for j in range(n-i+1):
            k=k+1;

            if i==0:
                intV[:,k-1]=pts[:,0]*Vy[:,j];
            #end

            if i==1:
                intV[:,k-1]=0.25*(b-a)*(((2*pts[:,0]-b-a)/(b-a))**2)*Vy[:,j];
            #end

            if i>1:
                intV[:,k-1]=0.25*(b-a)*(Vx[:,i+1]*Vy[:,j]/(i+1)-Vx[:,i-1]*Vy[:,j]/(i-1));
            #end

        #end
    #end
    return intV 
#==========================================================================
# gauss &  r_jacobi
#==========================================================================
# ...................... GAUSSIAN RULE  ......................... 

   # GAUSS Gauss quadrature rule.
   #
   #    Given a weight function w encoded by the nx2 array ab of the
   #    first n recurrence coefficients for the associated orthogonal
   #    polynomials, the first column of ab containing the n alpha-
   #    coefficients and the second column the n beta-coefficients,
   #    the call xw=GAUSS(n,ab) generates the nodes and weights xw of
   #    the n-point Gauss quadrature rule for the weight function w.
   #    The nodes, in increasing order, are stored in the first
   #    column, the n corresponding weights in the second column, of
   #    the nx2 array xw.
   #


def gauss(N,ab):
    
    N0 = ab.shape[0]
    if N0 < N:
        raise ValueError("Input array ab too short")

    # Construct Jacobi matrix J
    J = np.zeros((N, N))
    for n in range(N):
        J[n, n] = ab[n, 0]

    for n in range(1, N):
        J[n, n - 1] = np.sqrt(ab[n, 1])
        J[n - 1, n] = J[n, n - 1]

    # Compute eigenvalues and eigenvectors
    D, V = np.linalg.eig(J)

    # Sort eigenvalues and reorder eigenvectors
    I = np.argsort(D)
    D = D[I]
    V = V[:, I]

    # Compute quadrature weights
    xw = np.column_stack((D, ab[0, 1] * (V[0, :] ** 2)))

    return xw


# In[9]:


# ...................... ORTH. POLY. RECURSION  ......................... 

def r_jacobi(N,a,b):
    nu = (b - a) / (a + b + 2)

    # Compute mu based on the given conditions
    if a + b + 2 > 128:
        mu = np.exp((a + b + 1) * np.log(2) + (gammaln(a + 1) + gammaln(b + 1) - gammaln(a + b + 2)))
    else:
        mu = 2**(a + b + 1) * (gamma(a + 1) * gamma(b + 1) / gamma(a + b + 2))

    # Handle N=1 case
    if N == 1:
        return np.array([[nu, mu]])

    # Compute coefficients
    N -= 1
    N=int(N)
    n = np.arange(1, N + 1)
    nab = 2 * n + a + b
  
    A = np.hstack([[nu], (b**2 - a**2) * np.ones(N) / (nab * (nab + 2))])

    # Compute B coefficients
    nab = nab[1:] 
    B1 = 4 * (a + 1) * (b + 1) / ((a + b + 2)**2 * (a + b + 3))
    B = 4 * (n[1:] + a) * (n[1:] + b) * n[1:] * (n[1:] + a + b) / (nab**2 * (nab + 1) * (nab - 1))

    # Construct final coefficient matrix
    ab = np.column_stack([A, np.hstack([[mu], B1, B])])
    return ab






