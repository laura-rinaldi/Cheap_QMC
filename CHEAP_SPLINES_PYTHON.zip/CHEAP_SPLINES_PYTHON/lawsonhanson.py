from pydantic import BaseModel, conlist, conint, confloat
from typing import List, Optional
import numpy as np

import time
#==========================================================================
# COMPRESSION OF A CUBATURE RULE BY FAST LAWSON-HANSON ALGORITHM
#==========================================================================
# INPUT
#==========================================================================
# A: cubature Vandermonde matrix,
# b: moments vector,
#==========================================================================
# OUTPUT
#==========================================================================
# weights: cbature weights.
#==========================================================================


def lawsonhanson(A, b):
    """
    Solves NNLS using Lawson-Hanson's algorithm.
    
    Parameters:
    - A: Coefficient matrix (numpy.ndarray)
    - b: Observation vector (numpy.ndarray)

    Returns:
    - weights: Optimal weights computed by the selected solver.
    """
    # Initialize options
    opt_gen1 = initopt_general(perfmeas=[1], maxcpu=50, stopcrit=[1], tol=[1e-16])

    subcase = 0

    if subcase == 1:
        weights_struct = lawsonhanson_main(A, b, opt_gen1, opt_lawsonhanson(up=0, down=0))
    elif subcase == 2:
        weights_struct = lawsonhanson_main(A, b, opt_gen1, opt_lawsonhanson(up=0, down=1))
    elif subcase == 3:
        weights_struct = lawsonhanson_main(A, b, opt_gen1, opt_lawsonhanson(up=1, down=0))
    elif subcase == 4:
        weights_struct = lawsonhanson_main(A, b, opt_gen1, opt_lawsonhanson(up=1, down=1))
    else:
        weights_struct = lawsonhanson_main(A, b, opt_gen1, opt_lawsonhanson())

    return weights_struct["xopt"]






def lawsonhanson_main(A, b, options_general, options_specific):
    """
    Main function to solve NNLS using different solvers based on input options.

    Parameters:
    - A: Matrix (numpy.ndarray)
    - b: Vector (numpy.ndarray)
    - options_general: Dictionary of general options.
    - options_specific: Dictionary of specific solver options.

    Returns:
    - Output from the selected solver.
    """
    print(options_general.perfmeas)
    # Ensure dimension compatibility
    
#     if max([np.shape(z) for z in options_general.perfmeas]) > A.shape[1]:
#         raise ValueError("Dimension mismatch of A and the minimizer x")

#     if np.array(options_general.stopcrit).shape != np.array(options_general.tol).shape:
#         raise ValueError("Structure of stopcrit not compatible with structure of tol")

    # Select the appropriate solver based on options
    if options_general.usegram:
        if options_specific.up:
            if options_specific.down == 0:
                out = fnnls_up(A, b, options_general, options_specific)
            elif options_specific.down == 1:
                out = fnnls_up_down(A, b, options_general, options_specific)
            elif options_specific.down == 2:
                out = fnnls_up_down_c(A, b, options_general, options_specific)
        else:
            out = fnnls_pure(A, b, options_general, options_specific)
    else:
        if options_specific.up:
            if options_specific.down == 0:
                out = lsqnnls_up(A, b, options_general, options_specific)
            elif options_specific.down == 1:
                out = lsqnnls_up_down(A, b, options_general, options_specific)
            elif options_specific.down == 2:
                out = lsqnnls_up_down_c(A, b, options_general, options_specific)
        else:
            out = lsqnnls_pure(A, b, options_general, options_specific)

    return out





#==========================================================================
#
# ADDITIONAL ROUTINES.
#
# 0. function options = initopt_general(varargin)
# 1. function options = opt_lawsonhanson(varargin)
# 2. function [out] = fnnls_pure(A, b, options_general, options_specific)
# 3. function [out] = fnnls_up_down_c(A, b, options_general, options_specific)
# 4. function [out] = fnnls_up_down(A, b, options_general, options_specific)
# 5. function [out] = fnnls_up(A, b, options_general, options_specific)
# 6. function [out] = lsqnnls_pure(A, b, options_general, options_specific)
# 7. function [out] = fnnls_up_down_c(A, b, options_general, options_specific)
# 8. function [out] = lsqnnls_up_down(A, b, options_general, options_specific)
# 9. function [out] = lsqnnls_up(A, b, options_general, options_specific)
#==========================================================================








#==========================================================================
#
# 1. function options = opt_lawsonhanson(varargin)
#
#==========================================================================

# Function to set-up options specific to
# the Lawson-Hanson algorithm
#
# Inputs
#
# 'up'  --- Updating of the Cholesky factorization
#           is done ('up' = 1) or not done ('up' = 0).
#           In the second case, a Cholesky factorization
#           is re-computed from scratch each time
#           a new variable is added into the active set.
#
# 'down' --- Downdating of the Cholesky factorization
#            is done using MATLAB code ('down' = 1),
#            C-code ('down' = 2) or not done ('down' = 0).
#
# 'outeritmax' --- maximum number of outer iterations (integer).
#                  default: 'inf'
#
# 'inneritmax' --- maximum number of inner iterations (integer).
#                  default: 'inf'


class Options(BaseModel):
    up: conint(ge=0, le=1) = 1  # Binary integer (0 or 1)
    down: conint(ge=0, le=2) = 1  # Integer between 0 and 2
    outeritmax: conint(gt=0) = float('inf')  # Positive integer
    inneritmax: conint(gt=0) = float('inf')  # Positive integer

def opt_lawsonhanson(**kwargs):
    options = Options(**kwargs)

    # Ensure that up is set to 1 if down is not 0
    if options.down != 0 and options.up == 0:
        options.up = 1

    return options







#==========================================================================
#
# 2. function [out] = fnnls_pure(A, b, options_general, options_specific)
#
#==========================================================================

# *internal code not to be called directly by the user*
def fnnls_pure(A, b, options_general, options_specific):
    """Solves NNLS using Lawson-Hanson's algorithm with stored Gram matrix."""
    t0 = time.time()
    
    n, d = A.shape
    AtA, Atb = (A, b) if options_general.mode else (A.T @ A, A.T @ b)

    mv = options_general.mv if options_general.mv != 0 else (2 if 1.1 * 2 * n < d else 1)

    if not options_general.mode and options_general.gram is not None:
        AtA = options_general.gram
        if AtA.shape != (d, d):
            raise ValueError("Wrong input for the Gram matrix")
        options_general.gram = None

    f = lambda x: x.T @ (AtA @ x - 2 * Atb) if options_general.mode else np.linalg.norm(A @ x - b) ** 2

    P = np.zeros(d, dtype=bool)
    Z = np.ones(d, dtype=bool)
    x = np.zeros(d)

    w = Atb
    wz = np.zeros(d)

    outeriter, iter = 1, 0
    outeritmax, itmax = options_specific["outeritmax"], options_specific["inneritmax"]

    perf = getL(options_general["perfmeas"], -w, x)
    check = check_termination(t0, options_general, perf, -w, x, float("inf"), x + float("inf"))
    ConvSpeed = [[0, perf]]

    if check["stop"]:
        return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

    while np.any(Z) and np.any(w[Z] > np.finfo(float).eps) and not check["stop"]:
        if outeriter == outeritmax:
            print("Exiting: Outer iteration count is exceeded.")
            break

        outeriter += 1
        z = np.zeros(d)
        wz[P] = -np.inf
        wz[Z] = w[Z]

        t = np.argmax(wz)
        P[t], Z[t] = True, False
        z[P] = np.linalg.lstsq(A[:, P], b, rcond=None)[0]

        while np.any(z[P] <= np.finfo(float).eps):
            iter += 1
            if iter > itmax:
                print("Exiting: Inner iteration count exceeded.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            Q = (z <= np.finfo(float).eps) & P
            alpha = np.min(x[Q] / (x[Q] - z[Q])) if np.any(Q) else 0
            if not np.isfinite(alpha):
                print("Warning: No strictly positive step size found.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            x += alpha * (z - x)
            Z = ((np.abs(x) < np.finfo(float).eps) & P) | Z
            P = ~Z
            z = np.zeros(d)
            z[P] = np.linalg.lstsq(A[:, P], b, rcond=None)[0]

        x = z
        w = Atb - AtA[:, P] @ x[P] if mv == 1 else A.T @ (b - A[:, P] @ x[P])

        perf = getL(options_general["perfmeas"], -w, x)
        check = check_termination(t0, options_general, perf, -w, x, check["fprev"], check["xprev"])
        ConvSpeed.append([time.time() - t0, perf])

    return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

def getL(perfmeas, grad, x):
    """
    Computes performance measures.

    Parameters:
    - perfmeas: List of performance measures.
    - grad: Gradient vector.
    - x: Solution vector.
    - f: Objective function.

    Returns:
    - perf: List containing performance metrics [KKT, objective, error].
    """
    global f
    perf = [np.nan] * 3  # Initialize list with NaN values

    for i in range(len(perfmeas)):
        if isinstance(perfmeas[i], list) and len(perfmeas[i]) > 1:
            perf[2] = getd(x, perfmeas[i])  # Assuming getd() is a separate function
        elif isinstance(perfmeas[i], int) and len([perfmeas[i]]) == 1:
            if perfmeas[i] == 1:
                perf[0] = getkktopt(grad, x)  # Assuming getkktopt() is available
            elif perfmeas[i] == 2:
                perf[1] = f(x)
        else:
            continue

    return perf


def getkktopt(grad, x, eps=np.finfo(float).eps):
    """
    Computes the KKT optimality score.

    Parameters:
    - grad: Gradient vector.
    - x: Solution vector.
    - eps: Small positive threshold to handle numerical precision.

    Returns:
    - kktopt: Maximum KKT optimality score.
    """
    num = np.abs(grad) * (grad > eps)
    score = num.copy()

    Pc = num < eps

    if np.any(Pc):
        score[Pc] = num[Pc]

    if np.any(~Pc):
        score[~Pc] = num[~Pc] / x[~Pc]

    Pc = (num < eps) | (score < 1)
    P = ~Pc

    kktP = np.max(np.abs(x[P])) if np.any(P) else 0
    kktPc = np.max(np.abs(grad[Pc])) if np.any(Pc) else 0
    N = x < -eps
    kktN = np.max(np.abs(x[N])) if np.any(N) else 0

    return max(kktP, kktPc, kktN)




# t0 -- cputime at the beginning
# options_general
# perf -- after calling function for performance measures
# grad --- gradient
# x --- current iterate
# fprev --- objective at previous iteration
# xprev --- iterate at previous iteration

def check_termination(t0, options_general, perf, grad, x, fprev, xprev):
    """
    Determines termination conditions based on various criteria.

    Parameters:
    - t0: Start time.
    - options_general: Dictionary containing termination criteria.
    - perf: Performance metrics.
    - grad: Gradient values.
    - x: Current solution estimate.
    - fprev: Previous objective value.
    - xprev: Previous solution estimate.
    - f: Objective function.

    Returns:
    - Dictionary containing termination status and reasons.
    """
    global f
    reason = []
    tolreturn = []
    fcur = np.inf

    stop = 0
    if time.time() - t0 > options_general.maxcpu:
        stop = 1
        reason.append(0)  # Reason 0: Max CPU time exceeded

    stopcrit = options_general.stopcrit
    tol = options_general.tol
    nr, nc = np.shape(np.array(stopcrit))[0] , np.shape(np.array(stopcrit))[0] #laura

    for i in range(nr):
        tempstop = np.zeros(nc, dtype=int)

        for j in range(nc):
            critnumber = stopcrit[i]#[j] laura
            tolval = tol[i]#[j]

            if not np.isnan(perf[critnumber]):
                if critnumber == 1 and perf[critnumber] < tolval:
                    tolreturn.append(perf[critnumber])
                    tempstop[j] = 1
                    reason.append(1)
                elif critnumber == 2:
                    fcur = perf[critnumber]
                    relobj = fprev - fcur
                    if relobj < tolval:
                        tempstop[j] = 1
                        reason.append(2)
                        tolreturn.append(relobj)
                elif critnumber == 3:
                    relx = np.linalg.norm(x - xprev) / np.linalg.norm(0.5 * (x + xprev))
                    if relx < tolval:
                        tempstop[j] = 1
                        reason.append(3)
                        tolreturn.append(relx)
            else:
                if critnumber == 1:
                    kktopt = getkktopt(grad, x)
                    if kktopt < tolval:
                        tempstop[j] = 1
                        reason.append(1)
                        tolreturn.append(kktopt)
                elif critnumber == 2:
                    fcur = f(x)
                    relobj = fprev - fcur
                    if relobj < tolval:
                        tempstop[j] = 1
                        reason.append(2)
                        tolreturn.append(relobj)
                elif critnumber == 3:
                    relx = np.linalg.norm(x - xprev) / np.linalg.norm(0.5 * (x + xprev))
                    if relx < tolval:
                        tempstop[j] = 1
                        reason.append(3)
                        tolreturn.append(relx)

        if np.all(tempstop == 1):
            stop = 1

    sorted_indices = np.argsort(reason)
    sorted_reasons = np.array(reason)[sorted_indices]

    check = {
        "stop": stop,
        "reason": sorted_reasons.tolist(),
        "tol": [tolreturn[i] for i in sorted_indices if sorted_reasons[i] != 0] if tolreturn else [],
        "xprev": x,
        "fprev": fcur
    }

    return check












#==========================================================================
#
# * 3. function [out] = fnnls_up_down_c(A, b, options_general, options_specific)
#
#==========================================================================

# *internal code not to be called directly by the user*


def fnnls_up_down_c(A, b, options_general, options_specific):
    """Solves NNLS using Lawson-Hanson's algorithm with Cholesky updating/downdating."""
    t0 = time.time()
    
    n, d = A.shape
    AtA, Atb = (A, b) if options_general.mode else (A.T @ A, A.T @ b)

    mv = options_general.mv if options_general.mv != 0 else (2 if 1.1 * 2 * n < d else 1)

    if not options_general.mode and options_general.gram is not None:
        AtA = options_general.ram
        if AtA.shape != (d, d):
            raise ValueError("Wrong input for the Gram matrix")
        options_general.gram = None

    f = lambda x: x.T @ (AtA @ x - 2 * Atb) if options_general.mode else np.linalg.norm(A @ x - b) ** 2

    P = np.zeros(d, dtype=bool)
    Z = np.ones(d, dtype=bool)
    x = np.zeros(d)

    w = Atb
    wz = np.zeros(d)

    outeriter, iter = 1, 0
    outeritmax, itmax = options_specific.outeritmax, options_specific.inneritmax

    perf = getL(options_general.perfmeas, -w, x)
    check = check_termination(t0, options_general, perf, -w, x, float("inf"), x + float("inf"))
    ConvSpeed = [[0, perf]]

    if check.stop:
        return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

    while np.any(Z) and np.any(w[Z] > np.finfo(float).eps) and not check["stop"]:
        if outeriter == outeritmax:
            print("Exiting: Outer iteration count is exceeded.")
            break

        outeriter += 1
        wz[P] = -np.inf
        wz[Z] = w[Z]

        k = np.argmax(wz)
        P[k], Z[k] = True, False
        sizePnew = np.sum(P)

        xnew = np.zeros(d)
        if sizePnew == 1:
            Lt = np.array([[np.sqrt(AtA[k, k])]])
            y = np.array([Atb[k] / Lt[0, 0]])
            xnew[k] = y[0] / Lt[0, 0]
        else:
            l = np.linalg.solve(Lt[:sizePnew-1, :sizePnew-1].T, AtA[P, k])
            lkk = np.sqrt(AtA[k, k] - np.dot(l, l))
            Lt = np.vstack([Lt, np.zeros((1, sizePnew))])
            Lt[:, sizePnew - 1] = np.append(l, lkk)
            y = np.append(y, (Atb[k] - np.dot(l, y[:sizePnew-1])) / lkk)
            xnew[P] = np.linalg.solve(Lt[:sizePnew, :sizePnew], y[:sizePnew])

        while np.any(xnew[P] <= np.finfo(float).eps):
            iter += 1
            if iter > itmax:
                print("Exiting: Inner iteration count exceeded.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            Q = (xnew <= np.finfo(float).eps) & P
            alpha = np.min(x[Q] / (x[Q] - xnew[Q])) if np.any(Q) else 0
            if not np.isfinite(alpha):
                print("Warning: No strictly positive step size found.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            x += alpha * (xnew - x)
            Z = ((np.abs(x) < np.finfo(float).eps) & P) | Z
            P = ~Z

            Lt = choldown(Lt, np.argmax(Q))

            sizePnew = np.sum(P)
            y = np.linalg.solve(Lt[:sizePnew, :sizePnew].T, Atb[P])
            xnew[P] = np.linalg.solve(Lt[:sizePnew, :sizePnew], y[:sizePnew])

        x = xnew
        w = Atb - AtA[:, P] @ x[P] if mv == 1 else A.T @ (b - A[:, P] @ x[P])

        perf = getL(options_general.perfmeas, -w, x)
        check = check_termination(t0, options_general, perf, -w, x, check.fprev, check.xprev)
        ConvSpeed.append([time.time() - t0, perf])

    return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}








#==========================================================================
#
# * 4. function [out] = fnnls_up_down(A, b, options_general, options_specific)
#
#==========================================================================

# *internal code not to be called directly by the user*


def fnnls_up_down(A, b, options_general, options_specific):
    """Solves NNLS using Lawson-Hanson's algorithm with Cholesky updating/downdating."""
    t0 = time.time()
    
    n, d = A.shape
    AtA, Atb = (A, b) if options_general.mode else (A.T @ A, A.T @ b)

    mv = options_general.mv if options_general.mv != 0 else (2 if 1.1 * 2 * n < d else 1)

    if not options_general.mode and options_general.gram is not None:
        AtA = options_general.gram
        if AtA.shape != (d, d):
            raise ValueError("Wrong input for the Gram matrix")
        options_general.gram = None

    f = lambda x: x.T @ (AtA @ x - 2 * Atb) if options_general.mode else np.linalg.norm(A @ x - b) ** 2

    P, Z = np.zeros(d, dtype=bool), np.ones(d, dtype=bool)
    Pnew, sizeP, sizePnew = P.copy(), 0, 0
    ltb, Lt, y = np.zeros(d), np.zeros((d, d)), np.zeros(d)
    x, xnew, w, wz = np.zeros(d), np.zeros(d), Atb, np.zeros(d)

    outeriter, iter = 1, 0
    outeritmax, itmax = options_specific.outeritmax, options_specific.inneritmax

    perf = getL(options_general.perfmeas, -w, x)
    check = check_termination(t0, options_general, perf, -w, x, float("inf"), x + float("inf"))
    ConvSpeed = [[0, perf]]

    if check.stop:
        return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

    while np.any(Z) and np.any(w[Z] > np.finfo(float).eps) and not check["stop"]:
        if outeriter == outeritmax:
            print("Exiting: Outer iteration count is exceeded.")
            break

        outeriter += 1
        wz[P] = -np.inf
        wz[Z] = w[Z]
        k = np.argmax(wz)
        Pnew[k], Z[k] = True, False
        sizePnew += 1
        ltb[sizePnew - 1] = k

        xnew.fill(0)
        if sizePnew == 1:
            Lt[0, 0] = np.sqrt(AtA[k, k])
            y[0] = Atb[k] / Lt[0, 0]
            xnew[k] = y[0] / Lt[0, 0]
        else:
            l = np.linalg.solve(Lt[:sizeP, :sizeP].T, AtA[ltb[:sizeP], k])
            lkk = np.sqrt(AtA[k, k] - np.dot(l, l))
            Lt[:sizeP, sizePnew - 1] = l
            Lt[sizePnew - 1, sizePnew - 1] = lkk
            y[sizePnew - 1] = (Atb[k] - np.dot(l, y[:sizeP])) / lkk
            xnew[ltb[:sizePnew]] = np.linalg.solve(Lt[:sizePnew, :sizePnew], y[:sizePnew])

        P, sizeP = Pnew.copy(), sizePnew

        while np.any(xnew[P] <= np.finfo(float).eps):
            iter += 1
            if iter > itmax:
                print("Exiting: Inner iteration count exceeded.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

        x = xnew
        w = Atb - AtA[:, P] @ x[P] if mv == 1 else A.T @ (b - A[:, P] @ x[P])

        perf = getL(options_general.perfmeas, -w, x)
        check = check_termination(t0, options_general, perf, -w, x, check.fprev, check.xprev)
        ConvSpeed.append([time.time() - t0, perf])

    return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}




def choldownmatlab1(Lt, k):
    """
    Performs Cholesky downdating by removing the k-th column from Lt.

    Parameters:
    Lt (numpy.ndarray): Upper triangular Cholesky factor (p x p).
    k (int): Index of column to remove.

    Returns:
    numpy.ndarray: Updated Cholesky factor.
    """
    p = Lt.shape[0]

    # Drop the k-th column
    Temp = np.delete(Lt, k, axis=1)  # Removes column k
    
    # Givens Rotations
    for i in range(k, p-1):
        a = Temp[i, i]
        b = Temp[i+1, i]
        r = np.sqrt(np.sum(Lt[:, i+1]**2) - np.sum(Temp[:i, i]**2))
        c = r * a / (a**2 + b**2)
        s = r * b / (a**2 + b**2)
        
        # Rotation matrix rows
        Hrowi = np.zeros(p)
        Hrowi[i] = c
        Hrowi[i+1] = s
        
        Hrowi1 = np.zeros(p)
        Hrowi1[i] = -s
        Hrowi1[i+1] = c
        
        # Modify rows of Temp
        v = np.zeros((2, p-1))
        v[0, i:p-1] = Hrowi @ Temp[:, i:p-1]
        v[1, i+1:p-1] = Hrowi1 @ Temp[:, i+1:p-1]
        Temp[i:i+2, :] = v

    # Drop last row
    Lkt = Temp[:p-1, :]
    
    return Lkt









#==========================================================================
#
# * 5. function [out] = fnnls_up(A, b, options_general, options_specific)
#
#==========================================================================

# *internal code not to be called directly by the user*
def fnnls_up(A, b, options_general, options_specific):
    """Solves NNLS using Lawson-Hanson's algorithm with Cholesky updating."""
    t0 = time.time()
    
    n, d = A.shape
    AtA, Atb = (A, b) if options_general.mode else (A.T @ A, A.T @ b)

    mv = options_general.mv if options_general.mv != 0 else (2 if 1.1 * 2 * n < d else 1)

    if not options_general.mode and options_general.gram is not None:
        AtA = options_general.gram
        if AtA.shape != (d, d):
            raise ValueError("Wrong input for the Gram matrix")
        options_general.gram = None

    f = lambda x: x.T @ (AtA @ x - 2 * Atb) if options_general.mode else np.linalg.norm(A @ x - b) ** 2

    P, Z = np.zeros(d, dtype=bool), np.ones(d, dtype=bool)
    Pnew, sizeP, sizePnew = P.copy(), 0, 0
    ltb, Lt, y = np.zeros(d), np.zeros((d, d)), np.zeros(d)
    x, xnew, w, wz = np.zeros(d), np.zeros(d), Atb, np.zeros(d)

    outeriter, iter = 1, 0
    outeritmax, itmax = options_specific.outeritmax, options_specific.inneritmax

    perf = getL(options_general.perfmeas, -w, x)
    check = check_termination(t0, options_general, perf, -w, x, float("inf"), x + float("inf"))
    ConvSpeed = [[0, perf]]

    if check.stop:
        return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

    while np.any(Z) and np.any(w[Z] > np.finfo(float).eps) and not check["stop"]:
        if outeriter == outeritmax:
            print("Exiting: Outer iteration count is exceeded.")
            break

        outeriter += 1
        wz[P] = -np.inf
        wz[Z] = w[Z]
        k = np.argmax(wz)
        Pnew[k], Z[k] = True, False
        sizePnew += 1
        ltb[sizePnew - 1] = k

        xnew.fill(0)
        if sizePnew == 1:
            Lt[0, 0] = np.sqrt(AtA[k, k])
            y[0] = Atb[k] / Lt[0, 0]
            xnew[k] = y[0] / Lt[0, 0]
        else:
            l = np.linalg.solve(Lt[:sizeP, :sizeP].T, AtA[ltb[:sizeP], k])
            lkk = np.sqrt(AtA[k, k] - np.dot(l, l))
            Lt[:sizeP, sizePnew - 1] = l
            Lt[sizePnew - 1, sizePnew - 1] = lkk
            y[sizePnew - 1] = (Atb[k] - np.dot(l, y[:sizeP])) / lkk
            xnew[ltb[:sizePnew]] = np.linalg.solve(Lt[:sizePnew, :sizePnew], y[:sizePnew])

        P, sizeP = Pnew.copy(), sizePnew

        while np.any(xnew[P] <= np.finfo(float).eps):
            iter += 1
            if iter > itmax:
                print("Exiting: Inner iteration count exceeded.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            Q = (xnew <= np.finfo(float).eps) & P
            alpha = np.min(x[Q] / (x[Q] - xnew[Q])) if np.any(Q) else 0
            if not np.isfinite(alpha):
                print("Warning: No strictly positive step size found.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            x += alpha * (xnew - x)
            Z = ((np.abs(x) < np.finfo(float).eps) & P) | Z
            P = ~Z
            Pnew = P.copy()

            xnew.fill(0)
            ltb.fill(0)
            y.fill(0)
            K = np.nonzero(P)[0]
            sizeP = len(K)
            sizePnew = sizeP
            ltb[:sizeP] = K

            Lt.fill(0)
            Lt[:sizeP, :sizeP] = np.linalg.cholesky(AtA[K, K])
            y[:sizeP] = np.linalg.solve(Lt[:sizeP, :sizeP].T, Atb[K])
            xnew[K] = np.linalg.solve(Lt[:sizeP, :sizeP], y[:sizeP])

        x = xnew
        w = Atb - AtA[:, P] @ x[P] if mv == 1 else A.T @ (b - A[:, P] @ x[P])

        perf = getL(options_general["perfmeas"], -w, x)
        check = check_termination(t0, options_general, perf, -w, x, check["fprev"], check["xprev"])
        ConvSpeed.append([time.time() - t0, perf])

    return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}


















#==========================================================================
#
# * 6. function [out] = lsqnnls_pure(A, b, options_general, options_specific)
#
#==========================================================================

# *internal code not to be called directly by the user*
def lsqnnls_pure(A, b, options_general, options_specific):
    """Solves NNLS using Lawson-Hanson's algorithm without Cholesky updates."""
    f = lambda x: np.linalg.norm(A @ x - b)**2
    t0 = time.time()

    n, d = A.shape
    x = np.zeros(d)

    P = np.zeros(d, dtype=bool)
    Z = np.ones(d, dtype=bool)
    wz = np.zeros(d)
    w = A.T @ b

    outeriter, iter = 1, 0
    outeritmax, itmax = options_specific["outeritmax"], options_specific["inneritmax"]

    perf = getL(options_general["perfmeas"], -w, x)
    check = check_termination(t0, options_general, perf, -w, x, float("inf"), x + float("inf"))
    ConvSpeed = [[0, perf]]

    if check["stop"]:
        return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

    while np.any(Z) and np.any(w[Z] > np.finfo(float).eps) and not check["stop"]:
        if outeriter == outeritmax:
            print("Exiting: Outer iteration count is exceeded.")
            break
        
        outeriter += 1
        z = np.zeros(d)
        wz[P] = -np.inf
        wz[Z] = w[Z]

        # Find variable with largest Lagrange multiplier
        t = np.argmax(wz)
        P[t] = True
        Z[t] = False

        # Compute intermediate solution using positive set variables
        z[P] = np.linalg.lstsq(A[:, P], b, rcond=None)[0]

        while np.any(z[P] <= np.finfo(float).eps):
            iter += 1
            if iter > itmax:
                print("Exiting: Inner iteration count exceeded.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            Q = (z <= np.finfo(float).eps) & P
            alpha = np.min(x[Q] / (x[Q] - z[Q])) if np.any(Q) else 0
            if not np.isfinite(alpha):
                print("Warning: No strictly positive step size found.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            x += alpha * (z - x)
            Z = ((np.abs(x) < np.finfo(float).eps) & P) | Z
            P = ~Z

            z = np.zeros(d)
            z[P] = np.linalg.lstsq(A[:, P], b, rcond=None)[0]

        x = z
        w = A.T @ (b - A[:, P] @ x[P])

        perf = getL(options_general["perfmeas"], -w, x)
        check = check_termination(t0, options_general, perf, -w, x, check["fprev"], check["xprev"])
        ConvSpeed.append([time.time() - t0, perf])

    return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}




















#==========================================================================
#
# * 7. function [out] = fnnls_up_down_c(A, b, options_general, options_specific)
#
#==========================================================================

def lsqnnls_up_down_c(A, b, options_general, options_specific):
    """Solves NNLS using Lawson-Hanson's algorithm with Cholesky updating/downdating."""
    f = lambda x: np.linalg.norm(A @ x - b)**2
    t0 = time.time()

    n, d = A.shape
    Atb = A.T @ b

    P, Z = [], list(range(d))
    Pnew = P
    sizeP = sizePnew = 0

    Lt, x, xnew = None, np.zeros(d), np.zeros(d)
    y = np.array([])
    w = A.T @ (b - A @ x)

    outeriter, iter = 1, 0
    outeritmax, itmax = options_specific["outeritmax"], options_specific["inneritmax"]

    perf = getL(options_general["perfmeas"], -w, x)
    check = check_termination(t0, options_general, perf, -w, x, float("inf"), x + float("inf"))
    ConvSpeed = [[0, perf]]

    if check["stop"]:
        return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

    while Z and any(w[Z] > np.finfo(float).eps) and not check["stop"]:
        if outeriter == outeritmax:
            print("Exiting: Outer iteration count is exceeded.")
            break
        
        outeriter += 1
        wz = w[Z]
        k = Z[np.argmax(wz)]
        Pnew.append(k)
        Z.remove(k)
        sizePnew = len(Pnew)

        xnew = np.zeros(d)

        if sizePnew == 1:
            Lt = np.array([[np.linalg.norm(A[:, k])]])
            y = np.array([Atb[k] / Lt[0, 0]])
            xnew[k] = y[0] / Lt[0, 0]
        else:
            l = np.linalg.solve(Lt.T, A[:, P].T @ A[:, k])
            lkk = np.sqrt(np.sum(A[:, k] ** 2) - np.sum(l ** 2))
            Lt = np.vstack([Lt, np.zeros((1, sizePnew))])
            Lt[:, sizePnew - 1] = np.append(l, lkk)
            y = np.append(y, (Atb[k] - np.dot(l, y)) / lkk)
            xnew[Pnew] = np.linalg.solve(Lt, y)

        P, sizeP = Pnew, sizePnew

        while any(xnew[P] <= np.finfo(float).eps):
            iter += 1
            if iter > itmax:
                print("Exiting: Inner iteration count exceeded.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            Q = [p for p in P if xnew[p] <= np.finfo(float).eps]
            alpha = min(x[Q] / (x[Q] - xnew[Q])) if Q else 0
            if not np.isfinite(alpha):
                print("Warning: No strictly positive step size found.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            x += alpha * (xnew - x)
            tmp = [p for p in P if abs(x[p]) < np.finfo(float).eps]
            Z += tmp
            P = [p for p in P if p not in tmp]
            sizeP = len(P)

            for i in reversed(tmp):
                Lt = choldown(Lt, i)
                sizeP -= 1

            if sizeP > 0:
                Lt = np.linalg.cholesky(A[:, P].T @ A[:, P])
                y = np.linalg.solve(Lt.T, Atb[P])
                xnew[P] = np.linalg.solve(Lt, y)

        x = xnew
        w = A.T @ (b - A[:, P] @ x[P])

        perf = getL(options_general["perfmeas"], -w, x)
        check = check_termination(t0, options_general, perf, -w, x, check["fprev"], check["xprev"])
        ConvSpeed.append([time.time() - t0, perf])

    return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}


















#==========================================================================
#
# * 8. function [out] = lsqnnls_up_down(A, b, options_general, options_specific)
#
#==========================================================================


# *internal code not to be called directly by the user*
def lsqnnls_up_down(A, b, options_general, options_specific):
    """
    Solves NNLS using Lawson-Hanson's algorithm with Cholesky updating/downdating.
    """
    f = lambda x: np.linalg.norm(A @ x - b)**2
    t0 = time.time()

    n, d = A.shape
    Atb = A.T @ b

    P, Z = [], list(range(d))
    Pnew = P
    sizeP = sizePnew = 0

    Lt, x, xnew = None, np.zeros(d), np.zeros(d)
    y = np.array([])
    w = A.T @ (b - A @ x)

    outeriter, iter = 1, 0
    outeritmax, itmax = options_specific.outeritmax, options_specific.inneritmax

    perf = getL(options_general.perfmeas, -w, x)
    check = check_termination(t0, options_general, perf, -w, x, float("inf"), x + float("inf"))
    ConvSpeed = [[0, perf]]

    if check["stop"]:
        return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

    while Z and any(w[Z] > np.finfo(float).eps) and not check["stop"]:
        if outeriter == outeritmax:
            print("Exiting: Outer iteration count is exceeded.")
            break
        
        outeriter += 1
        wz = w[Z]
        k = Z[np.argmax(wz)]
        Pnew.append(k)
        Z.remove(k)
        sizePnew = len(Pnew)

        xnew = np.zeros(d)

        if sizePnew == 1:
            Lt = np.array([[np.linalg.norm(A[:, k])]])
            y = np.array([Atb[k] / Lt[0, 0]])
            xnew[k] = y[0] / Lt[0, 0]
        else:
            l = np.linalg.solve(Lt.T, A[:, P].T @ A[:, k])
            lkk = np.sqrt(np.sum(A[:, k] ** 2) - np.sum(l ** 2))
            Lt = np.vstack([Lt, np.zeros((1, sizePnew))])
            Lt[:, sizePnew - 1] = np.append(l, lkk)
            y = np.append(y, (Atb[k] - np.dot(l, y)) / lkk)
            xnew[Pnew] = np.linalg.solve(Lt, y)

        P, sizeP = Pnew, sizePnew

        while any(xnew[P] <= np.finfo(float).eps):
            iter += 1
            if iter > itmax:
                print("Exiting: Inner iteration count exceeded.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            Q = [p for p in P if xnew[p] <= np.finfo(float).eps]
            alpha = min(x[Q] / (x[Q] - xnew[Q])) if Q else 0
            if not np.isfinite(alpha):
                print("Warning: No strictly positive step size found.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

            x += alpha * (xnew - x)
            tmp = [p for p in P if abs(x[p]) < np.finfo(float).eps]
            Z += tmp
            P = [p for p in P if p not in tmp]
            sizeP = len(P)

            for i in reversed(tmp):
                Lt = choldown(Lt, i)
                sizeP -= 1

            if sizeP > 0:
                Lt = np.linalg.cholesky(A[:, P].T @ A[:, P])
                y = np.linalg.solve(Lt.T, Atb[P])
                xnew[P] = np.linalg.solve(Lt, y)

        x = xnew
        w = A.T @ (b - A[:, P] @ x[P])

        perf = getL(options_general.perfmeas, -w, x)
        check = check_termination(t0, options_general, perf, -w, x, check["fprev"], check["xprev"])
        ConvSpeed.append([time.time() - t0, perf])

    return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}


def choldown(Lt, k):
    """
    Performs Cholesky downdating by removing the k-th column from Lt.

    Parameters:
    Lt (numpy.ndarray): Upper triangular Cholesky factor (p x p).
    k (int): Index of column to remove.

    Returns:
    numpy.ndarray: Updated Cholesky factor.
    """
    p = Lt.shape[0]

    # Drop the k-th column
    Temp = np.delete(Lt, k, axis=1)  # Removes column k
    
    # Givens Rotations
    for i in range(k, p-1):
        a = Temp[i, i]
        b = Temp[i+1, i]
        r = np.sqrt(np.sum(Lt[:, i+1]**2) - np.sum(Temp[:i, i]**2))
        c = r * a / (a**2 + b**2)
        s = r * b / (a**2 + b**2)
        
        # Rotation matrix rows
        Hrowi = np.zeros(p)
        Hrowi[i] = c
        Hrowi[i+1] = s
        
        Hrowi1 = np.zeros(p)
        Hrowi1[i] = -s
        Hrowi1[i+1] = c
        
        # Modify rows of Temp
        v = np.zeros((2, p-1))
        v[0, i:p-1] = Hrowi @ Temp[:, i:p-1]
        v[1, i+1:p-1] = Hrowi1 @ Temp[:, i+1:p-1]
        Temp[i:i+2, :] = v

    # Drop last row
    Lkt = Temp[:p-1, :]
    
    return Lkt













#==========================================================================
#
# * 9. function [out] = lsqnnls_up(A, b, options_general, options_specific
#
#==========================================================================




def lsqnnls_up(A, b, options_general, options_specific):
    """
    Solves NNLS using Lawson-Hanson's algorithm with Cholesky updating/downdating.
    """
    # Objective function
    f = lambda x: np.linalg.norm(A @ x - b)**2
    
    # Initialize CPU time
    t0 = time.time()
    
    # Initialize variables
    n, d = A.shape
    Atb = A.T @ b
    
    # Active/passive sets
    P = []
    Z = list(range(d))
    Pnew = P
    sizeP = sizePnew = 0

    Lt = None  # Upper triangular matrix for Cholesky decomposition
    x = np.zeros(d)
    xnew = np.zeros(d)
    y = np.array([])
    w = A.T @ (b - A @ x)

    outeriter = 1
    outeritmax = options_specific.outeritmax
    iter = 0
    itmax = options_specific.inneritmax

    # Gradient-based performance measure
    perf = getL(options_general.perfmeas, -w, x)
    check = check_termination(t0, options_general, perf, -w, x, float("inf"), x + float("inf"))
    ConvSpeed = [[0, perf]]

    # Check initial termination condition
    if check["stop"]:
        return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}

    # Outer loop
    while Z and any(w[Z] > np.finfo(float).eps) and not check["stop"]:
        if outeriter == outeritmax:
            print("Exiting: Outer iteration count is exceeded.")
            break
        
        outeriter += 1
        
        # Move k from active set to positive set
        wz = w[Z]
        k = Z[np.argmax(wz)]
        Pnew.append(k)
        Z.remove(k)
        sizePnew = len(Pnew)

        # Cholesky updating to get xnew
        xnew = np.zeros(d)

        if sizePnew == 1:
            Lt = np.array([[np.linalg.norm(A[:, k])]])
            y = np.array([Atb[k] / Lt[0, 0]])
            xnew[k] = y[0] / Lt[0, 0]
        else:
            l = np.linalg.solve(Lt.T, A[:, P].T @ A[:, k])
            lkk = np.sqrt(np.sum(A[:, k] ** 2) - np.sum(l ** 2))
            Lt = np.vstack([Lt, np.zeros((1, sizePnew))])
            Lt[:, sizePnew - 1] = np.append(l, lkk)
            y = np.append(y, (Atb[k] - np.dot(l, y)) / lkk)
            xnew[Pnew] = np.linalg.solve(Lt, y)

        P = Pnew
        sizeP = sizePnew

        # Check feasibility of xnew
        while any(xnew[P] <= np.finfo(float).eps):
            iter += 1
            if iter > itmax:
                print("Exiting: Inner iteration count exceeded.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}
            
            Q = [p for p in P if xnew[p] <= np.finfo(float).eps]
            alpha = min(x[Q] / (x[Q] - xnew[Q])) if Q else 0
            if not np.isfinite(alpha):
                print("Warning: No strictly positive step size found.")
                return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}
            
            x += alpha * (xnew - x)
            tmp = [p for p in P if abs(x[p]) < np.finfo(float).eps]
            Z += tmp
            P = [p for p in P if p not in tmp]
            sizeP = len(P)

            if sizeP > 0:
                Lt = np.linalg.cholesky(A[:, P].T @ A[:, P])
                y = np.linalg.solve(Lt.T, Atb[P])
                xnew[P] = np.linalg.solve(Lt, y)

        x = xnew
        w = A.T @ (b - A[:, P] @ x[P])

        perf = getL(options_general.perfmeas, -w, x)
        check = check_termination(t0, options_general, perf, -w, x, check["fprev"], check["xprev"])
        ConvSpeed.append([time.time() - t0, perf])

    return {"xopt": x, "err": f(x), "ConvSpeed": ConvSpeed, "check": check}


#==========================================================================
#
# * 0. function options = initopt_general(varargin)
#
#==========================================================================



class OptionsGeneral(BaseModel):
    perfmeas: List[int] = [1]  # Performance measures
    maxcpu: confloat(gt=0) = float('inf')  # Max CPU time
    stopcrit: conlist(conint(gt=0, le=3), min_length=1) = [1]  # Stopping criteria
    tol: conlist(confloat(gt=0), min_length=1) = [1e-10]  # Tolerances
    usegram: conint(ge=0, le=1) = 0  # Whether to compute Gram matrix
    gram: Optional[List[List[float]]] = None  # Precomputed Gram matrix
    mv: conint(ge=0, le=2) = 0  # Matrix-vector multiplication strategy
    mode: conint(ge=0, le=1) = 0  # Problem mode

def initopt_general(**kwargs):
    options = OptionsGeneral(**kwargs)

    options.stopcrit = list(set(options.stopcrit))  # Ensure uniqueness

    if len(options.tol) != len(options.stopcrit):
        raise ValueError("The length of the vector of tolerances should be equal to the number of stopping criteria.")

    if options.gram is not None:
        options.usegram = 1

    if options.usegram == 0:
        if options.mode == 1:
            print("mode 1: automatically set usegram = 1.")
            options.usegram = 1
        if options.mv == 1:
            print("mv 1: automatically set usegram = 1.")
            options.usegram = 1

    return options

# example
# initopt_general()
# initopt_general('usegram',true)
# initopt_general('mv',2,'tol',10^-8);