#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
import math
from scipy.special import comb

from spline_chebmom  import *
from cheap_startup import *
from cub_gausscheb_tens2D import *
from dCHEBVAND import *
from mono_next_grlex import *



def tenscheb_norm2sq(ade,chebyshev_indices):

# %--------------------------------------------------------------------------
# % Object:
# %--------------------------------------------------------------------------
# % Input:
# %--------------------------------------------------------------------------
# % ade: total degree of the basis.
# % 
# % chebyshev_indices: indices of the tensorial Chebyshev basis (as produced
# %       by the routine "tenscheb_norm2sq"; in other words if 
# %       "tenscheb_norm2sq(s,:)=[i j]" then the s-th polynomial is
# %                       phi_s(x,y,z)=T_i(x) T_j(y)
# %       where T_m(u)=cos(m*acos(u)).
# %--------------------------------------------------------------------------
# % Output:
# %--------------------------------------------------------------------------
# % coeffs: computation of (phi_k,phi_k) where phi_k is the k-th tensor
# %         product polynomial of the basis used in the Vandermonde matrix.
# % chebyshev_indices: indices of the tensorial Chebyshev basis (as produced
# %       by the routine "tenscheb_norm2sq"; in other words if 
# %       "tenscheb_norm2sq(s,:)=[i j]" then the s-th polynomial is
# %                       T_i(x) T_j(y)
# %       where T_m(u)=cos(m*acos(u)).
# %--------------------------------------------------------------------------
# % Related paper:
# %--------------------------------------------------------------------------
# % "Effective numerical integration on complex shaped elements by discrete
# % signed measures", 2025.
# % by L. Rinaldi, A. Sommariva, M. Vianello.
# %--------------------------------------------------------------------------
# %--------------------------------------------------------------------------
# % License:
# %--------------------------------------------------------------------------
# % Copyright (C) 2025 Laura Rinaldi, Alvise Sommariva, Marco Vianello.
# %
# % This program is free software; you can redistribute it and/or modify
# % it under the terms of the GNU General Public License as published by
# % the Free Software Foundation; either version 3 of the License, or
# % (at your option) any later version.
# %
# % This program is distributed in the hope that it will be useful,
# % but WITHOUT ANY WARRANTY; without even the implied warranty of
# % MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# % GNU General Public License for more details.
# %
# % You should have received a copy of the GNU General Public License
# % along with this program; if not, write to the Free Software
# % Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
# %
# % Authors:
# %
# % Laura Rinaldi    <laura.rinaldi@unipd.it>
# % Alvise Sommariva <alvise@math.unipd.it>
# % Marco Vianello   <marcov@math.unipd.it>
# %
# % Date: October 22, 2025
# %--------------------------------------------------------------------------

    coeffs=[];

    for k in range(np.shape(chebyshev_indices)[0]):
        coeffsL = np.pi**2 / 2**sum(not(val == 0) for val in chebyshev_indices[k])
        coeffs.append(coeffsL)
    #end
    return coeffs,chebyshev_indices







