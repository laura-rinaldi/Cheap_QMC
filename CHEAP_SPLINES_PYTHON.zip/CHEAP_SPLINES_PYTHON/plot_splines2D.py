#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
import math
from scipy.special import comb

from spline_chebmom  import *
from cheap_startup import *
from cub_gausscheb_tens2D import *
from dCHEBVAND import *
from mono_next_grlex import *



import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import PPoly   

def plot_splines2D(Sx_list, Sy_list, plot_axis=0):

    fig, ax = plt.subplots()

    if plot_axis == 0:
        ax.axis("off")
    else:
        ax.axis("on")

    for Sx, Sy in zip(Sx_list, Sy_list):
        breaks = Sx.x  
        for k in range(len(breaks)-1):
            t0, t1 = breaks[k], breaks[k+1]
            tt = np.linspace(t0, t1, 1000)
            
            xx = Sx(tt)
            yy = Sy(tt)
            
            ax.plot(xx, yy, 'k-', linewidth=4)

    # plt.show()






