#!/usr/bin/env python
# coding: utf-8




import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
import math
from scipy.special import comb

from spline_chebmom  import *
from cheap_startup import *
from cub_gausscheb_tens2D import *
from dCHEBVAND import *



def mono_next_grlex ( m, x ):

    if m < 1:
        raise ValueError("mono_next_grlex - Fatal error! M < 1")

    # Ensure that all entries in x are >= 0
    for i in range(m):
        if x[i] < 0:
            raise ValueError("mono_next_grlex - Fatal error! X[i] < 0")

    # Find the index i of the rightmost nonzero entry of x
    i = 0
    for j in range(m - 1, -1, -1):
        if x[j] > 0:
            i = j + 1  # Convert 0-based Python indexing to 1-based
            break

    # If no nonzero entry, start with [0, ..., 0, 1]
    if i == 0:
        x[-1] = 1
        return x

    # Otherwise, process x
    if i == 1:
        t = x[0] + 1
        im1 = m - 1
    else:
        t = x[i - 1]
        im1 = i - 2

    x[i - 1] = 0
    x[im1] += 1
    x[-1] += t - 1

    return x







