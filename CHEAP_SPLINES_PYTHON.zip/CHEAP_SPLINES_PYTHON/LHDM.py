import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline, splrep, splev
from scipy.interpolate import BSpline, PPoly
import scipy.special
from scipy.special import roots_legendre
from scipy.special import gamma, gammaln
from scipy.linalg import qr
from scipy.optimize import lsq_linear
from scipy.optimize import nnls


import numpy as np

def LHDM(C, d, options=None, verbose=0):
# Lawson-Hanson algorithm accelerated by Deviation Maximization (DM).

#     Parameters:
#         C (numpy.ndarray): Least squares matrix.
#         d (numpy.ndarray): Right-hand side vector.
#         options (dict, optional): Optimization parameters:
#             - init (bool): Use ULS initialization if True.
#             - tol (float): Tolerance for projected residual.
#             - k (int): Max number of indices added to Passive set each iteration.
#             - thres (float): Threshold for angle between columns (0 to 1).
#         verbose (int, optional): Verbosity level.

#     Returns:
#         x (numpy.ndarray): Nonnegative solution minimizing ||C*x - d||.
#         resnorm (float): Squared residual norm ||C*x - d||^2.
#         exitflag (int): Exit condition (1: success, 0: exceeded iteration).
#         outeriter (int): Number of outer iterations.
#
    if options is None:
        options = {}

    m, n = C.shape
    nZeros = np.zeros(n)
    wz = np.zeros(n)
    itmax = 2 * m

    # Initialize sets
    P = np.zeros(n, dtype=bool)
    Z = np.ones(n, dtype=bool)
    x = np.zeros(n)

    thres = options.get('thres', 0.2222)
    thres_w = options.get('thres_w', 0.8)
    k = options.get('k', max(1, m // 20))
    tol = options.get('tol', 10 * np.finfo(float).eps * np.linalg.norm(C, 1) * len(C))
    LHDMflag = k > 1

    if verbose:
        print(f"LHDM({k}) {'with ULS initialization' if options.get('init', False) else ''}")

    if LHDMflag:
        Cnorm = C / np.linalg.norm(C, axis=0)

    # Initialize residual and dual variables
    resid = d - C @ x
    w = C.T @ resid
    outeriter = 0
    totiter = 0

    while np.any(Z) and (np.any(w[Z] > tol) or np.any(x[P] < 0)) and totiter < itmax:
        outeriter += 1
        totiter += 1

        wz[P] = -np.inf
        wz[Z] = w[Z]

        if outeriter == 1 or not LHDMflag:
            t = np.argmax(wz)
        else:
            t = DM(Cnorm, wz, k, thres, thres_w)
            t = t[:min(len(t), m - np.sum(P))]

        addedP = np.shape(t)
        z = np.zeros_like(x)
        P[t] = True
        Z[t] = False
        z[P] = np.linalg.lstsq(C[:, P], d, rcond=None)[0]

        iter = 0
        removedP = 0

        while np.any(z[P] <= 0) and totiter < itmax:
            totiter += 1
            iter += 1
            Q = (z <= 0) & P
            alpha = np.min(x[Q] / (x[Q] - z[Q]))
            x = x + alpha * (z - x)
            t = np.where((np.abs(x) < tol) & P)[0]
            removedP += len(t)
            Z[(np.abs(x) < tol) & P] = True
            P = ~Z
            z[P] = np.linalg.lstsq(C[:, P], d, rcond=None)[0]

        x = z
        resid = d - C @ x
        w = C.T @ resid

    exitflag = 1 if outeriter < itmax else 0
    resnorm = np.dot(resid, resid)

    return x #, resnorm, exitflag, outeriter




def DM(Cnorm, wz, k, thres, thres_w):

#     Deviation Maximization

#     :param Cnorm: 2D NumPy array
#     :param wz: 1D NumPy array
#     :param k: integer
#     :param thres: threshold value
#     :param thres_w: weight threshold multiplier
#     :return: list of indices

    wzI = np.sort(wz)[::-1]  # Sort in descending order
    I = np.argsort(wz)[::-1]  # Get sorted indices
    t = I[0]
    p = [t]
    
    thres_wloc = thres_w * wzI[0]
    C = np.where(wzI > thres_wloc)[0]  # Get indices of wzI above threshold
    
    n = C.shape[0]
    add = 1
    
    for i in range(1, n):
        c = C[i]
        max_dev = np.max(np.abs(Cnorm[:, I[c]].T @ Cnorm[:, p]))
        
        if max_dev < thres:
            p.insert(0, I[c])
            add += 1
            
        if add >= k:
            break
    
    return p
