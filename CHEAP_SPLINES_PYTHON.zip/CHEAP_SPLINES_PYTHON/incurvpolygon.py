
import numpy as np
from scipy.interpolate import CubicSpline, PchipInterpolator
from scipy.optimize import root
from scipy.interpolate import BSpline, PPoly



def incurvpolygon(P, X, Y, Nsub=None, spline_parms=None,
                  SPLtypestring=None, boxVx=None, singular_points=None):

#     Determines if a sequence of points lies inside, outside, or on the boundary
#     of a curvilinear polygon defined by parametric splines.

#     Parameters:
#         P (ndarray): Nx2 array of points to test.
#         X, Y: Either arrays of vertices or lists of spline objects.
#         Nsub (int): Subdivision count for box generation (optional).
#         spline_parms (ndarray): Spline order and index information (optional).
#         SPLtypestring (str): Spline type (e.g., 'cubic', 'not-a-knot').
#         boxVx (optional): Cached box structures from previous use.
#         singular_points (optional): Cached singular points from previous use.

#     Returns:
#         in_ (ndarray): Binary array where 1 = inside, 0 = outside.
#         on (ndarray): Array where NaN = not on boundary, otherwise indicates "on".
#         Sx, Sy (list): Spline objects representing the domain boundary.
#         boxVx: Monotonic box representations for spatial checking.
#         turning_points_Sx, turning_points_Sy: Where spline derivatives vanish.
#         singular_junctions_Sx: x-values where boundary crossings are ambiguous.


    tol = 1e-11  # boundary tolerance

    if Nsub is None:
        Nsub = []

    if boxVx is None:
        boxVx = []

    if singular_points is None:
        singular_points = []
        
    sorted_indices = np.lexsort((P[:, 1], P[:, 0]))
    P = P[sorted_indices]
    
    # Case: spline and box info already available
    if len(boxVx) != 0 and len(singular_points) != 0:
        Sx, Sy = X, Y
        if (np.shape(P)[0]) > 0:
            in_, on = indomain(P, Sx, Sy, boxVx, singular_points[:, 0], tol)
        else:
            in_, on = np.array([]), np.array([])

        turning_points_Sx = []
        turning_points_Sy = []
        singular_junctions_Sx = []

        return 
    LV=[]
    # Case: X, Y are not splines – generate splines
    if isinstance(X[0], float): 

        if spline_parms is None:
            spline_parms = np.array([2, len(X)])
        if SPLtypestring is None:
            SPLtypestring = 'natural'
        
        Sx, Sy, Nsub = Sx_Sy_preparation(X, Y, Nsub, spline_parms, SPLtypestring)
    else:
        Sx, Sy = X, Y
        for ii in range(len(Sx)):
            SxL = Sx[ii]  # Extract spline object
            LV.append(len(SxL.x))  
        L = sum(LV)
        Nsub = int(np.ceil(210 / L))

    # Generate boxes
    boxVx, turning_points_Sx, turning_points_Sy = spline_boxer(Sx, Sy, Nsub)

    # Identify singularities
    singular_junctions_Sx = singular_vertices_v8a(Sx, Sy)
    singular_points = define_singpts(turning_points_Sx, singular_junctions_Sx)

   
    # Determine if points are in domain
    in_, on = indomain(P, Sx, Sy, boxVx, singular_points[:, 0], tol)

    # Handle NaNs (undefined cases) with winding algorithm
    index_sz = np.where(np.isnan(in_)==1)[0]
    for ii in range( len(index_sz)):
        windn = winding_algorithm(P, Sx, Sy)
        in_[index_sz] = np.remainder(windn[index_sz], 2)

    if len(index_sz) > 1:
            print(f"\n\t*** Used winding algorithm {len(index_sz)} times")

    return in_, on   #, Sx, Sy, boxVx, turning_points_Sx, turning_points_Sy, singular_junctions_Sx


#--------------------------------------------------------------------------
# Attached functions.
#--------------------------------------------------------------------------


#--------------------------------------------------------------------------
# Sx_Sy_preparation
#--------------------------------------------------------------------------

def Sx_Sy_preparation(X, Y, Nsub, spline_parms, SPLtypestring):

#     Prepares parametric splines for X and Y data.

#     Parameters:
#         X (ndarray): 1D array of X coordinates.
#         Y (ndarray): 1D array of Y coordinates.
#         Nsub (int): Subdivision count (unchanged here).
#         spline_parms (ndarray): Lx2 array, each row [spline_type, endpoint_index].
#         SPLtypestring (str): Type of spline (e.g., 'cubic', 'linear').

#     Returns:
#         Sx (list): List of spline functions or representations for X.
#         Sy (list): List of spline functions or representations for Y.
#         Nsub (int): Returned unchanged.

    
    L = spline_parms.shape[0]
    Sx = []
    Sy = []

    for i in range(L):
        if i == 0:
            imin = 0 
        else:
            imin = spline_parms[i - 1, 1]
        
        imax = spline_parms[i, 1]

        tL = np.arange(imin, imax)
        xL = X[imin:imax ]
        yL = Y[imin:imax ]

        SxL, SyL = compute_parametric_spline(tL, xL, yL, spline_parms[i, 0], SPLtypestring)

        
        Sx[i] = SxL
        Sy[i] = SyL

    return Sx, Sy, Nsub



#--------------------------------------------------------------------------
# define_singpts
#--------------------------------------------------------------------------
def define_singpts(turning_points_Sx, singular_junctions_Sx):

#     Collects and combines singular points from turning points and singular junctions.
    
#     Parameters:
#         turning_points_Sx (ndarray): NxM array containing turning point data.
#         singular_junctions_Sx (ndarray): KxM array containing singular junction data.

#     Returns:
#         ndarray: Combined array of singular points (only first two columns).

  
    if np.shape(turning_points_Sx)[0] > 0:
        singular_points = turning_points_Sx[:,:2]
    else:
        singular_points = []
    
    if np.shape(singular_junctions_Sx)[0] > 0:
        if np.shape(singular_points)[0] > 0: 
            singular_points = np.vstack((singular_points, singular_junctions_Sx[:, :2]))
        else:
            singular_points = singular_junctions_Sx[:, :2]

    return singular_points




#--------------------------------------------------------------------------
#
#--------------------------------------------------------------------------

def indomain(P, Sx, Sy, boxV=None, singptsX=None, tol=1e-11):

#     Determines if points are inside or on a spline curvilinear region.

#     Args:
#         P (ndarray): Points to test, defined as an N x 2 matrix.
#         Sx (list): x-component of the splines.
#         Sy (list): y-component of the splines.
#         boxV (ndarray): Box definition matrix. Optional.
#         singptsX (ndarray): Singular points. Optional.
#         tol (float): Tolerance for point detection in the box.

#     Returns:
#         tuple: (in, on)
#             in: 1 if inside the domain, 0 if not, NaN for ambiguous points.
#             on: Number if point is close to boundary, NaN otherwise.

    if boxV is None:
        # Generate boxV and related data if not provided
        boxV, turning_points_Sx, boxVy, turning_points_Sy = spline_boxer(Sx, Sy)

       

    if singptsX is None:
        singptsX = []
        
        
    sorted_indices = np.lexsort((P[:, 1], P[:, 0]))
    P = P[sorted_indices]
    X = P[:, 0].reshape(1, -1)  # Extract x-coordinates of points
    Y = P[:, 1].reshape(1, -1)  # Extract y-coordinates of points
    
    a, b, c, d = boxV[:, 0].reshape(-1, 1).flatten(), boxV[:, 1].reshape(-1, 1).flatten(), boxV[:, 2].reshape(-1, 1).flatten(), boxV[:, 3].reshape(-1, 1).flatten()

    iboxes = (X.T > a) & (X.T <= b) & (Y.T >= c)
    iboxes=iboxes.T


    itestL = iboxes & (Y.T <= d).T
    iregL = iboxes & (Y.T > d).T
     
    crossings = np.sum(iregL, axis=0)

    # Points inside boxes
    further_analysis_index =  np.where(np.sum(itestL, axis=0) > 0)[0]
   

    on = np.full(X.shape, np.nan)
   
    for jj in range(len(further_analysis_index)):
        Pindex = further_analysis_index[jj]
        PL = P[Pindex, :]  # Extract row
        itestPL0 = itestL[:, Pindex]  # Extract column
        index_testPL = np.where(itestPL0 > 0)[0]  # Find positive indices

        
        final_value0, on_Pindex = box_analysis(PL, index_testPL, boxV, Sx, Sy, tol)

        # Update crossings array
        crossings[Pindex] += final_value0

    in_domain = crossings % 2

    # Study points close to singularities
    if singptsX.size > 0:
        iflag = singularity_checks(P, singptsX)
        iflag0 = np.where(~np.isfinite(on[iflag]))[0] 
        

        iflagF = iflag[iflag0]
        if iflagF:
            on[iflagF] = -np.inf * np.ones(( len(iflagF), np.shape(P[:,0])[0] ))
        
            in_domain[iflagF] = on[iflagF]  

    # Safe exit for boundary points
    ion = np.where(np.isfinite(on) == 1)[0]

    in_domain[ion] = 0

    return in_domain, on




#--------------------------------------------------------------------------
#
#--------------------------------------------------------------------------

def box_analysis(P, itest, boxV, Sx, Sy, tol=1e-11):

#     Analyzes a point P with respect to a given set of spline box data.

#     Args:
#         P (list or ndarray): Point to test, 1 x 2 matrix.
#         itest (list or ndarray): Index of the box to be studied.
#         boxV (ndarray): Box definition matrix, defining the box boundary.
#         Sx (list of splines): x-component of the splines.
#         Sy (list of splines): y-component of the splines.
#         tol (float): Tolerance for point detection in the box.

#     Returns:
#         tuple: (final_value, flag)
#             final_value: Crossing value (odd if inside, even if outside).
#             flag:
#                 * NaN if point is safely outside or inside the domain.
#                 * finite value if point is close to the boundary.
#                 * -Inf if there are issues determining the position.

    final_value = 0
    flag = np.nan

    x=P[0]
    y=P[1]# Extract the coordinates of the point P

    if len(itest) > 0:
        for ii in range(len(itest)):
            itestL = itest[ii]
            isplL = int(boxV[itestL, 6])  # Spline index
            icoefsL = int(boxV[itestL, 7])  # Coefficient index
            SxL = Sx[isplL]
            SyL = Sy[isplL]

            # Process higher-order splines
            if get_spline_degree(SxL) > 2:
                SxL_coefs = SxL.c.T[icoefsL, :]
                SyL_coefs = SyL.c.T[icoefsL, :]
                a = boxV[itestL, 4]  # t_min
                b = boxV[itestL, 5]  # t_max
                t0 = SxL.x[icoefsL]
                t1 = SxL.x[icoefsL + 1]

                local_value, flag = spline_over(P, SxL_coefs, SyL_coefs, a, b, t0, t1, tol)

                if np.isfinite(flag):
                    final_value = 0  # point is on the boundary
                    return 

            else:  # Spline order = 2
                nodes = SxL.x
                a = boxV[itestL, 4]
                b = boxV[itestL, 5]
                P1 = [SxL(a), SyL(a)]
                P2 = [SxL(b), SyL(b)]

                # Handle non-vertical sides
                if abs(P1[0] - P2[0]) > 0:
                    x0, y0 = P1
                    x1, y1 = P2
                    m = (y1 - y0) / (x1 - x0)
                    yy = y0 + m * (x - x0)

                    if abs(yy - y) <= tol:
                        final_value = 0
                        flag = abs(yy - y)
                        return 
                    else:
                        if yy < y:
                            local_value = 1  # Crossing
                        else:
                            local_value = 0  # Not crossing
                else:  # Vertical side case
                    min_y = min(P1[1], P2[1])
                    max_y = max(P1[1], P2[1])

                    if min_y <= y <= max_y:
                        flag = 0
                        final_value = 0
                        return 
                    else:
                        flag = -np.inf
                        final_value = np.nan
                        return 

            if np.isnan(flag):
                final_value += local_value
            else:
                final_value = 0
                return 

    return final_value, flag



#--------------------------------------------------------------------------
# spline_over
#--------------------------------------------------------------------------


def spline_over(P, xtv, ytv, a, b , t0, t1, tol=1e-12):

#     Determines how many times a straight line with x=P[1] intersects the spline boundary.
    
#     Args:
#         P (list or ndarray): Point to test, 1 x 2 vector. The point is assumed to be in
#                               the rectangle with SxL([t0,t1]) x SyL([t0,t1]).
#         xtv (ndarray): Local coefficients of the spline SxL.
#         ytv (ndarray): Local coefficients of the spline SyL.
#         a, b (float): The extrema of the spline SxL, SyL (subsequent break points).
#         t0, t1 (float): The interval [t0,t1] is a subset of [a,b].
#         tol (float): Tolerance for checking how close the point is to the boundary.

#     Returns:
#         tuple: (val, flag)
#             val: How many times the straight line intersects the spline boundary.
#             flag: 
#                 * NaN if the point is not on the boundary.
#                 * A finite number if the point is accepted as on the boundary.
#                 * -Inf if the point is out of range of the spline.

    val = 0
    flag = np.nan
    x= P[0]
    y= P[1]# Extract the coordinates of the point P

    s0 = a - t0
    s1 = b - t0

    # Create a new vector for xtv with the last element adjusted
    xtv0 = np.copy(xtv)
    xtv0[-1] -= x

    # Special case: Check if xtv is a vertical line
    if np.linalg.norm(xtv0[:-1]) == 0:
        if xtv0[-1] == 0:
            val = 0
            flag = 0
        else:
            val = np.nan
            flag = -np.inf
        return val, flag

    # Normal case: Solve the roots of the equation
    tR = myroots(xtv0, s0, s1)

    # Check for intersections
    for j in range(len(tR)):
        tRL = tR[j]
        yL = np.polyval(ytv, tRL)  

        # Point "safely" over the boundary
        if yL < y + tol:
            val += 1

        # Point "safely" close to the boundary
        if abs(yL - y) <= tol:
            val = 0
            flag = abs(yL - y)
            return val, flag

    return val, flag





#--------------------------------------------------------------------------
# singularity_checks.
#--------------------------------------------------------------------------

def singularity_checks(P, singular_pointsX):

#     This function checks whether any points in the set P are close to singularities.
#     Special algorithms are required for points near singularities.
    
#     Args:
#         P (ndarray): A matrix of size M x 2, where each row represents the coordinates (x, y).
#         singular_pointsX (ndarray): A 1D array of abscissas (x-coordinates) where problems may arise.
    
#     Returns:
#         iflag (ndarray): Indices of the points in P that are close to singularities.


    if singular_pointsX.size != 0:
        toll = 10**(-12)
      
        iflag = np.where(np.min(np.abs(singular_pointsX.reshape(-1, 1) - P[:, 0].reshape(1, -1)), axis=1) < toll)[0]

    else:
        iflag = np.array([])

    return iflag






#--------------------------------------------------------------------------
# myroots.
#--------------------------------------------------------------------------

def myroots(p, t1=-np.inf, t2=np.inf):

#     Solves the polynomial equation p(1)*x^n + ... + p(n+1) = 0 in the interval [t1, t2].
    
#     Args:
#         p (list or ndarray): Coefficients of the polynomial, starting from the highest degree.
#         t1 (float): Lower bound of the interval in which to find the roots (default: -inf).
#         t2 (float): Upper bound of the interval in which to find the roots (default: +inf).
    
#     Returns:
#         sols (ndarray): Vector of solutions in the interval [t1, t2].
#         flag (int or float): 0 for finite complex solutions, Inf for infinite complex solutions, 
#                               NaN for no complex solutions.

    
    # Compute the roots of the polynomial
    sols = np.roots(p)
    
    if sols.size > 0:
        # Separate real and imaginary parts
        isols = np.imag(sols)
        rsols = np.real(sols)

        # Filter solutions within the range [t1, t2] with negligible imaginary part
        isols_in = np.where((np.abs(isols) < 1e-12) & (rsols >= t1) & (sols <= t2))[0]
        sols = rsols[isols_in]
        flag = 0
    else:
        # Check for infinite or no solutions
        
        if p[-1] == 0 :
            flag = np.inf 
        else:
            np.nan
        

    return sols, flag





#--------------------------------------------------------------------------
# singular_vertices_v8a.
#--------------------------------------------------------------------------

def singular_vertices_v8a(Sx, Sy):

#     This function detects singular junctions (points where the derivative
#     of the spline changes sign) in the given splines Sx and Sy.
    
#     Args:
#         Sx (list of CubicSpline objects): List of splines representing the x boundary of the domain.
#         Sy (list of CubicSpline objects): List of splines representing the y boundary of the domain.
    
#     Returns:
#         singular_junctions (ndarray): Singular junctions where the derivative changes sign, along with
#                                        their corresponding x, y, and t values.

    singular_junctions = []
    derivatives_at_endpoints = []
    for ii in range(len(Sx)):
        SxL = Sx[ii]
        SyL = Sy[ii]

        # Extract breakpoints 
        nodes = SxL.x

        # Initialize an empty list
        derivatives_at_endpointsL = []


        if get_spline_degree(SxL) == 2:  # Order 2 spline (linear spline)
            Nnodes = len(nodes)
            t0 = nodes[:-1]
            t1 = nodes[1:]
            SxL_nodes = SxL(nodes)
            x0 = SxL_nodes[:-1]
            x1 = SxL_nodes[1:]
            m = (x1 - x0) / (t1 - t0)
            if len(m) > 1:
                mend=m[1:]
                minit=m[:-1]
                ichangeder=np.where((mend*minit )<= 1e-14)[0]
                inodes_ch=ichangeder +1
                singular_pointsT = nodes[inodes_ch]
                singular_pointsX = SxL_nodes[inodes_ch]
                singular_pointsY = SyL(singular_pointsT)
                if not singular_junctions:
                    singular_junctions = np.vstack((singular_pointsX, singular_pointsY, singular_pointsT)).T.tolist()
                    #print(np.shape(singular_junctions))
                else:
                    singular_junctions = np.vstack((singular_junctions, np.hstack((singular_pointsX, singular_pointsY, singular_pointsT)))).tolist()
                    
            #end

            derivatives_at_endpointsL = np.array([[m[0], t0[0]], [m[-1], t1[-1]]])

        else:  # Higher-order spline
            Sx1L = SxL.derivative()
            Sx1nodes = Sx1L(nodes)
            nodes_in = nodes[1:-1]
            Sx1nodes_in = Sx1nodes[1:-1]

            inullders = np.where(np.abs(Sx1nodes_in) <= 1e-14)[0]

            if inullders.size > 0:
                singular_pointsT = nodes_in[inullders]
                singular_pointsX = SxL(singular_pointsT)
                singular_pointsY = SyL(singular_pointsT)
                singular_junctions = np.vstack((singular_junctions, np.hstack((singular_pointsX, singular_pointsY, singular_pointsT))))
                

            Dinit = Sx1nodes[0]
            Dend = Sx1nodes[-1]
            derivatives_at_endpointsL = np.array([[Dinit, nodes[0]], [Dend, nodes[-1]]])
          
        derivatives_at_endpoints= np.append(derivatives_at_endpoints,derivatives_at_endpointsL)
        derivatives_at_endpoints = np.vstack(derivatives_at_endpoints)
    
        
    # Changes at spline junctions
    DeL = derivatives_at_endpoints[1::2][:-1, 0]  
    DeR = derivatives_at_endpoints[2::2][:, 0]  
    


    # Find indices where product of derivatives is non-positive
    ichangeder = np.where(DeL * DeR <= 0)[0]
    LL = len(ichangeder)

    if LL >= 1:
        singular_pointsTJ = np.zeros((LL, 1))
        singular_pointsXJ = np.zeros((LL, 1))
        singular_pointsYJ = np.zeros((LL, 1))

        for kk in range(LL):
            idx = ichangeder[kk]
            SxL = Sx[idx]
            SyL = Sy[idx]
            nodesL = SxL.x 

            singular_pointsTJ[kk, 0] = nodesL[-1]
            singular_pointsXJ[kk, 0] = SxL(nodesL[-1]) 
            singular_pointsYJ[kk, 0] = SyL(nodesL[-1])  
    else:
        singular_pointsXJ = np.array([])
        singular_pointsYJ = np.array([])
        singular_pointsTJ = np.array([])

        
        
        # Final and initial point
    temp = (derivatives_at_endpoints[0][0]) * (derivatives_at_endpoints[-1][0])

    ichangeder1 = temp[temp <= 0] #np.where(temp <=0)[0]

    if ichangeder1.size > 0:
    
        SxL = Sx[0]
        SyL = Sy[0]
        nodesL = SxL.x
        new_TJ = nodesL[0]
        new_XJ = SxL(new_TJ)  
        new_YJ = SyL(new_TJ)  

        # Append values as new rows
        singular_pointsTJ = np.vstack((singular_pointsTJ, np.array([[new_TJ]])))
        singular_pointsXJ = np.vstack((singular_pointsXJ, np.array([[new_XJ]])))
        singular_pointsYJ = np.vstack((singular_pointsYJ, np.array([[new_YJ]])))
    #print('a',np.shape(singular_junctions))
    if get_spline_degree(SxL) == 2:
            singular_junctions.append(( np.column_stack((singular_pointsXJ, singular_pointsYJ, singular_pointsTJ))))
            singular_junctions = np.vstack(singular_junctions)
    else:
        singular_junctions.append(( np.column_stack((singular_pointsXJ, singular_pointsYJ, singular_pointsTJ))))
        singular_junctions = np.vstack(singular_junctions)
        #print('b',np.shape(singular_junctions))
    #print(singular_junctions)
    return singular_junctions




#--------------------------------------------------------------------------
# spline_boxer (and subroutines)
#--------------------------------------------------------------------------


def spline_boxer(Sx, Sy, Nsub=10):

#     This function generates boxes from the splines Sx and Sy, and finds turning points
#     where the derivatives of Sx and Sy are zero.
    
#     Args:
#         Sx (list): List of CubicSpline objects representing the x boundary of the domain.
#         Sy (list): List of CubicSpline objects representing the y boundary of the domain.
#         Nsub (int, optional): Number of subdivisions between each pair of consecutive breakpoints. Default is 10.
    
#     Returns:
#         boxVx (ndarray): Array containing the boxes formed by the splines, each box is a rectangle.
#         turning_points_Sx (ndarray): Turning points of Sx, where the derivative is zero.
#         turning_points_Sy (ndarray): Turning points of Sy, where the derivative is zero.

    
    boxVx = []
    turning_points_Sx = np.empty((1, 3))   # 0 rows, 3 columns
    turning_points_Sy = np.empty((1, 3))

    for isp in range(len(Sx)):
        SxL = Sx[isp]
        SyL = Sy[isp]
        
        # Call the spline_boxer0 function, which processes each individual spline
        box_VxL, turning_points_SxL, turning_points_SyL = spline_boxer0(SxL, SyL, isp, Nsub)
        
        # Append results for each spline
        #print(boxVx, np.shape(boxVx))
        # boxVx.append(box_VxL)
        # turning_points_Sx.append(turning_points_SxL)
        # turning_points_Sy.append(turning_points_SyL)

    # Convert the list of results into numpy arrays for consistent output
    # np.vstack(boxVx), np.vstack(turning_points_Sx), np.vstack(turning_points_Sy)
        if isp ==0:
            boxVx = box_VxL
            # turning_points_Sx=  turning_points_SxL
            # turning_points_Sy=  turning_points_SyL
        else:
                
            boxVx = np.vstack([boxVx, box_VxL])
            turning_points_Sx= np.vstack([turning_points_Sx, turning_points_SxL])
            turning_points_Sy= np.vstack([turning_points_Sy, turning_points_SxL])

    return boxVx, np.array(turning_points_Sx)[1:], np.array(turning_points_Sy)[1:]



#--------------------------------------------------------------------------
#
#--------------------------------------------------------------------------
def get_spline_degree(spline):
    if isinstance(spline, CubicSpline):
        deg=4  # CubicSpline always means degree 3
    elif isinstance(spline, BSpline):
        deg=spline.k  # spline.k is the degree
    else:
        deg = spline.c.shape[0]#raise TypeError("Unsupported spline type")
    return deg
   


#--------------------------------------------------------------------------
#
#--------------------------------------------------------------------------
def spline_boxer0(SxL, SyL, isp, Nsub):

#     This function determines the appropriate spline boxing function based on the spline order.

#     Args:
#         SxL (CubicSpline): Spline for x coordinates.
#         SyL (CubicSpline): Spline for y coordinates.
#         isp (int): Spline index.
#         Nsub (int): Number of subdivisions of each subinterval determined by breaks and x-turning points.

#     Returns:
#         box_VxL (ndarray): Array containing the boxes with variables [a, b, c, d, ..., der_signx, der_signy].
#         turning_points_SxL (ndarray): The turning points for x-coordinates.
#         turning_points_SyL (ndarray): The turning points for y-coordinates.

    

        
    # Check if the spline order is 2
    if get_spline_degree(SxL) == 2:
        # If the spline order is 2, call the spline_boxer_order2 function
        box_VxL = spline_boxer_order2(SxL, SyL, isp, Nsub)
        turning_points_SxL = []
        turning_points_SyL = []
    else:
        # Otherwise, call the spline_boxer_ordernot2 function
        box_VxL, turning_points_SxL, turning_points_SyL = spline_boxer_ordernot2(SxL, SyL, isp, Nsub)

    return box_VxL, turning_points_SxL, turning_points_SyL



#--------------------------------------------------------------------------
#
#--------------------------------------------------------------------------

def spline_boxer_order2(SxL, SyL, isp, Nsub, derivatives_infos=0):

#     This function builds the "boxes" for a piece of spline of order 2.

#     Args:
#         SxL (CubicSpline): Spline for x coordinates.
#         SyL (CubicSpline): Spline for y coordinates.
#         isp (int): Spline index.
#         Nsub (int): Number of subdivisions of each subinterval determined by breaks and x-turning points.
#         derivatives_infos (int): Optional flag to include derivatives' sign in the box data (default is 0).

#     Returns:
#         box_VxL (ndarray): Array containing the boxes with variables [a, b, c, d, ..., der_signx, der_signy].

    # Retrieve spline breakpoints
    derivatives_infos=0;
    nodes = SxL.x.T
    box_VxL = []

    # Analyze each spline component
    for ibl in range(len(nodes) - 1):
        tm = nodes[ibl]
        tM = nodes[ibl + 1]

        # Generate subdivision points
        tt = np.linspace(tm, tM, Nsub + 1)
        tt = tt.reshape(-1, 1)

        # Evaluate the spline at subdivision points
        xvalues = SxL(tt)
        yvalues = SyL(tt)

        # Min and Max values between consecutive points for x and y
        xvaluesM = np.column_stack([xvalues[:-1], xvalues[1:]])
        xm = np.min(xvaluesM, axis=1)
        xM = np.max(xvaluesM, axis=1)

        yvaluesM = np.column_stack([yvalues[:-1], yvalues[1:]])
        ym = np.min(yvaluesM, axis=1)
        yM = np.max(yvaluesM, axis=1)

        # Subdivide time intervals
        ttm = tt[:-1]
        ttM = tt[1:]

        ss = np.ones_like(xm)

        # If derivatives info is needed, handle the derivative signs
        if derivatives_infos == 1:
            der_signx = np.sign(SxL.coefs[ibl, 0])  
            der_signy = np.sign(SyL.coefs[ibl, 0])
            boxL = np.column_stack((xm, xM, ym, yM, ttm, ttM, isp * ss, ibl * ss, der_signx * ss, der_signy * ss))
        else:
            boxL = np.column_stack((xm, xM, ym, yM, ttm, ttM, isp * ss, ibl * ss))

   

        # Append the current box to the list
        box_VxL.append(boxL)

    # Return the final boxes as a numpy array
    return np.vstack(box_VxL)




#--------------------------------------------------------------------------
#
#--------------------------------------------------------------------------

def spline_boxer_ordernot2(SxL, SyL, isp, Nsub):

#     This function builds the "boxes" for a piece of spline of order not 2.
    
#     Args:
#         SxL (CubicSpline): Spline for x coordinates.
#         SyL (CubicSpline): Spline for y coordinates.
#         isp (int): Spline index.
#         Nsub (int): Number of subdivisions of each subinterval determined by breaks and x-turning points.
        
#     Returns:
#         box_VxL (ndarray): Array containing the boxes with variables [a, b, c, d, ..., der_signx, der_signy].
#         turning_points_SxL (ndarray): Points where the derivative of SxL is zero (turning points in x).
#         turning_points_SyL (ndarray): Points where the derivative of SyL is zero (turning points in y).

    derivatives_infos=0; 
    
    # Derivatives of SxL and SyL
    SxL1 = SxL.derivative()
    SxL1_coeffs = SxL1.c.T
    
    SyL1 = SxL.derivative()
    SyL1_coeffs = SyL1.c.T
    
    # Breaks of the splines
    nodes = SxL.x.T
    
    # Initialization
    box_VxL = [] 
    turning_points_SxL = []
    turning_points_SyL = []
    
    # Analysis of each spline component
    for ibl in range(len(nodes) - 1):
        
        # Retrieving data for the current interval
        a = nodes[ibl]
        b = nodes[ibl + 1]
        t1=0; t2=b-a;
        # Spline coefficients for current interval
        SxL_coeffsL = SxL.c.T[ibl]
        SyL_coeffsL = SyL.c.T[ibl]
        SxL1_coeffsL = SxL1.c.T[ibl]
        SyL1_coeffsL = SyL1.c.T[ibl]
        
        
        # Turning points analysis
        turning_points_xL = turning_points_analysis(SxL_coeffsL, SyL_coeffsL, SxL1_coeffsL, a, t1, t2)
        turning_points_yL = turning_points_analysis(SxL_coeffsL, SyL_coeffsL, SyL1_coeffsL, a, t1, t2)

        
        
        turning_points_SxL.append(turning_points_xL)
        turning_points_SyL.append(turning_points_yL)
        
        
        # Making monotone boxes based on turning points and interval [a, b]
        t12 = np.linspace(t1, t2, Nsub + 1)
        t12=t12.T
        SxLvalues_ab = np.polyval(SxL_coeffsL, t12)
        SyLvalues_ab = np.polyval(SyL_coeffsL, t12)
        
        
        SxyLvalues_ab_ext = np.column_stack((SxLvalues_ab, SyLvalues_ab, a + t12))
        # Adding turning points to the list of values

        SxLvalues = np.vstack((SxyLvalues_ab_ext, turning_points_xL, turning_points_yL))
        
        
        # Sorting rows based on the third column (the t values)
        prebox_VxL0 = SxLvalues[np.argsort(SxLvalues[:, 2])]
        
        # Box coordinates and derivatives in each box
        tt = prebox_VxL0[:, 2]
        
        Xv = prebox_VxL0[:, 0]
        Yv = prebox_VxL0[:, 1]
        Tv = prebox_VxL0[:, 2]
        
        Xm = np.minimum(Xv[:-1], Xv[1:])  
        XM = np.maximum(Xv[:-1], Xv[1:])  
        Ym = np.minimum(Yv[:-1], Yv[1:])  
        YM = np.maximum(Yv[:-1], Yv[1:])  

        # Concatenate arrays to form preboxVxL
        preboxVxL = np.column_stack((Xm, XM, Ym, YM, Tv[:-1], Tv[1:]))
        
        # If derivative info is needed, calculate it
        if derivatives_infos == 1:
            der_signx, der_signy = derivatives_sign_monotone_box(SxL1_coeffsL, SyL1_coeffsL, tt)
            ss = np.ones(der_signx.shape)
            boxL = np.column_stack((preboxVxL, isp_ss, ibl_ss, der_signx, der_signy))
        else:
            ss = np.ones((preboxVxL.shape[0], 1))
            boxL = np.column_stack((preboxVxL, isp * ss, ibl * ss))
        
        # Append the current box to the list of boxes
        box_VxL.append(boxL)
        
    return np.vstack(box_VxL), np.vstack(turning_points_SxL), np.vstack(turning_points_SyL)




#--------------------------------------------------------------------------
#
#--------------------------------------------------------------------------

def turning_points_analysis(SxL_coeffsL, SyL_coeffsL, SxL1_coeffsL, a, t1, t2):
    # Analyze turning points based on polynomial derivatives 

    tR, flag = myroots(SxL1_coeffsL, t1, t2)

    if flag == 0:
        if len(tR) > 0:
            SxLvalues_tR = np.polyval(SxL_coeffsL, tR)
            SyLvalues_tR = np.polyval(SyL_coeffsL, tR)
            StLvalues_tR = a + tR
            turning_pointsL = np.column_stack((SxLvalues_tR, SyLvalues_tR, StLvalues_tR))
        else:
            tR = np.vstack((t1, t2))
            SxLvalues_tR = np.polyval(SxL_coeffsL, tR)
            SyLvalues_tR = np.polyval(SyL_coeffsL, tR)
            StLvalues_tR = a + tR
            turning_pointsL = np.column_stack((SxLvalues_tR, SyLvalues_tR, StLvalues_tR))
    else:
        if flag == np.inf:  # Infinite turning points (vertical segment)
            tR = np.vstack((t1, t2))
            SxLvalues_tR = np.polyval(SxL_coeffsL, tR)
            SyLvalues_tR = np.polyval(SyL_coeffsL, tR)
            StLvalues_tR = a + tR
            turning_pointsL = np.column_stack((SxLvalues_tR, SyLvalues_tR, StLvalues_tR))
        else:
            turning_pointsL = []  # No turning points

    return turning_pointsL



#--------------------------------------------------------------------------
#
#--------------------------------------------------------------------------
def derivatives_sign_monotone_box(SxL1_coeffsL, SyL1_coeffsL, tt):

#     Computes the signs of the derivatives for the x and y components based on the polynomial coefficients
#     and a set of parameter values.
    
#     Args:
#         SxL1_coeffsL (array-like): Coefficients of the polynomial for x.
#         SyL1_coeffsL (array-like): Coefficients of the polynomial for y.
#         tt (array-like): Array of parameter values.
        
#     Returns:
#         der_signx (ndarray): Sign of the derivative for x.
#         der_signy (ndarray): Sign of the derivative for y.

    
    # Compute the midpoints of tt (ttmed)
    ttmed = (tt[1:] - tt[:-1]) / 2
    
    # Evaluate the derivatives and take the sign using polyval and sign functions
    der_signx = np.sign(np.polyval(SxL1_coeffsL, ttmed))
    der_signy = np.sign(np.polyval(SyL1_coeffsL, ttmed))
    
    return der_signx, der_signy




#--------------------------------------------------------------------------
# compute_parametric_spline
#--------------------------------------------------------------------------


def compute_parametric_spline(s, x, y, spline_order, SPLtypestring):

#     Compute parametric spline relevant parameters "ppx", "ppy" so that a point
#     at the boundary of the domain has coordinates (x(s), y(s)).

#     Args:
#         s (ndarray): Parameter data.
#         x (ndarray): x coordinates to interpolate.
#         y (ndarray): y coordinates to interpolate.
#         spline_order (int): Spline order (degree + 1).
#         SPLtypestring (str): Spline type string.
#             - 'complete' : match end slopes (default).
#             - 'not-a-knot' : make spline C^3 across first and last interior break.
#             - 'periodic' : match first and second derivatives at the first and last data points.
#             - 'second' : match end second derivatives.
#             - 'variational' : set end second derivatives equal to zero.
    
#     Returns:
#         ppx (CubicSpline or PchipInterpolator): x spline.
#         ppy (CubicSpline or PchipInterpolator): y spline.

    # Default for cubic splines with periodic boundary conditions
    if spline_order == 4:
        # Handle periodic cubic splines by default
        ppx = CubicSpline(s, x, bc_type=SPLtypestring)  # Periodic boundary conditions for x
        ppy = CubicSpline(s, y, bc_type=SPLtypestring)  # Periodic boundary conditions for y
    else:
        tck_x = splrep(s, x, k=spline_order)
        tck_y = splrep(s, y, k=spline_order)

        # Evaluate splines at given points
        ppx = splev(s, tck_x)
        ppy = splev(s, tck_y)

    if ppx.form=='B-':
        ppx = PPoly.from_spline(tck_x)
        ppy = PPoly.from_spline(tck_y)
    
    return ppx, ppy





#--------------------------------------------------------------------------
# winding_algorithm
#--------------------------------------------------------------------------

def winding_algorithm(P, Sx, Sy, GL_1000):

#     Computes the winding number of points P with respect to the counterclockwise 
#     concatenated cubic spline arcs (Sx, Sy) forming a Jordan spline polygon,
#     by contour integration.

#     Args:
#         P (ndarray): 2-column array of planar points (n x 2)
#         Sx (list): List of CubicSpline objects for the x components of the spline arcs
#         Sy (list): List of CubicSpline objects for the y components of the spline arcs
#         GL_1000 (ndarray): Array of Gauss-Legendre nodes and weights for numerical integration

#     Returns:
#         ndarray: Winding numbers for each point in P (1 for inside, 0 for outside)

    windn = np.zeros((1,np.shape(P)[0]))
    
    # Loop through each cubic spline segment
    for i in range(len(Sx)):
        a = Sx[i].x.T[0]  # Start of the spline segment
        b = Sx[i].x.T[-1]  # End of the spline segment
        
        # Compute the derivatives of the splines
        dSx = Sx[i].derivative()
        dSy = Sy[i].derivative()
        
        # Define the spline evaluation and derivative functions
        x = lambda s: Sx[i](s)
        dx = lambda s: dSx(s)
        y = lambda s: Sy[i](s)
        dy = lambda s: dSy(s)
        
        # Function for the integrand
        def f(s, j):
            return (dy(s) * (x(s) - P[j, 0]) - dx(s) * (y(s) - P[j, 1])) / \
                   ((x(s) - P[j, 0])**2 + (y(s) - P[j, 1])**2)
        
        # Compute nodes and weights for the Gauss-Legendre quadrature
        nodes = GL_1000[:, 0] * (b - a) / 2 + (b + a) / 2
        weights = GL_1000[:, 1] * (b - a) / 2
        
        # Perform the integration using Gauss-Legendre quadrature for each point in P
        u, v = np.meshgrid(nodes, np.arange(1, len(P[:, 0]) + 1))

        # Compute function values
        fval = f(u.ravel(), v.ravel())

        # Reshape the array
        FV = fval.reshape(len(P[:, 0]), len(nodes))

        # Perform matrix multiplication
        int_result = FV @ weights 
        
        windn=windn+int_result.T
    # Normalize the winding number by the length of the curve
    den = Sx[-1].x[-1].T - Sx[0].x[0].T
    windn = np.round(windn / den)

    return windn




#==========================================================================
# attached function: GL_1000
#==========================================================================
def GL_1000():
    x=[-9.999971112980756e-01
    , -9.999847796329174e-01
    , -9.999625941483602e-01
    , -9.999305501355009e-01
    , -9.998886473067012e-01
    , -9.998368859309700e-01
    , -9.997752664706340e-01
    , -9.997037895136229e-01
    , -9.996224557554706e-01
    , -9.995312659933240e-01
    , -9.994302211236081e-01
    , -9.993193221410008e-01
    , -9.991985701379369e-01
    , -9.990679663043477e-01
    , -9.989275119275132e-01
    , -9.987772083919715e-01
    , -9.986170571794587e-01
    , -9.984470598688657e-01
    , -9.982672181362039e-01
    , -9.980775337545768e-01
    , -9.978780085941545e-01
    , -9.976686446221500e-01
    , -9.974494439027950e-01
    , -9.972204085973179e-01
    , -9.969815409639196e-01
    , -9.967328433577501e-01
    , -9.964743182308847e-01
    , -9.962059681322979e-01
    , -9.959277957078384e-01
    , -9.956398037002028e-01
    , -9.953419949489071e-01
    , -9.950343723902594e-01
    , -9.947169390573305e-01
    , -9.943896980799236e-01
    , -9.940526526845432e-01
    , -9.937058061943637e-01
    , -9.933491620291958e-01
    , -9.929827237054533e-01
    , -9.926064948361183e-01
    , -9.922204791307051e-01
    , -9.918246803952242e-01
    , -9.914191025321440e-01
    , -9.910037495403531e-01
    , -9.905786255151200e-01
    , -9.901437346480535e-01
    , -9.896990812270609e-01
    , -9.892446696363055e-01
    , -9.887805043561644e-01
    , -9.883065899631827e-01
    , -9.878229311300296e-01
    , -9.873295326254522e-01
    , -9.868263993142279e-01
    , -9.863135361571168e-01
    , -9.857909482108129e-01
    , -9.852586406278939e-01
    , -9.847166186567707e-01
    , -9.841648876416356e-01
    , -9.836034530224089e-01
    , -9.830323203346869e-01
    , -9.824514952096856e-01
    , -9.818609833741858e-01
    , -9.812607906504773e-01
    , -9.806509229563004e-01
    , -9.800313863047881e-01
    , -9.794021868044072e-01
    , -9.787633306588969e-01
    , -9.781148241672090e-01
    , -9.774566737234449e-01
    , -9.767888858167928e-01
    , -9.761114670314638e-01
    , -9.754244240466269e-01
    , -9.747277636363431e-01
    , -9.740214926694986e-01
    , -9.733056181097374e-01
    , -9.725801470153922e-01
    , -9.718450865394149e-01
    , -9.711004439293064e-01
    , -9.703462265270447e-01
    , -9.695824417690128e-01
    , -9.688090971859251e-01
    , -9.680262004027537e-01
    , -9.672337591386525e-01
    , -9.664317812068817e-01
    , -9.656202745147303e-01
    , -9.647992470634386e-01
    , -9.639687069481189e-01
    , -9.631286623576756e-01
    , -9.622791215747253e-01
    , -9.614200929755139e-01
    , -9.605515850298352e-01
    , -9.596736063009463e-01
    , -9.587861654454841e-01
    , -9.578892712133795e-01
    , -9.569829324477710e-01
    , -9.560671580849179e-01
    , -9.551419571541118e-01
    , -9.542073387775878e-01
    , -9.532633121704347e-01
    , -9.523098866405036e-01
    , -9.513470715883170e-01
    , -9.503748765069749e-01
    , -9.493933109820625e-01
    , -9.484023846915548e-01
    , -9.474021074057215e-01
    , -9.463924889870307e-01
    , -9.453735393900514e-01
    , -9.443452686613558e-01
    , -9.433076869394198e-01
    , -9.422608044545232e-01
    , -9.412046315286491e-01
    , -9.401391785753814e-01
    , -9.390644560998033e-01
    , -9.379804746983922e-01
    , -9.368872450589167e-01
    , -9.357847779603303e-01
    , -9.346730842726655e-01
    , -9.335521749569263e-01
    , -9.324220610649806e-01
    , -9.312827537394508e-01
    , -9.301342642136041e-01
    , -9.289766038112420e-01
    , -9.278097839465882e-01
    , -9.266338161241762e-01
    , -9.254487119387360e-01
    , -9.242544830750798e-01
    , -9.230511413079867e-01
    , -9.218386985020864e-01
    , -9.206171666117428e-01
    , -9.193865576809351e-01
    , -9.181468838431406e-01
    , -9.168981573212134e-01
    , -9.156403904272650e-01
    , -9.143735955625426e-01
    , -9.130977852173067e-01
    , -9.118129719707079e-01
    , -9.105191684906634e-01
    , -9.092163875337312e-01
    , -9.079046419449854e-01
    , -9.065839446578886e-01
    , -9.052543086941648e-01
    , -9.039157471636710e-01
    , -9.025682732642681e-01
    , -9.012119002816904e-01
    , -8.998466415894147e-01
    , -8.984725106485290e-01
    , -8.970895210075985e-01
    , -8.956976863025338e-01
    , -8.942970202564546e-01
    , -8.928875366795559e-01
    , -8.914692494689709e-01
    , -8.900421726086343e-01
    , -8.886063201691446e-01
    , -8.871617063076249e-01
    , -8.857083452675839e-01
    , -8.842462513787749e-01
    , -8.827754390570548e-01
    , -8.812959228042421e-01
    , -8.798077172079737e-01
    , -8.783108369415609e-01
    , -8.768052967638450e-01
    , -8.752911115190520e-01
    , -8.737682961366459e-01
    , -8.722368656311812e-01
    , -8.706968351021556e-01
    , -8.691482197338604e-01
    , -8.675910347952316e-01
    , -8.660252956396985e-01
    , -8.644510177050330e-01
    , -8.628682165131966e-01
    , -8.612769076701884e-01
    , -8.596771068658904e-01
    , -8.580688298739131e-01
    , -8.564520925514401e-01
    , -8.548269108390713e-01
    , -8.531933007606665e-01
    , -8.515512784231865e-01
    , -8.499008600165348e-01
    , -8.482420618133982e-01
    , -8.465749001690859e-01
    , -8.448993915213685e-01
    , -8.432155523903155e-01
    , -8.415233993781333e-01
    , -8.398229491690001e-01
    , -8.381142185289034e-01
    , -8.363972243054727e-01
    , -8.346719834278143e-01
    , -8.329385129063448e-01
    , -8.311968298326226e-01
    , -8.294469513791792e-01
    , -8.276888947993514e-01
    , -8.259226774271093e-01
    , -8.241483166768867e-01
    , -8.223658300434088e-01
    , -8.205752351015196e-01
    , -8.187765495060093e-01
    , -8.169697909914395e-01
    , -8.151549773719688e-01
    , -8.133321265411768e-01
    , -8.115012564718881e-01
    , -8.096623852159945e-01
    , -8.078155309042779e-01
    , -8.059607117462307e-01
    , -8.040979460298764e-01
    , -8.022272521215899e-01
    , -8.003486484659154e-01
    , -7.984621535853855e-01
    , -7.965677860803383e-01
    , -7.946655646287335e-01
    , -7.927555079859688e-01
    , -7.908376349846947e-01
    , -7.889119645346292e-01
    , -7.869785156223710e-01
    , -7.850373073112119e-01
    , -7.830883587409498e-01
    , -7.811316891276996e-01
    , -7.791673177637031e-01
    , -7.771952640171397e-01
    , -7.752155473319350e-01
    , -7.732281872275689e-01
    , -7.712332032988839e-01
    , -7.692306152158909e-01
    , -7.672204427235757e-01
    , -7.652027056417049e-01
    , -7.631774238646295e-01
    , -7.611446173610890e-01
    , -7.591043061740155e-01
    , -7.570565104203343e-01
    , -7.550012502907671e-01
    , -7.529385460496325e-01
    , -7.508684180346457e-01
    , -7.487908866567183e-01
    , -7.467059723997576e-01
    , -7.446136958204634e-01
    , -7.425140775481267e-01
    , -7.404071382844252e-01
    , -7.382928988032200e-01
    , -7.361713799503499e-01
    , -7.340426026434269e-01
    , -7.319065878716291e-01
    , -7.297633566954940e-01
    , -7.276129302467115e-01
    , -7.254553297279143e-01
    , -7.232905764124696e-01
    , -7.211186916442698e-01
    , -7.189396968375211e-01
    , -7.167536134765330e-01
    , -7.145604631155059e-01
    , -7.123602673783193e-01
    , -7.101530479583182e-01
    , -7.079388266180990e-01
    , -7.057176251892955e-01
    , -7.034894655723630e-01
    , -7.012543697363630e-01
    , -6.990123597187459e-01
    , -6.967634576251345e-01
    , -6.945076856291054e-01
    , -6.922450659719704e-01
    , -6.899756209625583e-01
    , -6.876993729769928e-01
    , -6.854163444584741e-01
    , -6.831265579170562e-01
    , -6.808300359294256e-01
    , -6.785268011386784e-01
    , -6.762168762540970e-01
    , -6.739002840509267e-01
    , -6.715770473701509e-01
    , -6.692471891182650e-01
    , -6.669107322670522e-01
    , -6.645676998533557e-01
    , -6.622181149788520e-01
    , -6.598620008098232e-01
    , -6.574993805769284e-01
    , -6.551302775749750e-01
    , -6.527547151626888e-01
    , -6.503727167624830e-01
    , -6.479843058602290e-01
    , -6.455895060050229e-01
    , -6.431883408089545e-01
    , -6.407808339468741e-01
    , -6.383670091561594e-01
    , -6.359468902364808e-01
    , -6.335205010495674e-01
    , -6.310878655189712e-01
    , -6.286490076298320e-01
    , -6.262039514286397e-01
    , -6.237527210229985e-01
    , -6.212953405813885e-01
    , -6.188318343329273e-01
    , -6.163622265671316e-01
    , -6.138865416336770e-01
    , -6.114048039421588e-01
    , -6.089170379618506e-01
    , -6.064232682214638e-01
    , -6.039235193089045e-01
    , -6.014178158710324e-01
    , -5.989061826134173e-01
    , -5.963886443000951e-01
    , -5.938652257533241e-01
    , -5.913359518533402e-01
    , -5.888008475381117e-01
    , -5.862599378030930e-01
    , -5.837132477009781e-01
    , -5.811608023414545e-01
    , -5.786026268909548e-01
    , -5.760387465724085e-01
    , -5.734691866649939e-01
    , -5.708939725038883e-01
    , -5.683131294800189e-01
    , -5.657266830398111e-01
    , -5.631346586849395e-01
    , -5.605370819720750e-01
    , -5.579339785126332e-01
    , -5.553253739725217e-01
    , -5.527112940718880e-01
    , -5.500917645848646e-01
    , -5.474668113393159e-01
    , -5.448364602165826e-01
    , -5.422007371512277e-01
    , -5.395596681307794e-01
    , -5.369132791954765e-01
    , -5.342615964380096e-01
    , -5.316046460032660e-01
    , -5.289424540880701e-01
    , -5.262750469409269e-01
    , -5.236024508617610e-01
    , -5.209246922016596e-01
    , -5.182417973626101e-01
    , -5.155537927972434e-01
    , -5.128607050085692e-01
    , -5.101625605497169e-01
    , -5.074593860236734e-01
    , -5.047512080830209e-01
    , -5.020380534296736e-01
    , -4.993199488146152e-01
    , -4.965969210376339e-01
    , -4.938689969470604e-01
    , -4.911362034395000e-01
    , -4.883985674595709e-01
    , -4.856561159996345e-01
    , -4.829088760995346e-01
    , -4.801568748463252e-01
    , -4.774001393740068e-01
    , -4.746386968632583e-01
    , -4.718725745411689e-01
    , -4.691017996809685e-01
    , -4.663263996017608e-01
    , -4.635464016682530e-01
    , -4.607618332904848e-01
    , -4.579727219235606e-01
    , -4.551790950673760e-01
    , -4.523809802663499e-01
    , -4.495784051091496e-01
    , -4.467713972284212e-01
    , -4.439599843005154e-01
    , -4.411441940452169e-01
    , -4.383240542254689e-01
    , -4.354995926470994e-01
    , -4.326708371585488e-01
    , -4.298378156505943e-01
    , -4.270005560560748e-01
    , -4.241590863496144e-01
    , -4.213134345473503e-01
    , -4.184636287066516e-01
    , -4.156096969258460e-01
    , -4.127516673439428e-01
    , -4.098895681403530e-01
    , -4.070234275346142e-01
    , -4.041532737861100e-01
    , -4.012791351937939e-01
    , -3.984010400959077e-01
    , -3.955190168697040e-01
    , -3.926330939311652e-01
    , -3.897432997347245e-01
    , -3.868496627729833e-01
    , -3.839522115764340e-01
    , -3.810509747131738e-01
    , -3.781459807886273e-01
    , -3.752372584452621e-01
    , -3.723248363623067e-01
    , -3.694087432554689e-01
    , -3.664890078766510e-01
    , -3.635656590136674e-01
    , -3.606387254899606e-01
    , -3.577082361643171e-01
    , -3.547742199305824e-01
    , -3.518367057173760e-01
    , -3.488957224878070e-01
    , -3.459512992391884e-01
    , -3.430034650027503e-01
    , -3.400522488433541e-01
    , -3.370976798592069e-01
    , -3.341397871815732e-01
    , -3.311785999744878e-01
    , -3.282141474344693e-01
    , -3.252464587902320e-01
    , -3.222755633023960e-01
    , -3.193014902632018e-01
    , -3.163242689962176e-01
    , -3.133439288560541e-01
    , -3.103604992280731e-01
    , -3.073740095280963e-01
    , -3.043844892021185e-01
    , -3.013919677260152e-01
    , -2.983964746052525e-01
    , -2.953980393745963e-01
    , -2.923966915978200e-01
    , -2.893924608674150e-01
    , -2.863853768042977e-01
    , -2.833754690575169e-01
    , -2.803627673039623e-01
    , -2.773473012480731e-01
    , -2.743291006215421e-01
    , -2.713081951830252e-01
    , -2.682846147178464e-01
    , -2.652583890377055e-01
    , -2.622295479803826e-01
    , -2.591981214094458e-01
    , -2.561641392139540e-01
    , -2.531276313081655e-01
    , -2.500886276312411e-01
    , -2.470471581469482e-01
    , -2.440032528433684e-01
    , -2.409569417325970e-01
    , -2.379082548504527e-01
    , -2.348572222561768e-01
    , -2.318038740321401e-01
    , -2.287482402835438e-01
    , -2.256903511381238e-01
    , -2.226302367458543e-01
    , -2.195679272786493e-01
    , -2.165034529300667e-01
    , -2.134368439150074e-01
    , -2.103681304694220e-01
    , -2.072973428500084e-01
    , -2.042245113339161e-01
    , -2.011496662184466e-01
    , -1.980728378207556e-01
    , -1.949940564775524e-01
    , -1.919133525448032e-01
    , -1.888307563974286e-01
    , -1.857462984290076e-01
    , -1.826600090514756e-01
    , -1.795719186948246e-01
    , -1.764820578068050e-01
    , -1.733904568526228e-01
    , -1.702971463146424e-01
    , -1.672021566920822e-01
    , -1.641055185007176e-01
    , -1.610072622725773e-01
    , -1.579074185556439e-01
    , -1.548060179135523e-01
    , -1.517030909252879e-01
    , -1.485986681848864e-01
    , -1.454927803011297e-01
    , -1.423854578972470e-01
    , -1.392767316106107e-01
    , -1.361666320924357e-01
    , -1.330551900074751e-01
    , -1.299424360337224e-01
    , -1.268284008621025e-01
    , -1.237131151961749e-01
    , -1.205966097518273e-01
    , -1.174789152569755e-01
    , -1.143600624512574e-01
    , -1.112400820857331e-01
    , -1.081190049225787e-01
    , -1.049968617347854e-01
    , -1.018736833058549e-01
    , -9.874950042949604e-02
    , -9.562434390932102e-02
    , -9.249824455854230e-02
    , -8.937123319966822e-02
    , -8.624334066419928e-02
    , -8.311459779232394e-02
    , -7.998503543261501e-02
    , -7.685468444172568e-02
    , -7.372357568408372e-02
    , -7.059174003158945e-02
    , -6.745920836330904e-02
    , -6.432601156517212e-02
    , -6.119218052966611e-02
    , -5.805774615553117e-02
    , -5.492273934745737e-02
    , -5.178719101577792e-02
    , -4.865113207616557e-02
    , -4.551459344932774e-02
    , -4.237760606070101e-02
    , -3.924020084014754e-02
    , -3.610240872164740e-02
    , -3.296426064299765e-02
    , -2.982578754550276e-02
    , -2.668702037367428e-02
    , -2.354799007492080e-02
    , -2.040872759924663e-02
    , -1.726926389894526e-02
    , -1.412962992829401e-02
    , -1.098985664324877e-02
    , -7.849975001139075e-03
    , -4.710015960364133e-03
    , -1.570010480083192e-03
    , 1.570010480083192e-03
    , 4.710015960364133e-03
    , 7.849975001139075e-03
    , 1.098985664324877e-02
    , 1.412962992829401e-02
    , 1.726926389894526e-02
    , 2.040872759924663e-02
    , 2.354799007492080e-02
    , 2.668702037367428e-02
    , 2.982578754550276e-02
    , 3.296426064299765e-02
    , 3.610240872164740e-02
    , 3.924020084014754e-02
    , 4.237760606070101e-02
    , 4.551459344932774e-02
    , 4.865113207616557e-02
    , 5.178719101577792e-02
    , 5.492273934745737e-02
    , 5.805774615553117e-02
    , 6.119218052966611e-02
    , 6.432601156517212e-02
    , 6.745920836330904e-02
    , 7.059174003158945e-02
    , 7.372357568408372e-02
    , 7.685468444172568e-02
    , 7.998503543261501e-02
    , 8.311459779232394e-02
    , 8.624334066419928e-02
    , 8.937123319966822e-02
    , 9.249824455854230e-02
    , 9.562434390932102e-02
    , 9.874950042949604e-02
    , 1.018736833058549e-01
    , 1.049968617347854e-01
    , 1.081190049225787e-01
    , 1.112400820857331e-01
    , 1.143600624512574e-01
    , 1.174789152569755e-01
    , 1.205966097518273e-01
    , 1.237131151961749e-01
    , 1.268284008621025e-01
    , 1.299424360337224e-01
    , 1.330551900074751e-01
    , 1.361666320924357e-01
    , 1.392767316106107e-01
    , 1.423854578972470e-01
    , 1.454927803011297e-01
    , 1.485986681848864e-01
    , 1.517030909252879e-01
    , 1.548060179135523e-01
    , 1.579074185556439e-01
    , 1.610072622725773e-01
    , 1.641055185007176e-01
    , 1.672021566920822e-01
    , 1.702971463146424e-01
    , 1.733904568526228e-01
    , 1.764820578068050e-01
    , 1.795719186948246e-01
    , 1.826600090514756e-01
    , 1.857462984290076e-01
    , 1.888307563974286e-01
    , 1.919133525448032e-01
    , 1.949940564775524e-01
    , 1.980728378207556e-01
    , 2.011496662184466e-01
    , 2.042245113339161e-01
    , 2.072973428500084e-01
    , 2.103681304694220e-01
    , 2.134368439150074e-01
    , 2.165034529300667e-01
    , 2.195679272786493e-01
    , 2.226302367458543e-01
    , 2.256903511381238e-01
    , 2.287482402835438e-01
    , 2.318038740321401e-01
    , 2.348572222561768e-01
    , 2.379082548504527e-01
    , 2.409569417325970e-01
    , 2.440032528433684e-01
    , 2.470471581469482e-01
    , 2.500886276312411e-01
    , 2.531276313081655e-01
    , 2.561641392139540e-01
    , 2.591981214094458e-01
    , 2.622295479803826e-01
    , 2.652583890377055e-01
    , 2.682846147178464e-01
    , 2.713081951830252e-01
    , 2.743291006215421e-01
    , 2.773473012480731e-01
    , 2.803627673039623e-01
    , 2.833754690575169e-01
    , 2.863853768042977e-01
    , 2.893924608674150e-01
    , 2.923966915978200e-01
    , 2.953980393745963e-01
    , 2.983964746052525e-01
    , 3.013919677260152e-01
    , 3.043844892021185e-01
    , 3.073740095280963e-01
    , 3.103604992280731e-01
    , 3.133439288560541e-01
    , 3.163242689962176e-01
    , 3.193014902632018e-01
    , 3.222755633023960e-01
    , 3.252464587902320e-01
    , 3.282141474344693e-01
    , 3.311785999744878e-01
    , 3.341397871815732e-01
    , 3.370976798592069e-01
    , 3.400522488433541e-01
    , 3.430034650027503e-01
    , 3.459512992391884e-01
    , 3.488957224878070e-01
    , 3.518367057173760e-01
    , 3.547742199305824e-01
    , 3.577082361643171e-01
    , 3.606387254899606e-01
    , 3.635656590136674e-01
    , 3.664890078766510e-01
    , 3.694087432554689e-01
    , 3.723248363623067e-01
    , 3.752372584452621e-01
    , 3.781459807886273e-01
    , 3.810509747131738e-01
    , 3.839522115764340e-01
    , 3.868496627729833e-01
    , 3.897432997347245e-01
    , 3.926330939311652e-01
    , 3.955190168697040e-01
    , 3.984010400959077e-01
    , 4.012791351937939e-01
    , 4.041532737861100e-01
    , 4.070234275346142e-01
    , 4.098895681403530e-01
    , 4.127516673439428e-01
    , 4.156096969258460e-01
    , 4.184636287066516e-01
    , 4.213134345473503e-01
    , 4.241590863496144e-01
    , 4.270005560560748e-01
    , 4.298378156505943e-01
    , 4.326708371585488e-01
    , 4.354995926470994e-01
    , 4.383240542254689e-01
    , 4.411441940452169e-01
    , 4.439599843005154e-01
    , 4.467713972284212e-01
    , 4.495784051091496e-01
    , 4.523809802663499e-01
    , 4.551790950673760e-01
    , 4.579727219235606e-01
    , 4.607618332904848e-01
    , 4.635464016682530e-01
    , 4.663263996017608e-01
    , 4.691017996809685e-01
    , 4.718725745411689e-01
    , 4.746386968632583e-01
    , 4.774001393740068e-01
    , 4.801568748463252e-01
    , 4.829088760995346e-01
    , 4.856561159996345e-01
    , 4.883985674595709e-01
    , 4.911362034395000e-01
    , 4.938689969470604e-01
    , 4.965969210376339e-01
    , 4.993199488146152e-01
    , 5.020380534296736e-01
    , 5.047512080830209e-01
    , 5.074593860236734e-01
    , 5.101625605497169e-01
    , 5.128607050085692e-01
    , 5.155537927972434e-01
    , 5.182417973626101e-01
    , 5.209246922016596e-01
    , 5.236024508617610e-01
    , 5.262750469409269e-01
    , 5.289424540880701e-01
    , 5.316046460032660e-01
    , 5.342615964380096e-01
    , 5.369132791954765e-01
    , 5.395596681307794e-01
    , 5.422007371512277e-01
    , 5.448364602165826e-01
    , 5.474668113393159e-01
    , 5.500917645848646e-01
    , 5.527112940718880e-01
    , 5.553253739725217e-01
    , 5.579339785126332e-01
    , 5.605370819720750e-01
    , 5.631346586849395e-01
    , 5.657266830398111e-01
    , 5.683131294800189e-01
    , 5.708939725038883e-01
    , 5.734691866649939e-01
    , 5.760387465724085e-01
    , 5.786026268909548e-01
    , 5.811608023414545e-01
    , 5.837132477009781e-01
    , 5.862599378030930e-01
    , 5.888008475381117e-01
    , 5.913359518533402e-01
    , 5.938652257533241e-01
    , 5.963886443000951e-01
    , 5.989061826134173e-01
    , 6.014178158710324e-01
    , 6.039235193089045e-01
    , 6.064232682214638e-01
    , 6.089170379618506e-01
    , 6.114048039421588e-01
    , 6.138865416336770e-01
    , 6.163622265671316e-01
    , 6.188318343329273e-01
    , 6.212953405813885e-01
    , 6.237527210229985e-01
    , 6.262039514286397e-01
    , 6.286490076298320e-01
    , 6.310878655189712e-01
    , 6.335205010495674e-01
    , 6.359468902364808e-01
    , 6.383670091561594e-01
    , 6.407808339468741e-01
    , 6.431883408089545e-01
    , 6.455895060050229e-01
    , 6.479843058602290e-01
    , 6.503727167624830e-01
    , 6.527547151626888e-01
    , 6.551302775749750e-01
    , 6.574993805769284e-01
    , 6.598620008098232e-01
    , 6.622181149788520e-01
    , 6.645676998533557e-01
    , 6.669107322670522e-01
    , 6.692471891182650e-01
    , 6.715770473701509e-01
    , 6.739002840509267e-01
    , 6.762168762540970e-01
    , 6.785268011386784e-01
    , 6.808300359294256e-01
    , 6.831265579170562e-01
    , 6.854163444584741e-01
    , 6.876993729769928e-01
    , 6.899756209625583e-01
    , 6.922450659719704e-01
    , 6.945076856291054e-01
    , 6.967634576251345e-01
    , 6.990123597187459e-01
    , 7.012543697363630e-01
    , 7.034894655723630e-01
    , 7.057176251892955e-01
    , 7.079388266180990e-01
    , 7.101530479583182e-01
    , 7.123602673783193e-01
    , 7.145604631155059e-01
    , 7.167536134765330e-01
    , 7.189396968375211e-01
    , 7.211186916442698e-01
    , 7.232905764124696e-01
    , 7.254553297279143e-01
    , 7.276129302467115e-01
    , 7.297633566954940e-01
    , 7.319065878716291e-01
    , 7.340426026434269e-01
    , 7.361713799503499e-01
    , 7.382928988032200e-01
    , 7.404071382844252e-01
    , 7.425140775481267e-01
    , 7.446136958204634e-01
    , 7.467059723997576e-01
    , 7.487908866567183e-01
    , 7.508684180346457e-01
    , 7.529385460496325e-01
    , 7.550012502907671e-01
    , 7.570565104203343e-01
    , 7.591043061740155e-01
    , 7.611446173610890e-01
    , 7.631774238646295e-01
    , 7.652027056417049e-01
    , 7.672204427235757e-01
    , 7.692306152158909e-01
    , 7.712332032988839e-01
    , 7.732281872275689e-01
    , 7.752155473319350e-01
    , 7.771952640171397e-01
    , 7.791673177637031e-01
    , 7.811316891276996e-01
    , 7.830883587409498e-01
    , 7.850373073112119e-01
    , 7.869785156223710e-01
    , 7.889119645346292e-01
    , 7.908376349846947e-01
    , 7.927555079859688e-01
    , 7.946655646287335e-01
    , 7.965677860803383e-01
    , 7.984621535853855e-01
    , 8.003486484659154e-01
    , 8.022272521215899e-01
    , 8.040979460298764e-01
    , 8.059607117462307e-01
    , 8.078155309042779e-01
    , 8.096623852159945e-01
    , 8.115012564718881e-01
    , 8.133321265411768e-01
    , 8.151549773719688e-01
    , 8.169697909914395e-01
    , 8.187765495060093e-01
    , 8.205752351015196e-01
    , 8.223658300434088e-01
    , 8.241483166768867e-01
    , 8.259226774271093e-01
    , 8.276888947993514e-01
    , 8.294469513791792e-01
    , 8.311968298326226e-01
    , 8.329385129063448e-01
    , 8.346719834278143e-01
    , 8.363972243054727e-01
    , 8.381142185289034e-01
    , 8.398229491690001e-01
    , 8.415233993781333e-01
    , 8.432155523903155e-01
    , 8.448993915213685e-01
    , 8.465749001690859e-01
    , 8.482420618133982e-01
    , 8.499008600165348e-01
    , 8.515512784231865e-01
    , 8.531933007606665e-01
    , 8.548269108390713e-01
    , 8.564520925514401e-01
    , 8.580688298739131e-01
    , 8.596771068658904e-01
    , 8.612769076701884e-01
    , 8.628682165131966e-01
    , 8.644510177050330e-01
    , 8.660252956396985e-01
    , 8.675910347952316e-01
    , 8.691482197338604e-01
    , 8.706968351021556e-01
    , 8.722368656311812e-01
    , 8.737682961366459e-01
    , 8.752911115190520e-01
    , 8.768052967638450e-01
    , 8.783108369415609e-01
    , 8.798077172079737e-01
    , 8.812959228042421e-01
    , 8.827754390570548e-01
    , 8.842462513787749e-01
    , 8.857083452675839e-01
    , 8.871617063076249e-01
    , 8.886063201691446e-01
    , 8.900421726086343e-01
    , 8.914692494689709e-01
    , 8.928875366795559e-01
    , 8.942970202564546e-01
    , 8.956976863025338e-01
    , 8.970895210075985e-01
    , 8.984725106485290e-01
    , 8.998466415894147e-01
    , 9.012119002816904e-01
    , 9.025682732642681e-01
    , 9.039157471636710e-01
    , 9.052543086941648e-01
    , 9.065839446578886e-01
    , 9.079046419449854e-01
    , 9.092163875337312e-01
    , 9.105191684906634e-01
    , 9.118129719707079e-01
    , 9.130977852173067e-01
    , 9.143735955625426e-01
    , 9.156403904272650e-01
    , 9.168981573212134e-01
    , 9.181468838431406e-01
    , 9.193865576809351e-01
    , 9.206171666117428e-01
    , 9.218386985020864e-01
    , 9.230511413079867e-01
    , 9.242544830750798e-01
    , 9.254487119387360e-01
    , 9.266338161241762e-01
    , 9.278097839465882e-01
    , 9.289766038112420e-01
    , 9.301342642136041e-01
    , 9.312827537394508e-01
    , 9.324220610649806e-01
    , 9.335521749569263e-01
    , 9.346730842726655e-01
    , 9.357847779603303e-01
    , 9.368872450589167e-01
    , 9.379804746983922e-01
    , 9.390644560998033e-01
    , 9.401391785753814e-01
    , 9.412046315286491e-01
    , 9.422608044545232e-01
    , 9.433076869394198e-01
    , 9.443452686613558e-01
    , 9.453735393900514e-01
    , 9.463924889870307e-01
    , 9.474021074057215e-01
    , 9.484023846915548e-01
    , 9.493933109820625e-01
    , 9.503748765069749e-01
    , 9.513470715883170e-01
    , 9.523098866405036e-01
    , 9.532633121704347e-01
    , 9.542073387775878e-01
    , 9.551419571541118e-01
    , 9.560671580849179e-01
    , 9.569829324477710e-01
    , 9.578892712133795e-01
    , 9.587861654454841e-01
    , 9.596736063009463e-01
    , 9.605515850298352e-01
    , 9.614200929755139e-01
    , 9.622791215747253e-01
    , 9.631286623576756e-01
    , 9.639687069481189e-01
    , 9.647992470634386e-01
    , 9.656202745147303e-01
    , 9.664317812068817e-01
    , 9.672337591386525e-01
    , 9.680262004027537e-01
    , 9.688090971859251e-01
    , 9.695824417690128e-01
    , 9.703462265270447e-01
    , 9.711004439293064e-01
    , 9.718450865394149e-01
    , 9.725801470153922e-01
    , 9.733056181097374e-01
    , 9.740214926694986e-01
    , 9.747277636363431e-01
    , 9.754244240466269e-01
    , 9.761114670314638e-01
    , 9.767888858167928e-01
    , 9.774566737234449e-01
    , 9.781148241672090e-01
    , 9.787633306588969e-01
    , 9.794021868044072e-01
    , 9.800313863047881e-01
    , 9.806509229563004e-01
    , 9.812607906504773e-01
    , 9.818609833741858e-01
    , 9.824514952096856e-01
    , 9.830323203346869e-01
    , 9.836034530224089e-01
    , 9.841648876416356e-01
    , 9.847166186567707e-01
    , 9.852586406278939e-01
    , 9.857909482108129e-01
    , 9.863135361571168e-01
    , 9.868263993142279e-01
    , 9.873295326254522e-01
    , 9.878229311300296e-01
    , 9.883065899631827e-01
    , 9.887805043561644e-01
    , 9.892446696363055e-01
    , 9.896990812270609e-01
    , 9.901437346480535e-01
    , 9.905786255151200e-01
    , 9.910037495403531e-01
    , 9.914191025321440e-01
    , 9.918246803952242e-01
    , 9.922204791307051e-01
    , 9.926064948361183e-01
    , 9.929827237054533e-01
    , 9.933491620291958e-01
    , 9.937058061943637e-01
    , 9.940526526845432e-01
    , 9.943896980799236e-01
    , 9.947169390573305e-01
    , 9.950343723902594e-01
    , 9.953419949489071e-01
    , 9.956398037002028e-01
    , 9.959277957078384e-01
    , 9.962059681322979e-01
    , 9.964743182308847e-01
    , 9.967328433577501e-01
    , 9.969815409639196e-01
    , 9.972204085973179e-01
    , 9.974494439027950e-01
    , 9.976686446221500e-01
    , 9.978780085941545e-01
    , 9.980775337545768e-01
    , 9.982672181362039e-01
    , 9.984470598688657e-01
    , 9.986170571794587e-01
    , 9.987772083919715e-01
    , 9.989275119275132e-01
    , 9.990679663043477e-01
    , 9.991985701379369e-01
    , 9.993193221410008e-01
    , 9.994302211236081e-01
    , 9.995312659933240e-01
    , 9.996224557554706e-01
    , 9.997037895136229e-01
    , 9.997752664706340e-01
    , 9.998368859309700e-01
    , 9.998886473067012e-01
    , 9.999305501355009e-01
    , 9.999625941483602e-01
    , 9.999847796329174e-01
    , 9.999971112980756e-01 ];



    w=[7.413338416432071e-06
    , 1.725676977373923e-05
    , 2.711460656520586e-05
    , 3.697344200643550e-05
    , 4.683216706971275e-05
    , 5.669050651151729e-05
    , 6.654831593030788e-05
    , 7.640548208416073e-05
    , 8.626190132806909e-05
    , 9.611747354547055e-05
    , 1.059721000990171e-04
    , 1.158256830390418e-04
    , 1.256781247645614e-04
    , 1.355293278657728e-04
    , 1.453791950459568e-04
    , 1.552276290807009e-04
    , 1.650745327957399e-04
    , 1.749198090545718e-04
    , 1.847633607514339e-04
    , 1.946050908073345e-04
    , 2.044449021678837e-04
    , 2.142826978022177e-04
    , 2.241183807026033e-04
    , 2.339518538844774e-04
    , 2.437830203867700e-04
    , 2.536117832724149e-04
    , 2.634380456289895e-04
    , 2.732617105694400e-04
    , 2.830826812328697e-04
    , 2.929008607853699e-04
    , 3.027161524208810e-04
    , 3.125284593620774e-04
    , 3.223376848612676e-04
    , 3.321437322013066e-04
    , 3.419465046965173e-04
    , 3.517459056936195e-04
    , 3.615418385726617e-04
    , 3.713342067479596e-04
    , 3.811229136690341e-04
    , 3.909078628215541e-04
    , 4.006889577282802e-04
    , 4.104661019500086e-04
    , 4.202391990865167e-04
    , 4.300081527775093e-04
    , 4.397728667035656e-04
    , 4.495332445870837e-04
    , 4.592891901932303e-04
    , 4.690406073308848e-04
    , 4.787873998535875e-04
    , 4.885294716604855e-04
    , 4.982667266972789e-04
    , 5.079990689571673e-04
    , 5.177264024817950e-04
    , 5.274486313621963e-04
    , 5.371656597397405e-04
    , 5.468773918070770e-04
    , 5.565837318090788e-04
    , 5.662845840437867e-04
    , 5.759798528633512e-04
    , 5.856694426749778e-04
    , 5.953532579418668e-04
    , 6.050312031841557e-04
    , 6.147031829798617e-04
    , 6.243691019658201e-04
    , 6.340288648386262e-04
    , 6.436823763555741e-04
    , 6.533295413355955e-04
    , 6.629702646601990e-04
    , 6.726044512744057e-04
    , 6.822320061876894e-04
    , 6.918528344749099e-04
    , 7.014668412772516e-04
    , 7.110739318031568e-04
    , 7.206740113292620e-04
    , 7.302669852013290e-04
    , 7.398527588351816e-04
    , 7.494312377176357e-04
    , 7.590023274074321e-04
    , 7.685659335361670e-04
    , 7.781219618092233e-04
    , 7.876703180066994e-04
    , 7.972109079843394e-04
    , 8.067436376744594e-04
    , 8.162684130868772e-04
    , 8.257851403098364e-04
    , 8.352937255109361e-04
    , 8.447940749380504e-04
    , 8.542860949202592e-04
    , 8.637696918687673e-04
    , 8.732447722778282e-04
    , 8.827112427256674e-04
    , 8.921690098754021e-04
    , 9.016179804759605e-04
    , 9.110580613630041e-04
    , 9.204891594598446e-04
    , 9.299111817783607e-04
    , 9.393240354199172e-04
    , 9.487276275762778e-04
    , 9.581218655305246e-04
    , 9.675066566579679e-04
    , 9.768819084270612e-04
    , 9.862475284003150e-04
    , 9.956034242352054e-04
    , 1.004949503685087e-03
    , 1.014285674600100e-03
    , 1.023611844928081e-03
    , 1.032927922715472e-03
    , 1.042233816108219e-03
    , 1.051529433352690e-03
    , 1.060814682796570e-03
    , 1.070089472889766e-03
    , 1.079353712185315e-03
    , 1.088607309340280e-03
    , 1.097850173116653e-03
    , 1.107082212382255e-03
    , 1.116303336111633e-03
    , 1.125513453386959e-03
    , 1.134712473398925e-03
    , 1.143900305447640e-03
    , 1.153076858943521e-03
    , 1.162242043408192e-03
    , 1.171395768475371e-03
    , 1.180537943891762e-03
    , 1.189668479517946e-03
    , 1.198787285329270e-03
    , 1.207894271416733e-03
    , 1.216989347987873e-03
    , 1.226072425367654e-03
    , 1.235143413999347e-03
    , 1.244202224445417e-03
    , 1.253248767388401e-03
    , 1.262282953631792e-03
    , 1.271304694100914e-03
    , 1.280313899843806e-03
    , 1.289310482032094e-03
    , 1.298294351961871e-03
    , 1.307265421054567e-03
    , 1.316223600857826e-03
    , 1.325168803046379e-03
    , 1.334100939422908e-03
    , 1.343019921918926e-03
    , 1.351925662595635e-03
    , 1.360818073644801e-03
    , 1.369697067389615e-03
    , 1.378562556285561e-03
    , 1.387414452921273e-03
    , 1.396252670019407e-03
    , 1.405077120437490e-03
    , 1.413887717168789e-03
    , 1.422684373343161e-03
    , 1.431467002227917e-03
    , 1.440235517228671e-03
    , 1.448989831890196e-03
    , 1.457729859897278e-03
    , 1.466455515075564e-03
    , 1.475166711392415e-03
    , 1.483863362957751e-03
    , 1.492545384024901e-03
    , 1.501212688991444e-03
    , 1.509865192400058e-03
    , 1.518502808939362e-03
    , 1.527125453444752e-03
    , 1.535733040899247e-03
    , 1.544325486434322e-03
    , 1.552902705330750e-03
    , 1.561464613019433e-03
    , 1.570011125082237e-03
    , 1.578542157252828e-03
    , 1.587057625417495e-03
    , 1.595557445615986e-03
    , 1.604041534042337e-03
    , 1.612509807045688e-03
    , 1.620962181131121e-03
    , 1.629398572960475e-03
    , 1.637818899353169e-03
    , 1.646223077287026e-03
    , 1.654611023899084e-03
    , 1.662982656486419e-03
    , 1.671337892506963e-03
    , 1.679676649580308e-03
    , 1.687998845488527e-03
    , 1.696304398176983e-03
    , 1.704593225755132e-03
    , 1.712865246497340e-03
    , 1.721120378843683e-03
    , 1.729358541400747e-03
    , 1.737579652942445e-03
    , 1.745783632410800e-03
    , 1.753970398916756e-03
    , 1.762139871740975e-03
    , 1.770291970334624e-03
    , 1.778426614320179e-03
    , 1.786543723492215e-03
    , 1.794643217818192e-03
    , 1.802725017439252e-03
    , 1.810789042670997e-03
    , 1.818835214004284e-03
    , 1.826863452106004e-03
    , 1.834873677819862e-03
    , 1.842865812167164e-03
    , 1.850839776347589e-03
    , 1.858795491739974e-03
    , 1.866732879903076e-03
    , 1.874651862576361e-03
    , 1.882552361680765e-03
    , 1.890434299319467e-03
    , 1.898297597778659e-03
    , 1.906142179528309e-03
    , 1.913967967222926e-03
    , 1.921774883702324e-03
    , 1.929562851992384e-03
    , 1.937331795305809e-03
    , 1.945081637042882e-03
    , 1.952812300792226e-03
    , 1.960523710331551e-03
    , 1.968215789628411e-03
    , 1.975888462840948e-03
    , 1.983541654318645e-03
    , 1.991175288603067e-03
    , 1.998789290428615e-03
    , 2.006383584723250e-03
    , 2.013958096609253e-03
    , 2.021512751403949e-03
    , 2.029047474620451e-03
    , 2.036562191968393e-03
    , 2.044056829354659e-03
    , 2.051531312884117e-03
    , 2.058985568860349e-03
    , 2.066419523786370e-03
    , 2.073833104365362e-03
    , 2.081226237501393e-03
    , 2.088598850300136e-03
    , 2.095950870069590e-03
    , 2.103282224320793e-03
    , 2.110592840768541e-03
    , 2.117882647332103e-03
    , 2.125151572135922e-03
    , 2.132399543510334e-03
    , 2.139626489992268e-03
    , 2.146832340325951e-03
    , 2.154017023463618e-03
    , 2.161180468566204e-03
    , 2.168322605004043e-03
    , 2.175443362357568e-03
    , 2.182542670418008e-03
    , 2.189620459188072e-03
    , 2.196676658882644e-03
    , 2.203711199929472e-03
    , 2.210724012969852e-03
    , 2.217715028859311e-03
    , 2.224684178668293e-03
    , 2.231631393682832e-03
    , 2.238556605405238e-03
    , 2.245459745554762e-03
    , 2.252340746068279e-03
    , 2.259199539100956e-03
    , 2.266036057026913e-03
    , 2.272850232439903e-03
    , 2.279641998153969e-03
    , 2.286411287204108e-03
    , 2.293158032846927e-03
    , 2.299882168561310e-03
    , 2.306583628049067e-03
    , 2.313262345235589e-03
    , 2.319918254270500e-03
    , 2.326551289528307e-03
    , 2.333161385609047e-03
    , 2.339748477338928e-03
    , 2.346312499770981e-03
    , 2.352853388185686e-03
    , 2.359371078091624e-03
    , 2.365865505226107e-03
    , 2.372336605555810e-03
    , 2.378784315277403e-03
    , 2.385208570818183e-03
    , 2.391609308836700e-03
    , 2.397986466223378e-03
    , 2.404339980101141e-03
    , 2.410669787826031e-03
    , 2.416975826987830e-03
    , 2.423258035410665e-03
    , 2.429516351153631e-03
    , 2.435750712511404e-03
    , 2.441961058014833e-03
    , 2.448147326431567e-03
    , 2.454309456766642e-03
    , 2.460447388263092e-03
    , 2.466561060402543e-03
    , 2.472650412905817e-03
    , 2.478715385733515e-03
    , 2.484755919086618e-03
    , 2.490771953407074e-03
    , 2.496763429378383e-03
    , 2.502730287926187e-03
    , 2.508672470218845e-03
    , 2.514589917668023e-03
    , 2.520482571929258e-03
    , 2.526350374902550e-03
    , 2.532193268732920e-03
    , 2.538011195810989e-03
    , 2.543804098773543e-03
    , 2.549571920504098e-03
    , 2.555314604133467e-03
    , 2.561032093040317e-03
    , 2.566724330851727e-03
    , 2.572391261443745e-03
    , 2.578032828941942e-03
    , 2.583648977721962e-03
    , 2.589239652410075e-03
    , 2.594804797883713e-03
    , 2.600344359272021e-03
    , 2.605858281956397e-03
    , 2.611346511571029e-03
    , 2.616808994003433e-03
    , 2.622245675394985e-03
    , 2.627656502141452e-03
    , 2.633041420893520e-03
    , 2.638400378557324e-03
    , 2.643733322294964e-03
    , 2.649040199525035e-03
    , 2.654320957923137e-03
    , 2.659575545422398e-03
    , 2.664803910213981e-03
    , 2.670006000747599e-03
    , 2.675181765732026e-03
    , 2.680331154135593e-03
    , 2.685454115186698e-03
    , 2.690550598374310e-03
    , 2.695620553448458e-03
    , 2.700663930420736e-03
    , 2.705680679564785e-03
    , 2.710670751416793e-03
    , 2.715634096775979e-03
    , 2.720570666705080e-03
    , 2.725480412530825e-03
    , 2.730363285844427e-03
    , 2.735219238502055e-03
    , 2.740048222625306e-03
    , 2.744850190601680e-03
    , 2.749625095085050e-03
    , 2.754372888996129e-03
    , 2.759093525522930e-03
    , 2.763786958121232e-03
    , 2.768453140515037e-03
    , 2.773092026697030e-03
    , 2.777703570929024e-03
    , 2.782287727742421e-03
    , 2.786844451938652e-03
    , 2.791373698589630e-03
    , 2.795875423038185e-03
    , 2.800349580898514e-03
    , 2.804796128056608e-03
    , 2.809215020670695e-03
    , 2.813606215171669e-03
    , 2.817969668263520e-03
    , 2.822305336923760e-03
    , 2.826613178403850e-03
    , 2.830893150229617e-03
    , 2.835145210201678e-03
    , 2.839369316395851e-03
    , 2.843565427163576e-03
    , 2.847733501132313e-03
    , 2.851873497205961e-03
    , 2.855985374565260e-03
    , 2.860069092668195e-03
    , 2.864124611250388e-03
    , 2.868151890325506e-03
    , 2.872150890185647e-03
    , 2.876121571401736e-03
    , 2.880063894823915e-03
    , 2.883977821581920e-03
    , 2.887863313085473e-03
    , 2.891720331024665e-03
    , 2.895548837370322e-03
    , 2.899348794374390e-03
    , 2.903120164570302e-03
    , 2.906862910773354e-03
    , 2.910576996081061e-03
    , 2.914262383873530e-03
    , 2.917919037813817e-03
    , 2.921546921848289e-03
    , 2.925146000206969e-03
    , 2.928716237403907e-03
    , 2.932257598237510e-03
    , 2.935770047790903e-03
    , 2.939253551432268e-03
    , 2.942708074815184e-03
    , 2.946133583878970e-03
    , 2.949530044849017e-03
    , 2.952897424237124e-03
    , 2.956235688841825e-03
    , 2.959544805748718e-03
    , 2.962824742330790e-03
    , 2.966075466248741e-03
    , 2.969296945451293e-03
    , 2.972489148175522e-03
    , 2.975652042947158e-03
    , 2.978785598580897e-03
    , 2.981889784180712e-03
    , 2.984964569140165e-03
    , 2.988009923142688e-03
    , 2.991025816161902e-03
    , 2.994012218461904e-03
    , 2.996969100597564e-03
    , 2.999896433414806e-03
    , 3.002794188050909e-03
    , 3.005662335934783e-03
    , 3.008500848787250e-03
    , 3.011309698621333e-03
    , 3.014088857742515e-03
    , 3.016838298749028e-03
    , 3.019557994532115e-03
    , 3.022247918276299e-03
    , 3.024908043459645e-03
    , 3.027538343854029e-03
    , 3.030138793525386e-03
    , 3.032709366833974e-03
    , 3.035250038434625e-03
    , 3.037760783276995e-03
    , 3.040241576605799e-03
    , 3.042692393961083e-03
    , 3.045113211178437e-03
    , 3.047504004389244e-03
    , 3.049864750020924e-03
    , 3.052195424797148e-03
    , 3.054496005738085e-03
    , 3.056766470160619e-03
    , 3.059006795678572e-03
    , 3.061216960202934e-03
    , 3.063396941942065e-03
    , 3.065546719401931e-03
    , 3.067666271386294e-03
    , 3.069755576996934e-03
    , 3.071814615633858e-03
    , 3.073843366995487e-03
    , 3.075841811078876e-03
    , 3.077809928179896e-03
    , 3.079747698893435e-03
    , 3.081655104113591e-03
    , 3.083532125033856e-03
    , 3.085378743147301e-03
    , 3.087194940246763e-03
    , 3.088980698425022e-03
    , 3.090736000074978e-03
    , 3.092460827889820e-03
    , 3.094155164863208e-03
    , 3.095818994289429e-03
    , 3.097452299763566e-03
    , 3.099055065181663e-03
    , 3.100627274740879e-03
    , 3.102168912939644e-03
    , 3.103679964577818e-03
    , 3.105160414756831e-03
    , 3.106610248879840e-03
    , 3.108029452651865e-03
    , 3.109418012079937e-03
    , 3.110775913473224e-03
    , 3.112103143443181e-03
    , 3.113399688903676e-03
    , 3.114665537071113e-03
    , 3.115900675464568e-03
    , 3.117105091905902e-03
    , 3.118278774519892e-03
    , 3.119421711734338e-03
    , 3.120533892280183e-03
    , 3.121615305191622e-03
    , 3.122665939806213e-03
    , 3.123685785764977e-03
    , 3.124674833012502e-03
    , 3.125633071797050e-03
    , 3.126560492670637e-03
    , 3.127457086489142e-03
    , 3.128322844412387e-03
    , 3.129157757904231e-03
    , 3.129961818732646e-03
    , 3.130735018969810e-03
    , 3.131477350992170e-03
    , 3.132188807480534e-03
    , 3.132869381420126e-03
    , 3.133519066100670e-03
    , 3.134137855116449e-03
    , 3.134725742366366e-03
    , 3.135282722054010e-03
    , 3.135808788687708e-03
    , 3.136303937080585e-03
    , 3.136768162350607e-03
    , 3.137201459920638e-03
    , 3.137603825518479e-03
    , 3.137975255176912e-03
    , 3.138315745233739e-03
    , 3.138625292331819e-03
    , 3.138903893419101e-03
    , 3.139151545748650e-03
    , 3.139368246878682e-03
    , 3.139553994672580e-03
    , 3.139708787298920e-03
    , 3.139832623231489e-03
    , 3.139925501249297e-03
    , 3.139987420436592e-03
    , 3.140018380182867e-03
    , 3.140018380182867e-03
    , 3.139987420436592e-03
    , 3.139925501249297e-03
    , 3.139832623231489e-03
    , 3.139708787298920e-03
    , 3.139553994672580e-03
    , 3.139368246878682e-03
    , 3.139151545748650e-03
    , 3.138903893419101e-03
    , 3.138625292331819e-03
    , 3.138315745233739e-03
    , 3.137975255176912e-03
    , 3.137603825518479e-03
    , 3.137201459920638e-03
    , 3.136768162350607e-03
    , 3.136303937080585e-03
    , 3.135808788687708e-03
    , 3.135282722054010e-03
    , 3.134725742366366e-03
    , 3.134137855116449e-03
    , 3.133519066100670e-03
    , 3.132869381420126e-03
    , 3.132188807480534e-03
    , 3.131477350992170e-03
    , 3.130735018969810e-03
    , 3.129961818732646e-03
    , 3.129157757904231e-03
    , 3.128322844412387e-03
    , 3.127457086489142e-03
    , 3.126560492670637e-03
    , 3.125633071797050e-03
    , 3.124674833012502e-03
    , 3.123685785764977e-03
    , 3.122665939806213e-03
    , 3.121615305191622e-03
    , 3.120533892280183e-03
    , 3.119421711734338e-03
    , 3.118278774519892e-03
    , 3.117105091905902e-03
    , 3.115900675464568e-03
    , 3.114665537071113e-03
    , 3.113399688903676e-03
    , 3.112103143443181e-03
    , 3.110775913473224e-03
    , 3.109418012079937e-03
    , 3.108029452651865e-03
    , 3.106610248879840e-03
    , 3.105160414756831e-03
    , 3.103679964577818e-03
    , 3.102168912939644e-03
    , 3.100627274740879e-03
    , 3.099055065181663e-03
    , 3.097452299763566e-03
    , 3.095818994289429e-03
    , 3.094155164863208e-03
    , 3.092460827889820e-03
    , 3.090736000074978e-03
    , 3.088980698425022e-03
    , 3.087194940246763e-03
    , 3.085378743147301e-03
    , 3.083532125033856e-03
    , 3.081655104113591e-03
    , 3.079747698893435e-03
    , 3.077809928179896e-03
    , 3.075841811078876e-03
    , 3.073843366995487e-03
    , 3.071814615633858e-03
    , 3.069755576996934e-03
    , 3.067666271386294e-03
    , 3.065546719401931e-03
    , 3.063396941942065e-03
    , 3.061216960202934e-03
    , 3.059006795678572e-03
    , 3.056766470160619e-03
    , 3.054496005738085e-03
    , 3.052195424797148e-03
    , 3.049864750020924e-03
    , 3.047504004389244e-03
    , 3.045113211178437e-03
    , 3.042692393961083e-03
    , 3.040241576605799e-03
    , 3.037760783276995e-03
    , 3.035250038434625e-03
    , 3.032709366833974e-03
    , 3.030138793525386e-03
    , 3.027538343854029e-03
    , 3.024908043459645e-03
    , 3.022247918276299e-03
    , 3.019557994532115e-03
    , 3.016838298749028e-03
    , 3.014088857742515e-03
    , 3.011309698621333e-03
    , 3.008500848787250e-03
    , 3.005662335934783e-03
    , 3.002794188050909e-03
    , 2.999896433414806e-03
    , 2.996969100597564e-03
    , 2.994012218461904e-03
    , 2.991025816161902e-03
    , 2.988009923142688e-03
    , 2.984964569140165e-03
    , 2.981889784180712e-03
    , 2.978785598580897e-03
    , 2.975652042947158e-03
    , 2.972489148175522e-03
    , 2.969296945451293e-03
    , 2.966075466248741e-03
    , 2.962824742330790e-03
    , 2.959544805748718e-03
    , 2.956235688841825e-03
    , 2.952897424237124e-03
    , 2.949530044849017e-03
    , 2.946133583878970e-03
    , 2.942708074815184e-03
    , 2.939253551432268e-03
    , 2.935770047790903e-03
    , 2.932257598237510e-03
    , 2.928716237403907e-03
    , 2.925146000206969e-03
    , 2.921546921848289e-03
    , 2.917919037813817e-03
    , 2.914262383873530e-03
    , 2.910576996081061e-03
    , 2.906862910773354e-03
    , 2.903120164570302e-03
    , 2.899348794374390e-03
    , 2.895548837370322e-03
    , 2.891720331024665e-03
    , 2.887863313085473e-03
    , 2.883977821581920e-03
    , 2.880063894823915e-03
    , 2.876121571401736e-03
    , 2.872150890185647e-03
    , 2.868151890325506e-03
    , 2.864124611250388e-03
    , 2.860069092668195e-03
    , 2.855985374565260e-03
    , 2.851873497205961e-03
    , 2.847733501132313e-03
    , 2.843565427163576e-03
    , 2.839369316395851e-03
    , 2.835145210201678e-03
    , 2.830893150229617e-03
    , 2.826613178403850e-03
    , 2.822305336923760e-03
    , 2.817969668263520e-03
    , 2.813606215171669e-03
    , 2.809215020670695e-03
    , 2.804796128056608e-03
    , 2.800349580898514e-03
    , 2.795875423038185e-03
    , 2.791373698589630e-03
    , 2.786844451938652e-03
    , 2.782287727742421e-03
    , 2.777703570929024e-03
    , 2.773092026697030e-03
    , 2.768453140515037e-03
    , 2.763786958121232e-03
    , 2.759093525522930e-03
    , 2.754372888996129e-03
    , 2.749625095085050e-03
    , 2.744850190601680e-03
    , 2.740048222625306e-03
    , 2.735219238502055e-03
    , 2.730363285844427e-03
    , 2.725480412530825e-03
    , 2.720570666705080e-03
    , 2.715634096775979e-03
    , 2.710670751416793e-03
    , 2.705680679564785e-03
    , 2.700663930420736e-03
    , 2.695620553448458e-03
    , 2.690550598374310e-03
    , 2.685454115186698e-03
    , 2.680331154135593e-03
    , 2.675181765732026e-03
    , 2.670006000747599e-03
    , 2.664803910213981e-03
    , 2.659575545422398e-03
    , 2.654320957923137e-03
    , 2.649040199525035e-03
    , 2.643733322294964e-03
    , 2.638400378557324e-03
    , 2.633041420893520e-03
    , 2.627656502141452e-03
    , 2.622245675394985e-03
    , 2.616808994003433e-03
    , 2.611346511571029e-03
    , 2.605858281956397e-03
    , 2.600344359272021e-03
    , 2.594804797883713e-03
    , 2.589239652410075e-03
    , 2.583648977721962e-03
    , 2.578032828941942e-03
    , 2.572391261443745e-03
    , 2.566724330851727e-03
    , 2.561032093040317e-03
    , 2.555314604133467e-03
    , 2.549571920504098e-03
    , 2.543804098773543e-03
    , 2.538011195810989e-03
    , 2.532193268732920e-03
    , 2.526350374902550e-03
    , 2.520482571929258e-03
    , 2.514589917668023e-03
    , 2.508672470218845e-03
    , 2.502730287926187e-03
    , 2.496763429378383e-03
    , 2.490771953407074e-03
    , 2.484755919086618e-03
    , 2.478715385733515e-03
    , 2.472650412905817e-03
    , 2.466561060402543e-03
    , 2.460447388263092e-03
    , 2.454309456766642e-03
    , 2.448147326431567e-03
    , 2.441961058014833e-03
    , 2.435750712511404e-03
    , 2.429516351153631e-03
    , 2.423258035410665e-03
    , 2.416975826987830e-03
    , 2.410669787826031e-03
    , 2.404339980101141e-03
    , 2.397986466223378e-03
    , 2.391609308836700e-03
    , 2.385208570818183e-03
    , 2.378784315277403e-03
    , 2.372336605555810e-03
    , 2.365865505226107e-03
    , 2.359371078091624e-03
    , 2.352853388185686e-03
    , 2.346312499770981e-03
    , 2.339748477338928e-03
    , 2.333161385609047e-03
    , 2.326551289528307e-03
    , 2.319918254270500e-03
    , 2.313262345235589e-03
    , 2.306583628049067e-03
    , 2.299882168561310e-03
    , 2.293158032846927e-03
    , 2.286411287204108e-03
    , 2.279641998153969e-03
    , 2.272850232439903e-03
    , 2.266036057026913e-03
    , 2.259199539100956e-03
    , 2.252340746068279e-03
    , 2.245459745554762e-03
    , 2.238556605405238e-03
    , 2.231631393682832e-03
    , 2.224684178668293e-03
    , 2.217715028859311e-03
    , 2.210724012969852e-03
    , 2.203711199929472e-03
    , 2.196676658882644e-03
    , 2.189620459188072e-03
    , 2.182542670418008e-03
    , 2.175443362357568e-03
    , 2.168322605004043e-03
    , 2.161180468566204e-03
    , 2.154017023463618e-03
    , 2.146832340325951e-03
    , 2.139626489992268e-03
    , 2.132399543510334e-03
    , 2.125151572135922e-03
    , 2.117882647332103e-03
    , 2.110592840768541e-03
    , 2.103282224320793e-03
    , 2.095950870069590e-03
    , 2.088598850300136e-03
    , 2.081226237501393e-03
    , 2.073833104365362e-03
    , 2.066419523786370e-03
    , 2.058985568860349e-03
    , 2.051531312884117e-03
    , 2.044056829354659e-03
    , 2.036562191968393e-03
    , 2.029047474620451e-03
    , 2.021512751403949e-03
    , 2.013958096609253e-03
    , 2.006383584723250e-03
    , 1.998789290428615e-03
    , 1.991175288603067e-03
    , 1.983541654318645e-03
    , 1.975888462840948e-03
    , 1.968215789628411e-03
    , 1.960523710331551e-03
    , 1.952812300792226e-03
    , 1.945081637042882e-03
    , 1.937331795305809e-03
    , 1.929562851992384e-03
    , 1.921774883702324e-03
    , 1.913967967222926e-03
    , 1.906142179528309e-03
    , 1.898297597778659e-03
    , 1.890434299319467e-03
    , 1.882552361680765e-03
    , 1.874651862576361e-03
    , 1.866732879903076e-03
    , 1.858795491739974e-03
    , 1.850839776347589e-03
    , 1.842865812167164e-03
    , 1.834873677819862e-03
    , 1.826863452106004e-03
    , 1.818835214004284e-03
    , 1.810789042670997e-03
    , 1.802725017439252e-03
    , 1.794643217818192e-03
    , 1.786543723492215e-03
    , 1.778426614320179e-03
    , 1.770291970334624e-03
    , 1.762139871740975e-03
    , 1.753970398916756e-03
    , 1.745783632410800e-03
    , 1.737579652942445e-03
    , 1.729358541400747e-03
    , 1.721120378843683e-03
    , 1.712865246497340e-03
    , 1.704593225755132e-03
    , 1.696304398176983e-03
    , 1.687998845488527e-03
    , 1.679676649580308e-03
    , 1.671337892506963e-03
    , 1.662982656486419e-03
    , 1.654611023899084e-03
    , 1.646223077287026e-03
    , 1.637818899353169e-03
    , 1.629398572960475e-03
    , 1.620962181131121e-03
    , 1.612509807045688e-03
    , 1.604041534042337e-03
    , 1.595557445615986e-03
    , 1.587057625417495e-03
    , 1.578542157252828e-03
    , 1.570011125082237e-03
    , 1.561464613019433e-03
    , 1.552902705330750e-03
    , 1.544325486434322e-03
    , 1.535733040899247e-03
    , 1.527125453444752e-03
    , 1.518502808939362e-03
    , 1.509865192400058e-03
    , 1.501212688991444e-03
    , 1.492545384024901e-03
    , 1.483863362957751e-03
    , 1.475166711392415e-03
    , 1.466455515075564e-03
    , 1.457729859897278e-03
    , 1.448989831890196e-03
    , 1.440235517228671e-03
    , 1.431467002227917e-03
    , 1.422684373343161e-03
    , 1.413887717168789e-03
    , 1.405077120437490e-03
    , 1.396252670019407e-03
    , 1.387414452921273e-03
    , 1.378562556285561e-03
    , 1.369697067389615e-03
    , 1.360818073644801e-03
    , 1.351925662595635e-03
    , 1.343019921918926e-03
    , 1.334100939422908e-03
    , 1.325168803046379e-03
    , 1.316223600857826e-03
    , 1.307265421054567e-03
    , 1.298294351961871e-03
    , 1.289310482032094e-03
    , 1.280313899843806e-03
    , 1.271304694100914e-03
    , 1.262282953631792e-03
    , 1.253248767388401e-03
    , 1.244202224445417e-03
    , 1.235143413999347e-03
    , 1.226072425367654e-03
    , 1.216989347987873e-03
    , 1.207894271416733e-03
    , 1.198787285329270e-03
    , 1.189668479517946e-03
    , 1.180537943891762e-03
    , 1.171395768475371e-03
    , 1.162242043408192e-03
    , 1.153076858943521e-03
    , 1.143900305447640e-03
    , 1.134712473398925e-03
    , 1.125513453386959e-03
    , 1.116303336111633e-03
    , 1.107082212382255e-03
    , 1.097850173116653e-03
    , 1.088607309340280e-03
    , 1.079353712185315e-03
    , 1.070089472889766e-03
    , 1.060814682796570e-03
    , 1.051529433352690e-03
    , 1.042233816108219e-03
    , 1.032927922715472e-03
    , 1.023611844928081e-03
    , 1.014285674600100e-03
    , 1.004949503685087e-03
    , 9.956034242352054e-04
    , 9.862475284003150e-04
    , 9.768819084270612e-04
    , 9.675066566579679e-04
    , 9.581218655305246e-04
    , 9.487276275762778e-04
    , 9.393240354199172e-04
    , 9.299111817783607e-04
    , 9.204891594598446e-04
    , 9.110580613630041e-04
    , 9.016179804759605e-04
    , 8.921690098754021e-04
    , 8.827112427256674e-04
    , 8.732447722778282e-04
    , 8.637696918687673e-04
    , 8.542860949202592e-04
    , 8.447940749380504e-04
    , 8.352937255109361e-04
    , 8.257851403098364e-04
    , 8.162684130868772e-04
    , 8.067436376744594e-04
    , 7.972109079843394e-04
    , 7.876703180066994e-04
    , 7.781219618092233e-04
    , 7.685659335361670e-04
    , 7.590023274074321e-04
    , 7.494312377176357e-04
    , 7.398527588351816e-04
    , 7.302669852013290e-04
    , 7.206740113292620e-04
    , 7.110739318031568e-04
    , 7.014668412772516e-04
    , 6.918528344749099e-04
    , 6.822320061876894e-04
    , 6.726044512744057e-04
    , 6.629702646601990e-04
    , 6.533295413355955e-04
    , 6.436823763555741e-04
    , 6.340288648386262e-04
    , 6.243691019658201e-04
    , 6.147031829798617e-04
    , 6.050312031841557e-04
    , 5.953532579418668e-04
    , 5.856694426749778e-04
    , 5.759798528633512e-04
    , 5.662845840437867e-04
    , 5.565837318090788e-04
    , 5.468773918070770e-04
    , 5.371656597397405e-04
    , 5.274486313621963e-04
    , 5.177264024817950e-04
    , 5.079990689571673e-04
    , 4.982667266972789e-04
    , 4.885294716604855e-04
    , 4.787873998535875e-04
    , 4.690406073308848e-04
    , 4.592891901932303e-04
    , 4.495332445870837e-04
    , 4.397728667035656e-04
    , 4.300081527775093e-04
    , 4.202391990865167e-04
    , 4.104661019500086e-04
    , 4.006889577282802e-04
    , 3.909078628215541e-04
    , 3.811229136690341e-04
    , 3.713342067479596e-04
    , 3.615418385726617e-04
    , 3.517459056936195e-04
    , 3.419465046965173e-04
    , 3.321437322013066e-04
    , 3.223376848612676e-04
    , 3.125284593620774e-04
    , 3.027161524208810e-04
    , 2.929008607853699e-04
    , 2.830826812328697e-04
    , 2.732617105694400e-04
    , 2.634380456289895e-04
    , 2.536117832724149e-04
    , 2.437830203867700e-04
    , 2.339518538844774e-04
    , 2.241183807026033e-04
    , 2.142826978022177e-04
    , 2.044449021678837e-04
    , 1.946050908073345e-04
    , 1.847633607514339e-04
    , 1.749198090545718e-04
    , 1.650745327957399e-04
    , 1.552276290807009e-04
    , 1.453791950459568e-04
    , 1.355293278657728e-04
    , 1.256781247645614e-04
    , 1.158256830390418e-04
    , 1.059721000990171e-04
    , 9.611747354547055e-05
    , 8.626190132806909e-05
    , 7.640548208416073e-05
    , 6.654831593030788e-05
    , 5.669050651151729e-05
    , 4.683216706971275e-05
    , 3.697344200643550e-05
    , 2.711460656520586e-05
    , 1.725676977373923e-05
    , 7.413338416432071e-06];
    
    xw=[x , w]
    
    return xw



















